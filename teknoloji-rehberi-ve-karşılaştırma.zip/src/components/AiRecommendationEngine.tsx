import React, { useState } from 'react';
import { Product } from '../data/products';
import { Sparkles, Terminal, Sliders, DollarSign, Brain, Heart, Gamepad2, Compass, ShieldAlert, CheckCircle, Scale, Loader2, ArrowRight } from 'lucide-react';
import { motion } from 'motion/react';

interface AiRecommendationEngineProps {
  products: Product[];
  onAddToCompare: (product: Product) => void;
  onViewDetails: (product: Product) => void;
  compareList: Product[];
}

interface RecommendedItem {
  productId: string;
  matchScore: number;
  reasoning: string;
}

interface AIResponse {
  userAnalysis: string;
  recommendedProducts: RecommendedItem[];
  genericAdvice: string;
}

export default function AiRecommendationEngine({
  products,
  onAddToCompare,
  onViewDetails,
  compareList
}: AiRecommendationEngineProps) {
  const [budget, setBudget] = useState<number>(5000);
  const [primaryUse, setPrimaryUse] = useState<string>('Yapay Zeka, Geliştirme & Profesyonel Kodlama');
  const [selectedCategory, setSelectedCategory] = useState<string>('Hepsi');
  const [customNeeds, setCustomNeeds] = useState<string>('');

  const [loading, setLoading] = useState<boolean>(false);
  const [statusText, setStatusText] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<AIResponse | null>(null);

  const useCases = [
    { value: 'Yapay Zeka, Geliştirme & Profesyonel Kodlama', label: 'AI, Robotik & Yazılım Geliştirme', icon: Brain },
    { value: 'Grafik Tasarım, 3B Modelleme & Yoğun Oyunlar', label: 'Ultra Grafik & Gaming / İş İstasyonu', icon: Gamepad2 },
    { value: 'Mobilite, Taşınabilir Ofis & Sürdürülebilirlik', label: 'Modülerlik & Sürdürülebilir Ofis', icon: Sliders },
    { value: 'Sağlıklı Yaşam, Uyku Takibi & Bio-Metrik Veriler', label: 'Görünmez Sağlık & Bio-Takip', icon: Heart },
    { value: 'Zorlu Doğa Koşulları, Karavan & Taşınabilir İletişim', label: 'Uzak Alan & Taşınabilir İletişim', icon: Compass }
  ];

  const categories = ['Hepsi', 'Donanım & Bilgisayar', 'Giyilebilir Teknoloji', 'Sanal & Artırılmış Gerçeklik', 'Yapay Zeka & Robotik', 'Akıllı Çevre & İletişim'];

  const handleGenerateRecommendations = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setResult(null);

    const statuses = [
      'Derin Düşünme Modu (ThinkingLevel.HIGH) yükleniyor...',
      'Bütçe kısıtlamaları ve donanım parametreleri eşleştiriliyor...',
      'Tesla FSD, Apple M3, Blackwell RTX mimarileri analiz ediliyor...',
      'Üretkenlik, taşınabilirlik ve güç verimliliği indeksleri hesaplanıyor...',
      'Fiyat ve pazar yeri tedarikçileri simüle ediliyor...',
      'Yapay zeka nihai kişiselleştirilmiş raporunu oluşturuyor...'
    ];

    let statusIndex = 0;
    setStatusText(statuses[0]);
    const statusInterval = setInterval(() => {
      statusIndex++;
      if (statusIndex < statuses.length) {
        setStatusText(statuses[statusIndex]);
      }
    }, 2500);

    try {
      const response = await fetch('/api/recommend', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          budget,
          primaryUse,
          selectedCategory,
          customNeeds
        })
      });

      const data = await response.json();
      clearInterval(statusInterval);

      if (!response.ok) {
        throw new Error(data.error || 'Tavsiye motoru çalıştırılırken bir hata oluştu.');
      }

      setResult(data);
    } catch (err: any) {
      clearInterval(statusInterval);
      setError(err.message || 'Öneri alınamadı.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      
      {/* Introduction */}
      <div className="border-b border-gray-800 pb-5">
        <h2 className="font-display text-2xl font-bold text-white tracking-tight flex items-center gap-2">
          <Sparkles className="h-6 w-6 text-teal-400 animate-pulse" />
          Yapay Zeka Destekli Öneri Motoru
        </h2>
        <p className="mt-1 text-sm text-gray-400">
          TeknoAsistan uzman sistemine bütçenizi ve hedeflerinizi belirtin. Gemini 3.1 Pro <strong>Yüksek Düşünme Modu (High Thinking)</strong> ile size en uygun donanımları tespit etsin.
        </p>
      </div>

      <div className="mt-8 grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* LEFT COLUMN: PARAMETERS FORM */}
        <div className="lg:col-span-5 rounded-2xl border border-gray-800 bg-dark-card/40 p-6 backdrop-blur-sm self-start">
          <h3 className="font-display text-lg font-bold text-white mb-4 flex items-center gap-2">
            <Sliders className="h-5 w-5 text-teal-400" />
            Parametre Girişi
          </h3>

          <form onSubmit={handleGenerateRecommendations} className="space-y-6">
            
            {/* 1. Budget Slider */}
            <div className="space-y-2">
              <label className="text-xs font-mono font-semibold text-gray-400 uppercase tracking-wider flex justify-between">
                <span>Hedef Maksimum Bütçe</span>
                <span className="text-teal-400 font-bold font-mono">${budget.toLocaleString()} USD</span>
              </label>
              <div className="relative flex items-center gap-3">
                <DollarSign className="h-4 w-4 text-gray-500" />
                <input
                  type="range"
                  min="300"
                  max="25000"
                  step="100"
                  value={budget}
                  onChange={(e) => setBudget(Number(e.target.value))}
                  className="w-full h-2 rounded-lg bg-gray-900 accent-teal-500 cursor-pointer border border-gray-800"
                />
              </div>
              <div className="flex justify-between text-[10px] text-gray-600 font-mono">
                <span>$300</span>
                <span>$10,000</span>
                <span>$25,000</span>
              </div>
            </div>

            {/* 2. Primary Use Case Selector */}
            <div className="space-y-2">
              <label className="text-xs font-mono font-semibold text-gray-400 uppercase tracking-wider">
                Birincil Kullanım Amacı
              </label>
              <div className="grid grid-cols-1 gap-2">
                {useCases.map((uc) => {
                  const Icon = uc.icon;
                  const isSelected = primaryUse === uc.value;
                  return (
                    <button
                      key={uc.value}
                      type="button"
                      onClick={() => setPrimaryUse(uc.value)}
                      className={`flex items-center gap-3 rounded-xl border p-3 text-left transition-all text-xs font-semibold ${
                        isSelected
                          ? 'border-teal-500 bg-teal-500/10 text-teal-400'
                          : 'border-gray-800 bg-gray-900/20 text-gray-400 hover:border-gray-700 hover:text-white'
                      }`}
                    >
                      <Icon className={`h-4 w-4 ${isSelected ? 'text-teal-400' : 'text-gray-500'}`} />
                      <span>{uc.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 3. Category Filter */}
            <div className="space-y-2">
              <label className="text-xs font-mono font-semibold text-gray-400 uppercase tracking-wider">
                Kategori Tercihi
              </label>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="w-full rounded-xl border border-gray-800 bg-gray-900 p-3 text-xs font-semibold text-white focus:border-teal-500 focus:outline-none"
              >
                {categories.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>

            {/* 4. Custom Needs */}
            <div className="space-y-2">
              <label className="text-xs font-mono font-semibold text-gray-400 uppercase tracking-wider">
                Özel İhtiyaç ve İstekleriniz (İsteğe Bağlı)
              </label>
              <textarea
                placeholder="Örn: 'Uzun seyahatler için elektrik prizi bulamadığımda çalışabilecek, çok hafif bir donanım arıyorum.' ya da 'En yüksek yapay zeka render gücüne ihtiyacım var.'"
                rows={3}
                value={customNeeds}
                onChange={(e) => setCustomNeeds(e.target.value)}
                className="w-full rounded-xl border border-gray-800 bg-gray-900 p-3 text-xs text-white placeholder-gray-600 focus:border-teal-500 focus:outline-none leading-relaxed"
              />
            </div>

            {/* Submit Button */}
            <button
              id="btn-recommend"
              type="submit"
              disabled={loading}
              className="w-full rounded-xl bg-gradient-to-r from-teal-500 to-emerald-500 hover:from-teal-600 hover:to-emerald-600 py-3 text-xs font-bold text-dark-bg transition-all disabled:opacity-40 flex items-center justify-center gap-2"
            >
              {loading ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin text-dark-bg" />
                  Yapay Zeka Muhakeme Ediyor...
                </>
              ) : (
                <>
                  <Sparkles className="h-4 w-4 text-dark-bg animate-pulse" />
                  Akıllı Öneri Analizini Başlat
                </>
              )}
            </button>

          </form>
        </div>

        {/* RIGHT COLUMN: AI EXPLANATION & RECOMMENDED CARDS */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* Default / Loading placeholder when no result exists */}
          {!loading && !result && !error && (
            <div className="rounded-2xl border border-dashed border-gray-800 bg-dark-card/10 p-12 text-center h-full flex flex-col justify-center items-center">
              <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-teal-950/20 border border-teal-900/30 text-teal-400 mb-4 animate-pulse">
                <Brain className="h-7 w-7" />
              </div>
              <h4 className="font-display font-bold text-white text-base">Analiz Raporu Hazır Değil</h4>
              <p className="text-gray-400 text-xs mt-2 max-w-sm leading-relaxed">
                Soldaki bütçe ve kullanım kriterlerini belirleyin, <strong>"Akıllı Öneri Analizini Başlat"</strong> butonuna tıklayın. Model derin donanım şemalarını sizin için tarayacaktır.
              </p>
              <div className="mt-4 flex items-center gap-1.5 text-[10px] text-gray-500 font-mono">
                <Terminal className="h-3 w-3 text-teal-500" />
                <span>Entegre Model: gemini-3.1-pro-preview</span>
              </div>
            </div>
          )}

          {/* LOADING STATE DISPLAY */}
          {loading && (
            <div className="rounded-2xl border border-teal-900/30 bg-teal-950/5 p-8 flex flex-col justify-center items-center text-center h-full space-y-6">
              
              {/* Spinner & Glow */}
              <div className="relative flex items-center justify-center h-20 w-20">
                <div className="absolute h-full w-full rounded-full border-4 border-teal-500/10 border-t-teal-400 animate-spin" />
                <motion.div
                  animate={{ scale: [1, 1.15, 1] }}
                  transition={{ repeat: Infinity, duration: 2 }}
                  className="absolute h-10 w-10 rounded-full bg-teal-500/10 border border-teal-500/30 flex items-center justify-center"
                >
                  <Brain className="h-5 w-5 text-teal-400" />
                </motion.div>
              </div>

              <div className="space-y-2">
                <h4 className="font-display font-bold text-white text-base uppercase tracking-wider flex items-center gap-2 justify-center">
                  <span className="inline-flex h-2 w-2 rounded-full bg-teal-400 animate-ping" />
                  Yüksek Düşünme Zinciri Aktif
                </h4>
                <p className="text-sm text-teal-400 font-mono italic px-4 max-w-md mx-auto">
                  "{statusText}"
                </p>
              </div>

              <div className="border border-teal-900/30 rounded-lg p-3 bg-teal-950/20 max-w-sm text-left space-y-1.5">
                <div className="text-[10px] font-mono font-bold text-teal-500 uppercase tracking-widest flex items-center gap-1">
                  <Terminal className="h-2.5 w-2.5" />
                  Kuantum Karar Motoru
                </div>
                <p className="text-[11px] text-gray-400 leading-relaxed font-mono">
                  Gemini, donanım mimarilerini, nanometre düğüm verimliliklerini ve pazar yeri stok dinamiklerini karşılaştırıyor...
                </p>
              </div>
            </div>
          )}

          {/* SYSTEM ERROR */}
          {error && (
            <div className="rounded-2xl border border-red-900/30 bg-red-950/10 p-6 text-red-400 flex flex-col gap-3">
              <div className="font-bold font-display flex items-center gap-2 text-lg">
                <ShieldAlert className="h-5 w-5 text-red-500 animate-bounce" />
                Öneri Hizmetine Bağlanılamadı!
              </div>
              <p className="text-sm">{error}</p>
              <div className="text-xs text-gray-500 border-t border-gray-950 pt-3">
                Lütfen projenizin secrets kısmına geçerli bir <strong>GEMINI_API_KEY</strong> tanımlandığından emin olun.
              </div>
            </div>
          )}

          {/* AI RECOMMENDATION RESULT */}
          {result && !loading && (
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="space-y-6"
            >
              {/* 1. User Profile Analysis Card */}
              <div className="rounded-2xl border border-teal-900/20 bg-gradient-to-b from-teal-950/10 to-transparent p-5">
                <h4 className="text-xs font-mono font-bold text-teal-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                  <Brain className="h-3.5 w-3.5" />
                  Profil & İhtiyaç Analizi Analizi
                </h4>
                <p className="text-sm text-gray-300 leading-relaxed font-display">
                  {result.userAnalysis}
                </p>
              </div>

              {/* 2. Recommended Cards */}
              <div className="space-y-4">
                <h4 className="text-xs font-mono font-bold text-gray-400 uppercase tracking-wider">
                  Tavsiye Edilen Modern Cihazlar
                </h4>

                <div className="grid grid-cols-1 gap-4">
                  {result.recommendedProducts.map((rec) => {
                    const matchedProduct = products.find(p => p.id === rec.productId);
                    if (!matchedProduct) return null;

                    const isCurrentlyComparing = compareList.some(item => item.id === matchedProduct.id);

                    return (
                      <div
                        key={rec.productId}
                        className="rounded-2xl border border-gray-800 bg-dark-card/50 p-5 flex flex-col md:flex-row md:items-center justify-between gap-5 transition-all hover:border-gray-700 hover:shadow-lg"
                      >
                        {/* Left: Product Name, Match Circle, Reasoning */}
                        <div className="space-y-3 flex-1">
                          <div className="flex items-center gap-3">
                            {/* Circular Match Percentage */}
                            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-teal-500/10 border border-teal-500/20 font-mono text-xs font-bold text-teal-400">
                              {rec.matchScore}%
                            </div>
                            <div>
                              <h5 className="font-display font-bold text-white text-base">
                                {matchedProduct.name}
                              </h5>
                              <span className="text-[10px] text-gray-500 font-mono">
                                {matchedProduct.category} • {matchedProduct.priceRange}
                              </span>
                            </div>
                          </div>

                          <p className="text-xs text-gray-300 leading-relaxed italic border-l-2 border-teal-500/30 pl-3">
                            "{rec.reasoning}"
                          </p>
                        </div>

                        {/* Right: Actions */}
                        <div className="flex md:flex-col gap-2 shrink-0 border-t md:border-t-0 border-gray-800/60 pt-3 md:pt-0">
                          <button
                            id={`rec-view-${matchedProduct.id}`}
                            onClick={() => onViewDetails(matchedProduct)}
                            className="flex-1 md:w-36 rounded-xl bg-gray-800 border border-gray-700 hover:bg-gray-700 py-2 text-center text-xs font-semibold text-white transition-all"
                          >
                            Detaylı İncele
                          </button>
                          
                          <button
                            id={`rec-compare-${matchedProduct.id}`}
                            onClick={() => onAddToCompare(matchedProduct)}
                            className={`flex items-center justify-center gap-1 w-full rounded-xl border px-3 py-2 text-xs font-semibold transition-all ${
                              isCurrentlyComparing
                                ? 'bg-teal-500 border-teal-500 text-dark-bg'
                                : 'border-gray-700 text-gray-300 hover:border-teal-500 hover:text-teal-400 bg-transparent'
                            }`}
                          >
                            <Scale className="h-3 w-3" />
                            <span>{isCurrentlyComparing ? 'Eklendi' : 'Karşılaştır'}</span>
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* 3. General Hardware Investment Advice */}
              <div className="rounded-2xl border border-gray-800 bg-gray-900/20 p-5 flex gap-3.5">
                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-teal-950/40 border border-teal-900/30 text-teal-400">
                  <Terminal className="h-4 w-4" />
                </div>
                <div>
                  <h4 className="text-xs font-mono font-bold text-white uppercase tracking-wider mb-1.5">
                    TeknoAsistan Yatırım & Adaptasyon Tavsiyesi
                  </h4>
                  <p className="text-xs text-gray-400 leading-relaxed">
                    {result.genericAdvice}
                  </p>
                </div>
              </div>

            </motion.div>
          )}

        </div>

      </div>

    </div>
  );
}
