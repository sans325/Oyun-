import React, { useState } from 'react';
import { Product } from '../data/products';
import { Scale, Trash2, Cpu, HelpCircle, ShieldAlert, Sparkles, Terminal, ArrowRight, Loader2, BarChart2 } from 'lucide-react';
import { motion } from 'motion/react';
import {
  ResponsiveContainer,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  Legend,
  Tooltip
} from 'recharts';

function getRadarMetricsForProduct(product: Product): { subject: string; score: number }[] {
  let performance = 80;
  let priceScore = 50;
  let durability = 80;
  let features = 80;

  // Derive Performance
  const perfMetric = product.performanceMetrics.find(m => 
    m.label.toLowerCase().includes('performans') || 
    m.label.toLowerCase().includes('kalite') ||
    m.label.toLowerCase().includes('beceri') ||
    m.label.toLowerCase().includes('hız') ||
    m.label.toLowerCase().includes('güç')
  );
  if (perfMetric) {
    performance = perfMetric.value;
  } else {
    if (product.id === 'apple-vision-pro-2') performance = 95;
    else if (product.id === 'nvidia-rtx-5090') performance = 100;
    else if (product.id === 'framework-laptop-16') performance = 80;
    else if (product.id === 'samsung-galaxy-ring') performance = 85;
    else if (product.id === 'tesla-optimus-devkit') performance = 90;
    else if (product.id === 'starlink-mini') performance = 83;
  }

  // Derive Price Score (affordability: higher is better/cheaper)
  const minPrice = product.marketplace.length > 0 
    ? Math.min(...product.marketplace.map(m => m.price))
    : 1000;
  
  if (minPrice < 500) {
    priceScore = 95;
  } else if (minPrice < 1000) {
    priceScore = 85;
  } else if (minPrice < 2000) {
    priceScore = 65;
  } else if (minPrice < 5000) {
    priceScore = 40;
  } else {
    priceScore = 15;
  }

  // Derive Durability
  const durMetric = product.performanceMetrics.find(m => 
    m.label.toLowerCase().includes('dayanıklılık') || 
    m.label.toLowerCase().includes('pil') ||
    m.label.toLowerCase().includes('sürdürülebilirlik') ||
    m.label.toLowerCase().includes('verimlilik')
  );
  if (durMetric) {
    durability = durMetric.value;
  } else {
    if (product.id === 'apple-vision-pro-2') durability = 75;
    else if (product.id === 'nvidia-rtx-5090') durability = 82;
    else if (product.id === 'framework-laptop-16') durability = 95;
    else if (product.id === 'samsung-galaxy-ring') durability = 94;
    else if (product.id === 'tesla-optimus-devkit') durability = 85;
    else if (product.id === 'starlink-mini') durability = 90;
  }

  // Derive Features
  const featMetric = product.performanceMetrics.find(m => 
    m.label.toLowerCase().includes('özellik') || 
    m.label.toLowerCase().includes('sensör') ||
    m.label.toLowerCase().includes('takip') ||
    m.label.toLowerCase().includes('entegrasyon') ||
    m.label.toLowerCase().includes('karar') ||
    m.label.toLowerCase().includes('yükseltilebilirlik')
  );
  if (featMetric) {
    features = featMetric.value;
  } else {
    if (product.id === 'apple-vision-pro-2') features = 96;
    else if (product.id === 'nvidia-rtx-5090') features = 98;
    else if (product.id === 'framework-laptop-16') features = 95;
    else if (product.id === 'samsung-galaxy-ring') features = 88;
    else if (product.id === 'tesla-optimus-devkit') features = 90;
    else if (product.id === 'starlink-mini') features = 92;
  }

  return [
    { subject: 'Performans', score: performance },
    { subject: 'Ekonomiklik', score: priceScore },
    { subject: 'Dayanıklılık', score: durability },
    { subject: 'Özellik Zenginliği', score: features }
  ];
}

const CustomRadarTooltip = ({ active, payload }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-gray-950/95 border border-gray-800 p-3 rounded-xl shadow-xl backdrop-blur-sm">
        <p className="text-xs font-mono font-bold text-gray-400 mb-2 uppercase tracking-wide">
          {payload[0].payload.subject}
        </p>
        <div className="space-y-1.5">
          {payload.map((entry: any, i: number) => (
            <div key={i} className="flex items-center gap-2 text-xs">
              <span className="h-2 w-2 rounded-full" style={{ backgroundColor: entry.color }} />
              <span className="text-gray-300 font-medium">{entry.name}:</span>
              <span className="font-bold text-white font-mono">{entry.value} / 100</span>
            </div>
          ))}
        </div>
      </div>
    );
  }
  return null;
};

interface ComparisonArenaProps {
  compareList: Product[];
  onRemove: (product: Product) => void;
  onClear: () => void;
  onViewDetails: (product: Product) => void;
  onSaveSet?: (set: Product[]) => void;
}

interface AICompareResult {
  summaries: {
    [key: string]: string;
  };
  keyDifferences: string[];
  useCaseVerdict: {
    scenarioGamingOrAI: string;
    scenarioMobilityOrDaily: string;
    scenarioVerdictSummary: string;
  };
}

export default function ComparisonArena({
  compareList,
  onRemove,
  onClear,
  onViewDetails,
  onSaveSet
}: ComparisonArenaProps) {
  const [aiReport, setAiReport] = useState<AICompareResult | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [loadingStatus, setLoadingStatus] = useState<string>('');
  const [setSaved, setSetSaved] = useState<boolean>(false);

  // Compute radar data based on selected products
  const radarData = [
    { subject: 'Performans', fullMark: 100 },
    { subject: 'Ekonomiklik', fullMark: 100 },
    { subject: 'Dayanıklılık', fullMark: 100 },
    { subject: 'Özellik Zenginliği', fullMark: 100 }
  ].map(item => {
    const row: any = { ...item };
    compareList.forEach(product => {
      const metrics = getRadarMetricsForProduct(product);
      const matched = metrics.find(m => m.subject === item.subject);
      row[product.name] = matched ? matched.score : 80;
    });
    return row;
  });

  // List of technical specs labels present in any of our items to align them side-by-side
  const allSpecLabels = Array.from(
    new Set(compareList.flatMap(p => p.specs.map(s => s.label)))
  );

  const allPerformanceLabels = Array.from(
    new Set(compareList.flatMap(p => p.performanceMetrics.map(m => m.label)))
  );

  const handleGenerateAIReport = async () => {
    if (compareList.length < 2) return;
    setLoading(true);
    setError(null);
    setAiReport(null);

    const statuses = [
      'Seçilen cihazların donanım şemaları çıkarılıyor...',
      'Çiplerin nanometre ve transistör yoğunlukları kıyaslanıyor...',
      'Güç verimlilikleri ve termal kapasiteler simüle ediliyor...',
      'Pazar yeri fiyat/performans indeksleri ağırlıklandırılıyor...',
      'Derin Düşünme Modu (ThinkingLevel.HIGH) etkinleştirildi...',
      'TeknoAsistan nihai uzman raporunu derliyor...'
    ];

    let i = 0;
    setLoadingStatus(statuses[0]);
    const statusInterval = setInterval(() => {
      i++;
      if (i < statuses.length) {
        setLoadingStatus(statuses[i]);
      }
    }, 2500);

    try {
      const response = await fetch('/api/ai-compare', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ productIds: compareList.map(p => p.id) })
      });

      const data = await response.json();
      clearInterval(statusInterval);

      if (!response.ok) {
        throw new Error(data.error || 'Yapay zeka karşılaştırma raporu oluşturulurken bir hata oluştu.');
      }

      setAiReport(data);
    } catch (err: any) {
      clearInterval(statusInterval);
      setError(err.message || 'Bir şeyler ters gitti.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      
      {/* Tab Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between border-b border-gray-800 pb-5 gap-4">
        <div>
          <h2 className="font-display text-2xl font-bold text-white tracking-tight flex items-center gap-2">
            <Scale className="h-6 w-6 text-teal-400" />
            Donanım Karşılaştırma Arenası
          </h2>
          <p className="mt-1 text-sm text-gray-400">
            Seçtiğiniz modern teknolojileri yan yana koyun, derinlemesine teknik farkları inceleyin ve yapay zeka ile karşılaştırın.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {compareList.length >= 2 && onSaveSet && (
            <button
              onClick={() => {
                onSaveSet(compareList);
                setSetSaved(true);
                setTimeout(() => setSetSaved(false), 2000);
              }}
              className={`flex items-center gap-1.5 rounded-xl border px-4 py-2 text-xs font-semibold transition-all ${
                setSaved
                  ? 'bg-emerald-500 border-emerald-500 text-dark-bg'
                  : 'border-teal-500/30 bg-teal-500/10 hover:bg-teal-500/25 text-teal-400'
              }`}
            >
              <Sparkles className={`h-4 w-4 ${setSaved ? '' : 'animate-pulse text-teal-400'}`} />
              {setSaved ? 'Başarıyla Kaydedildi!' : 'Kıyaslama Setini Kaydet'}
            </button>
          )}

          {compareList.length > 0 && (
            <button
              id="btn-clear-compare"
              onClick={onClear}
              className="flex items-center gap-1.5 rounded-xl border border-red-500/30 bg-red-500/10 hover:bg-red-500/20 px-4 py-2 text-xs font-semibold text-red-400 transition-all self-start sm:self-center"
            >
              <Trash2 className="h-4 w-4" />
              Listeyi Temizle
            </button>
          )}
        </div>
      </div>

      {/* EMPTY STATE */}
      {compareList.length === 0 ? (
        <div className="mt-12 rounded-2xl border border-dashed border-gray-800 bg-dark-card/25 p-12 text-center max-w-2xl mx-auto">
          <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-xl bg-gray-900 border border-gray-800 text-gray-400">
            <Scale className="h-6 w-6" />
          </div>
          <h3 className="mt-4 text-base font-semibold text-white font-display">Karşılaştırma Listesi Boş</h3>
          <p className="mt-2 text-sm text-gray-400 max-w-sm mx-auto">
            Katalog sekmesine gidin ve yan yana kıyaslamak istediğiniz modern cihazların altındaki <strong>"Karşılaştır"</strong> butonuna tıklayarak listeye ekleyin (en fazla 3 ürün).
          </p>
          <div className="mt-6">
            <span className="inline-flex items-center gap-1.5 text-xs text-teal-400 font-mono font-bold animate-pulse bg-teal-950/40 border border-teal-800/50 px-3 py-1.5 rounded-full">
              <Sparkles className="h-3 w-3" />
              Yapay Zeka Karar Desteği Aktif
            </span>
          </div>
        </div>
      ) : (
        /* COMPARISON MATRIX CONTAINER */
        <div className="mt-8 space-y-8">
          
          {/* Comparison Grid */}
          <div className="overflow-x-auto rounded-xl border border-gray-800 bg-dark-card/40 backdrop-blur-sm">
            <table className="w-full min-w-[600px] border-collapse text-left">
              <thead>
                <tr className="border-b border-gray-800 bg-gray-900/40">
                  {/* First Column Header */}
                  <th className="p-4 text-xs font-mono text-gray-500 uppercase tracking-widest w-1/4">Donanım Metrikleri</th>
                  
                  {/* Product Columns Headers */}
                  {compareList.map(product => (
                    <th key={product.id} className="p-4 w-1/4 group relative">
                      <div className="flex flex-col space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-xs text-gray-400 bg-gray-900 border border-gray-800 rounded px-2 py-0.5 font-mono">
                            {product.category}
                          </span>
                          <button
                            id={`remove-compare-${product.id}`}
                            onClick={() => onRemove(product)}
                            className="rounded p-1 text-gray-500 hover:bg-gray-800 hover:text-red-400 transition-all"
                            title="Karşılaştırmadan çıkar"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </div>
                        <h4 className="font-display font-bold text-white text-base group-hover:text-teal-300 transition-all">
                          {product.name}
                        </h4>
                        <div className="text-sm font-semibold text-teal-400 font-mono">
                          {product.priceRange}
                        </div>
                        <button
                          id={`btn-view-spec-${product.id}`}
                          onClick={() => onViewDetails(product)}
                          className="mt-1 self-start text-[10px] text-gray-400 hover:text-white font-semibold underline"
                        >
                          Tam Ürün Kartı
                        </button>
                      </div>
                    </th>
                  ))}
                  
                  {/* Fill empty column slots if under 3 products */}
                  {compareList.length < 3 && 
                    Array.from({ length: 3 - compareList.length }).map((_, idx) => (
                      <th key={idx} className="p-4 w-1/4 text-center border-l border-gray-800/40">
                        <div className="flex flex-col items-center justify-center py-6 text-xs text-gray-600 space-y-1.5">
                          <PlusPlaceholder />
                          <span className="font-medium">Karşılaştırma Boşluğu</span>
                        </div>
                      </th>
                    ))
                  }
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-800/80">
                
                {/* 1. Taglines Row */}
                <tr className="hover:bg-gray-900/10">
                  <td className="p-4 text-xs font-mono text-gray-400 font-semibold uppercase">Konsept Sloganı</td>
                  {compareList.map(product => (
                    <td key={product.id} className="p-4 text-sm text-gray-300 italic font-mono leading-relaxed">
                      "{product.tagline}"
                    </td>
                  ))}
                  {compareList.length < 3 && Array.from({ length: 3 - compareList.length }).map((_, idx) => <td key={idx} className="p-4 border-l border-gray-800/40 bg-gray-950/10"></td>)}
                </tr>

                {/* 2. Technical Specs Row-by-Row Alignment */}
                {allSpecLabels.map((label, rowIdx) => (
                  <tr key={rowIdx} className="hover:bg-gray-900/10">
                    <td className="p-4 text-xs font-mono text-gray-400 font-semibold uppercase">{label}</td>
                    {compareList.map(product => {
                      const spec = product.specs.find(s => s.label === label);
                      return (
                        <td key={product.id} className="p-4 text-sm font-mono text-white font-semibold">
                          {spec ? spec.value : <span className="text-gray-600">-</span>}
                        </td>
                      );
                    })}
                    {compareList.length < 3 && Array.from({ length: 3 - compareList.length }).map((_, idx) => <td key={idx} className="p-4 border-l border-gray-800/40 bg-gray-950/10"></td>)}
                  </tr>
                ))}

                {/* 3. Pros Alignment Row */}
                <tr className="hover:bg-gray-900/10">
                  <td className="p-4 text-xs font-mono text-gray-400 font-semibold uppercase">Güçlü Yönler (Artılar)</td>
                  {compareList.map(product => (
                    <td key={product.id} className="p-4">
                      <ul className="space-y-1.5 text-xs text-emerald-400">
                        {product.pros.slice(0, 3).map((p, i) => (
                          <li key={i} className="flex items-start gap-1">
                            <span>•</span>
                            <span className="text-gray-300 leading-relaxed">{p}</span>
                          </li>
                        ))}
                      </ul>
                    </td>
                  ))}
                  {compareList.length < 3 && Array.from({ length: 3 - compareList.length }).map((_, idx) => <td key={idx} className="p-4 border-l border-gray-800/40 bg-gray-950/10"></td>)}
                </tr>

                {/* 4. Cons Alignment Row */}
                <tr className="hover:bg-gray-900/10">
                  <td className="p-4 text-xs font-mono text-gray-400 font-semibold uppercase">Limitasyonlar (Eksiler)</td>
                  {compareList.map(product => (
                    <td key={product.id} className="p-4">
                      <ul className="space-y-1.5 text-xs text-amber-500">
                        {product.cons.slice(0, 3).map((c, i) => (
                          <li key={i} className="flex items-start gap-1">
                            <span>•</span>
                            <span className="text-gray-300 leading-relaxed">{c}</span>
                          </li>
                        ))}
                      </ul>
                    </td>
                  ))}
                  {compareList.length < 3 && Array.from({ length: 3 - compareList.length }).map((_, idx) => <td key={idx} className="p-4 border-l border-gray-800/40 bg-gray-950/10"></td>)}
                </tr>

                {/* 5. Performance Metrics Rows with Winner Highlighted in Green */}
                {allPerformanceLabels.map((label, perfIdx) => {
                  const values = compareList.map(p => p.performanceMetrics.find(m => m.label === label)?.value ?? -1);
                  const maxValue = Math.max(...values);
                  
                  return (
                    <tr key={perfIdx} className="hover:bg-gray-900/10">
                      <td className="p-4 text-xs font-mono text-gray-400 font-semibold uppercase">{label} (Skor)</td>
                      {compareList.map(product => {
                        const metric = product.performanceMetrics.find(m => m.label === label);
                        const value = metric ? metric.value : -1;
                        const isBest = value > 0 && value === maxValue && compareList.length > 1;
                        
                        return (
                          <td key={product.id} className="p-4">
                            {value !== -1 ? (
                              <div className={`p-3 rounded-xl border transition-all duration-300 ${
                                isBest 
                                  ? 'bg-emerald-950/20 border-emerald-500/40 text-emerald-400 shadow-sm shadow-emerald-500/5' 
                                  : 'bg-gray-900/40 border-gray-800 text-gray-300'
                              }`}>
                                <div className="flex items-center justify-between text-xs mb-1.5">
                                  <span className={isBest ? 'text-emerald-400 font-semibold' : 'text-gray-400'}>Performans Gücü</span>
                                  <span className="font-mono font-bold">{value} / 100</span>
                                </div>
                                <div className="h-1.5 w-full bg-gray-950 rounded-full overflow-hidden">
                                  <div className={`h-full rounded-full transition-all duration-500 ${isBest ? 'bg-gradient-to-r from-emerald-500 to-teal-400' : 'bg-teal-600'}`} style={{ width: `${value}%` }} />
                                </div>
                                {isBest && (
                                  <div className="mt-1.5 text-[9px] font-bold text-emerald-400 font-mono tracking-wider uppercase flex items-center gap-1">
                                    <span className="animate-pulse">●</span> En Yüksek Skor
                                  </div>
                                )}
                              </div>
                            ) : (
                              <span className="text-gray-600 font-mono text-xs">-</span>
                            )}
                          </td>
                        );
                      })}
                      {compareList.length < 3 && Array.from({ length: 3 - compareList.length }).map((_, idx) => (
                        <td key={idx} className="p-4 border-l border-gray-800/40 bg-gray-950/10"></td>
                      ))}
                    </tr>
                  );
                })}

              </tbody>
            </table>
          </div>

          {/* RADAR CHART COMPARISON */}
          <div className="rounded-2xl border border-gray-800 bg-dark-card/35 p-6 backdrop-blur-sm">
            <div className="mb-4">
              <h3 className="font-display text-lg font-bold text-white flex items-center gap-2">
                <BarChart2 className="h-5 w-5 text-teal-400" />
                Donanım Güç Dengesi (Radar Analizi)
              </h3>
              <p className="text-xs text-gray-400 mt-0.5">
                Seçtiğiniz {compareList.length} cihazın Performans, Ekonomiklik, Dayanıklılık ve Özellik Zenginliği dengesini dairesel radar grafiğiyle karşılaştırın.
              </p>
            </div>
            
            <div className="w-full h-[320px] md:h-[380px] flex items-center justify-center bg-gray-900/10 rounded-xl p-2 border border-gray-800/40">
              <ResponsiveContainer width="100%" height="100%">
                <RadarChart cx="50%" cy="50%" outerRadius="75%" data={radarData}>
                  <PolarGrid stroke="#374151" />
                  <PolarAngleAxis dataKey="subject" stroke="#9ca3af" fontSize={11} fontFamily="Inter" />
                  <PolarRadiusAxis angle={30} domain={[0, 100]} stroke="#4b5563" fontSize={10} tickCount={6} />
                  {compareList.map((product, idx) => {
                    const colors = [
                      { stroke: '#2dd4bf', fill: '#2dd4bf' }, // Teal-400
                      { stroke: '#3b82f6', fill: '#3b82f6' }, // Blue-500
                      { stroke: '#10b981', fill: '#10b981' }  // Emerald-500
                    ];
                    const color = colors[idx % colors.length];
                    return (
                      <Radar
                        key={product.id}
                        name={product.name}
                        dataKey={product.name}
                        stroke={color.stroke}
                        fill={color.fill}
                        fillOpacity={0.25}
                      />
                    );
                  })}
                  <Tooltip content={<CustomRadarTooltip />} />
                  <Legend wrapperStyle={{ paddingTop: '20px', fontSize: '11px', color: '#9ca3af' }} />
                </RadarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* AI COMPARE REPORT SECTION */}
          <div className="mt-10 border border-teal-900/30 rounded-2xl bg-gradient-to-b from-teal-950/15 via-dark-card/50 to-dark-bg p-6">
            <div className="flex items-start sm:items-center justify-between flex-col sm:flex-row gap-4">
              <div>
                <h3 className="font-display text-lg font-bold text-white flex items-center gap-2">
                  <Sparkles className="h-5 w-5 text-teal-400 animate-pulse" />
                  TeknoAsistan AI Karşılaştırma Raporu
                </h3>
                <p className="text-sm text-gray-400 mt-0.5">
                  Seçtiğiniz {compareList.length} cihazı Gemini 3.1 Pro (HIGH Düşünme Seviyesi) ile en ince teknik detayına kadar karşılaştırın.
                </p>
              </div>

              <button
                id="btn-generate-ai-compare"
                onClick={handleGenerateAIReport}
                disabled={compareList.length < 2 || loading}
                className="rounded-xl bg-gradient-to-r from-teal-500 to-emerald-500 hover:from-teal-600 hover:to-emerald-600 px-5 py-3 text-sm font-bold text-dark-bg transition-all disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-2 whitespace-nowrap"
              >
                {loading ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin text-dark-bg" />
                    Analiz Ediliyor...
                  </>
                ) : (
                  <>
                    <Terminal className="h-4 w-4" />
                    AI Karşılaştırma Raporu Oluştur
                  </>
                )}
              </button>
            </div>

            {/* AI LOADING PROGRESS DISPLAY */}
            {loading && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-6 border border-teal-800/40 bg-teal-950/20 rounded-xl p-4 flex items-center gap-3"
              >
                <div className="relative flex h-8 w-8 items-center justify-center">
                  <div className="absolute h-full w-full rounded-full border-2 border-teal-500/20 border-t-teal-400 animate-spin" />
                  <Sparkles className="h-3.5 w-3.5 text-teal-400 animate-pulse" />
                </div>
                <div className="space-y-1">
                  <div className="text-xs font-mono font-bold text-teal-400 uppercase tracking-widest">Yapay Zeka Muhakemesi Sürüyor</div>
                  <div className="text-sm text-gray-300 font-mono italic animate-pulse">{loadingStatus}</div>
                </div>
              </motion.div>
            )}

            {/* AI SYSTEM ERROR */}
            {error && (
              <div className="mt-6 border border-red-900/40 bg-red-950/20 rounded-xl p-4 text-sm text-red-400 flex flex-col gap-2">
                <div className="font-bold font-display flex items-center gap-2">
                  <ShieldAlert className="h-4 w-4 text-red-500" />
                  Rapor Alınamadı!
                </div>
                <p>{error}</p>
                <p className="text-xs text-gray-500 mt-1">Lütfen tarayıcıyı yenileyin veya API Anahtarınızın geçerliliğini kontrol edin.</p>
              </div>
            )}

            {/* AI COMPARED RESULT DISPLAY */}
            {aiReport && (
              <motion.div
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="mt-6 divide-y divide-gray-800/80 space-y-6"
              >
                {/* Row 1: AI Summaries */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 pt-4">
                  {compareList.map(product => (
                    <div key={product.id} className="rounded-xl border border-gray-800 bg-gray-900/30 p-4">
                      <h4 className="text-xs font-mono font-bold text-teal-400 mb-2 uppercase tracking-wide">
                        {product.name} Analizi
                      </h4>
                      <p className="text-xs text-gray-300 leading-relaxed">
                        {aiReport.summaries[product.id] || "Analiz oluşturulamadı."}
                      </p>
                    </div>
                  ))}
                </div>

                {/* Row 2: Key Differences */}
                <div className="pt-6">
                  <h4 className="text-sm font-display font-bold text-white mb-3 flex items-center gap-1.5">
                    <span className="h-1.5 w-1.5 rounded-full bg-teal-400" />
                    Temel Teknik ve Donanımsal Farklar
                  </h4>
                  <ul className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {aiReport.keyDifferences.map((diff, index) => (
                      <li key={index} className="flex items-start gap-2 text-xs border border-gray-800/40 bg-gray-900/10 rounded-lg p-2.5">
                        <ArrowRight className="h-3.5 w-3.5 text-teal-500 mt-0.5 shrink-0" />
                        <span className="text-gray-300 leading-relaxed">{diff}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Row 3: Scenarios & Final Verdict */}
                <div className="pt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="rounded-xl border border-blue-500/10 bg-blue-500/[0.02] p-4">
                    <h5 className="font-display text-xs font-bold text-blue-400 mb-2 uppercase tracking-wide">
                      Maksimum Güç, Yapay Zeka veya Profesyonel İşçilik
                    </h5>
                    <p className="text-xs text-gray-300 leading-relaxed">
                      {aiReport.useCaseVerdict.scenarioGamingOrAI}
                    </p>
                  </div>

                  <div className="rounded-xl border border-teal-500/10 bg-teal-500/[0.02] p-4">
                    <h5 className="font-display text-xs font-bold text-teal-400 mb-2 uppercase tracking-wide">
                      Mobilite, Günlük Yaşam veya Pratik Kullanım
                    </h5>
                    <p className="text-xs text-gray-300 leading-relaxed">
                      {aiReport.useCaseVerdict.scenarioMobilityOrDaily}
                    </p>
                  </div>

                  <div className="md:col-span-2 rounded-xl border border-emerald-500/20 bg-emerald-950/10 p-4">
                    <h5 className="font-display text-xs font-bold text-emerald-400 mb-1.5 uppercase tracking-wide">
                      TeknoAsistan Uzman Nihai Değerlendirmesi
                    </h5>
                    <p className="text-xs text-gray-200 leading-relaxed italic">
                      "{aiReport.useCaseVerdict.scenarioVerdictSummary}"
                    </p>
                  </div>
                </div>

              </motion.div>
            )}

          </div>

        </div>
      )}

    </div>
  );
}

function PlusPlaceholder() {
  return (
    <svg className="h-5 w-5 text-gray-700" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4" />
    </svg>
  );
}
