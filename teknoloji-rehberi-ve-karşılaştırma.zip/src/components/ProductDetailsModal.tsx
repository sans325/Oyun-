import React, { useState, useEffect } from 'react';
import { Product, MarketplaceStore } from '../data/products';
import { X, Check, AlertTriangle, Cpu, BarChart2, ShoppingCart, Star, Clock, Sparkles, Download, Bell, Mail, ChevronRight, TrendingDown, MessageSquare } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import UserReviews from './UserReviews';
import GlossaryTerm from './GlossaryTerm';

interface ProductDetailsModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToCompare: (product: Product) => void;
  isComparing: boolean;
  isCompareDisabled: boolean;
  onPurchaseSimulate: (product: Product, store: MarketplaceStore) => void;
}

type TabType = 'overview' | 'specs' | 'marketplace' | 'trend' | 'reviews';

export default function ProductDetailsModal({
  product,
  onClose,
  onAddToCompare,
  isComparing,
  isCompareDisabled,
  onPurchaseSimulate
}: ProductDetailsModalProps) {
  const [activeSubTab, setActiveSubTab] = useState<TabType>('overview');

  // Interactive local states for alerts and downloads
  const [email, setEmail] = useState('');
  const [targetPrice, setTargetPrice] = useState<number>(0);
  const [alertSuccess, setAlertSuccess] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  const [initializedId, setInitializedId] = useState<string | null>(null);
  const [activeAlerts, setActiveAlerts] = useState<any[]>([]);

  // Active price alerts loader hook (placed above early return to respect React rules)
  useEffect(() => {
    if (product) {
      try {
        const stored = localStorage.getItem('tekno_price_alerts');
        if (stored) {
          const allAlerts = JSON.parse(stored);
          setActiveAlerts(allAlerts.filter((alert: any) => alert.productId === product.id));
        } else {
          setActiveAlerts([]);
        }
      } catch (e) {
        console.error("Fiyat alarmları yüklenemedi:", e);
      }
    }
  }, [product?.id, alertSuccess]);

  // Delete an active alert helper
  const handleDeleteAlert = (alertToDelete: any) => {
    try {
      const stored = localStorage.getItem('tekno_price_alerts');
      if (stored) {
        const allAlerts = JSON.parse(stored);
        const updated = allAlerts.filter((alert: any) => 
          !(alert.productId === alertToDelete.productId && 
            alert.email === alertToDelete.email && 
            alert.targetPrice === alertToDelete.targetPrice)
        );
        localStorage.setItem('tekno_price_alerts', JSON.stringify(updated));
        // Refresh local list
        setActiveAlerts(updated.filter((alert: any) => alert.productId === product?.id));
      }
    } catch (e) {
      console.error("Alarm silinemedi:", e);
    }
  };

  if (!product) return null;

  // Sync state initialization whenever a different product is opened
  if (product && initializedId !== product.id) {
    const lowest = product.marketplace.reduce((min, item) => (item.price < min.price ? item : min), product.marketplace[0]).price;
    setTargetPrice(Math.round(lowest * 0.9));
    setEmail('');
    setAlertSuccess(false);
    setInitializedId(product.id);
  }

  // Monthly Price fluctuation generator for Recharts
  const lowestPrice = product.marketplace.reduce((min, item) => (item.price < min.price ? item : min), product.marketplace[0]).price;
  const generatePriceHistory = (base: number) => {
    const months = ['Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz'];
    const multipliers = [1.06, 1.04, 1.09, 1.01, 1.03, 1.00];
    return months.map((m, idx) => ({
      name: m,
      fiyat: Math.round(base * multipliers[idx])
    }));
  };
  const priceHistoryData = generatePriceHistory(lowestPrice);

  // Generate and download summarized technical & sentiment analysis report as TXT
  const handleDownloadReport = () => {
    setIsDownloading(true);

    const highestPrice = product.marketplace.reduce((max, item) => (item.price > max.price ? item : max), product.marketplace[0]).price;

    const reportContent = `======================================================================
           TEKNOANALİZ TEKNİK DEĞERLENDİRME VE ANALİZ RAPORU
======================================================================
Cihaz Adı            : ${product.name}
Kategori             : ${product.category}
Konsept Sloganı      : "${product.tagline}"
Rapor Tarihi         : ${new Date().toLocaleDateString('tr-TR')}
Durum                : Doğrulanmış Teknik Analiz Raporu
======================================================================

1. ÜRÜN TANITIMI VE GENEL ANALİZ
----------------------------------------------------------------------
${product.longDescription}

2. GÜÇLÜ VE ZAYIF YÖNLER (ARTILAR VE EKSİLER)
----------------------------------------------------------------------
Artıları (Güçlü Yönleri):
${product.pros.map(p => `  [+] ${p}`).join('\n')}

Eksileri (Limitasyonları):
${product.cons.map(c => `  [-] ${c}`).join('\n')}

3. DONANIM ÖZELLİKLERİ VE YAPILANDIRMASI
----------------------------------------------------------------------
${product.specs.map(s => `  * ${s.label.padEnd(25)}: ${s.value}`).join('\n')}

4. TEKNİK PERFORMANS METRİKLERİ VE SKORLARI (0-100)
----------------------------------------------------------------------
${product.performanceMetrics.map(m => `  * ${m.label.padEnd(25)}: ${m.value} / 100`).join('\n')}

5. PAZAR YERİ VE TEDARİKÇİ FİYATLARI (USD)
----------------------------------------------------------------------
En Düşük Fiyat       : $${lowestPrice.toLocaleString()}
En Yüksek Fiyat      : $${highestPrice.toLocaleString()}

Aktif Tedarikçi Mağazaları:
${product.marketplace.map(m => `  - ${m.storeName.padEnd(20)}: $${m.price.toLocaleString()} (${m.deliveryDays} Gün Teslimat, Stok: ${m.stockStatus === 'InStock' ? 'Mevcut' : 'Son Ürünler'})`).join('\n')}

6. KULLANICI DUYGU & GERİBİLDİRİM ANALİZİ (SENTIMENT)
----------------------------------------------------------------------
Genel Duygu Skoru    : %94 Pozitif | %4 Nötr | %2 Negatif

Kullanıcı Yorum Özeti:
"Erken aşama kullanıcı geri bildirimleri, ürünün donanımsal hassasiyetini ve ergonomik mühendisliğini tam puanla ödüllendiriyor. Kullanıcılar, özellikle malzeme kalitesinden ve vaat edilen performans kararlılığından son derece memnun. Az sayıdaki eleştiri ise premium fiyat baremine ve ambalaj içeriğinin ekosistem aksesuarları içermemesine yönelik."

7. TEKNOASİSTAN AI YATIRIM TAVSİYESİ
----------------------------------------------------------------------
"Seçilen cihaz, kendi segmentindeki en yeni donanım standartlarını başarıyla karşılıyor. Eğer bütçeniz elveriyorsa, uzun vadeli gelecek odaklılık skoru göz önüne alındığında, bu cihaz teknolojik olgunluk açısından son derece güvenli ve karlı bir donanım yatırımıdır."

----------------------------------------------------------------------
                   TEKNOANALİZ - Geleceğin Portalı
======================================================================`;

    const blob = new Blob([reportContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${product.id}-teknik-analiz-raporu.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    setTimeout(() => {
      setIsDownloading(false);
    }, 800);
  };

  const handleSaveAlert = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;

    const newAlert = {
      productId: product.id,
      productName: product.name,
      email: email,
      targetPrice: targetPrice,
      createdAt: new Date().toISOString()
    };

    const existingAlertsStr = localStorage.getItem('tekno_price_alerts');
    const existingAlerts = existingAlertsStr ? JSON.parse(existingAlertsStr) : [];
    
    // Check for duplicate alert configurations
    const isDuplicate = existingAlerts.some((alert: any) => 
      alert.productId === newAlert.productId && 
      alert.email === newAlert.email && 
      alert.targetPrice === newAlert.targetPrice
    );

    if (!isDuplicate) {
      existingAlerts.push(newAlert);
      localStorage.setItem('tekno_price_alerts', JSON.stringify(existingAlerts));
    }

    setAlertSuccess(true);
    setTimeout(() => {
      setAlertSuccess(false);
      setEmail('');
    }, 4000);
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto">
        
        {/* Modal Panel Container */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          transition={{ type: 'spring', duration: 0.4 }}
          className="relative w-full max-w-4xl rounded-2xl border border-gray-800 bg-dark-bg text-white shadow-2xl overflow-hidden flex flex-col my-8"
        >
          {/* Header background decoration */}
          <div className="absolute top-0 left-0 right-0 h-32 bg-gradient-to-b from-teal-500/10 via-transparent to-transparent -z-10" />

          {/* Modal Header */}
          <div className="flex items-start justify-between p-6 border-b border-gray-800/80">
            <div>
              <div className="flex items-center gap-2">
                <span className="inline-flex items-center rounded-full bg-teal-950/80 text-teal-400 border border-teal-800 px-2.5 py-0.5 text-xs font-semibold font-display">
                  {product.category}
                </span>
                <span className="font-mono text-xs text-gray-400">ID: {product.id}</span>
              </div>
              <h2 className="mt-2 font-display text-2xl sm:text-3xl font-bold text-white tracking-tight">
                {product.name}
              </h2>
              <p className="mt-1 text-sm text-teal-400/90 font-mono italic">
                "{product.tagline}"
              </p>
            </div>
            
            <button
              id="btn-close-modal"
              onClick={onClose}
              className="rounded-lg p-2 text-gray-400 hover:bg-gray-800 hover:text-white transition-all"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          {/* Navigation Sub-Tabs */}
          <div className="flex border-b border-gray-800 bg-gray-900/30 px-6 overflow-x-auto whitespace-nowrap scrollbar-none">
            <button
              id="subtab-overview"
              onClick={() => setActiveSubTab('overview')}
              className={`flex items-center gap-2 py-3 px-4 text-sm font-semibold border-b-2 shrink-0 whitespace-nowrap transition-all ${
                activeSubTab === 'overview'
                  ? 'border-teal-500 text-teal-400'
                  : 'border-transparent text-gray-400 hover:text-white'
              }`}
            >
              <Cpu className="h-4 w-4" />
              Genel Bakış
            </button>
            <button
              id="subtab-specs"
              onClick={() => setActiveSubTab('specs')}
              className={`flex items-center gap-2 py-3 px-4 text-sm font-semibold border-b-2 shrink-0 whitespace-nowrap transition-all ${
                activeSubTab === 'specs'
                  ? 'border-teal-500 text-teal-400'
                  : 'border-transparent text-gray-400 hover:text-white'
              }`}
            >
              <BarChart2 className="h-4 w-4" />
              Teknik Analiz & Metrikler
            </button>
            <button
              id="subtab-marketplace"
              onClick={() => setActiveSubTab('marketplace')}
              className={`flex items-center gap-2 py-3 px-4 text-sm font-semibold border-b-2 shrink-0 whitespace-nowrap transition-all ${
                activeSubTab === 'marketplace'
                  ? 'border-teal-500 text-teal-400'
                  : 'border-transparent text-gray-400 hover:text-white'
              }`}
            >
              <ShoppingCart className="h-4 w-4" />
              Pazar Yeri Fiyatları
            </button>
            <button
              id="subtab-trend"
              onClick={() => setActiveSubTab('trend')}
              className={`flex items-center gap-2 py-3 px-4 text-sm font-semibold border-b-2 shrink-0 whitespace-nowrap transition-all ${
                activeSubTab === 'trend'
                  ? 'border-teal-500 text-teal-400'
                  : 'border-transparent text-gray-400 hover:text-white'
              }`}
            >
              <Clock className="h-4 w-4" />
              Fiyat Trendi & Alarm
            </button>
            <button
              id="subtab-reviews"
              onClick={() => setActiveSubTab('reviews')}
              className={`flex items-center gap-2 py-3 px-4 text-sm font-semibold border-b-2 shrink-0 whitespace-nowrap transition-all ${
                activeSubTab === 'reviews'
                  ? 'border-teal-500 text-teal-400'
                  : 'border-transparent text-gray-400 hover:text-white'
              }`}
            >
              <MessageSquare className="h-4 w-4" />
              Değerlendirmeler
            </button>
          </div>

          {/* Scrollable Content */}
          <div className="p-6 overflow-y-auto max-h-[55vh]">
            
            {/* OVERVIEW TAB */}
            {activeSubTab === 'overview' && (
              <div className="space-y-6">
                <div>
                  <h3 className="text-xs font-mono text-gray-500 uppercase tracking-widest mb-2">Geliştirici & Ürün Tanıtımı</h3>
                  <p className="text-gray-300 leading-relaxed text-base">
                    {product.longDescription}
                  </p>
                </div>

                {/* Pros and Cons Columns */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4">
                  {/* Pros */}
                  <div className="rounded-xl border border-emerald-500/10 bg-emerald-500/[0.02] p-4">
                    <h4 className="flex items-center gap-2 font-display text-sm font-bold text-emerald-400 mb-3">
                      <Check className="h-4 w-4 text-emerald-500" />
                      Artıları / Güçlü Yönleri
                    </h4>
                    <ul className="space-y-2 text-xs text-gray-300">
                      {product.pros.map((pro, index) => (
                        <li key={index} className="flex items-start gap-2 leading-relaxed">
                          <span className="text-emerald-500 font-bold">•</span>
                          <span>{pro}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Cons */}
                  <div className="rounded-xl border border-amber-500/10 bg-amber-500/[0.02] p-4">
                    <h4 className="flex items-center gap-2 font-display text-sm font-bold text-amber-400 mb-3">
                      <AlertTriangle className="h-4 w-4 text-amber-500" />
                      Eksileri / Limitasyonları
                    </h4>
                    <ul className="space-y-2 text-xs text-gray-300">
                      {product.cons.map((con, index) => (
                        <li key={index} className="flex items-start gap-2 leading-relaxed">
                          <span className="text-amber-500 font-bold">•</span>
                          <span>{con}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            )}

            {/* SPECS & METRICS TAB */}
            {activeSubTab === 'specs' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                
                {/* Specs List */}
                <div className="space-y-4">
                  <h3 className="text-xs font-mono text-gray-500 uppercase tracking-widest mb-2">Detaylı Donanım Özellikleri</h3>
                  <div className="divide-y divide-gray-800 border-t border-b border-gray-800">
                    {product.specs.map((spec, idx) => (
                      <div key={idx} className="flex justify-between py-2.5 text-sm">
                        <span className="text-gray-400 font-medium">
                          <GlossaryTerm>{spec.label}</GlossaryTerm>
                        </span>
                        <span className="text-white font-semibold font-mono text-right max-w-[60%]">
                          <GlossaryTerm>{spec.value}</GlossaryTerm>
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Performance Metrics Progress Bars */}
                <div>
                  <h3 className="text-xs font-mono text-gray-500 uppercase tracking-widest mb-4">Teknik Performans Dağılımı</h3>
                  <div className="space-y-4">
                    {product.performanceMetrics.map((metric, idx) => (
                      <div key={idx} className="space-y-1.5">
                        <div className="flex items-center justify-between text-xs font-medium">
                          <span className="text-gray-300">{metric.label}</span>
                          <span className="text-teal-400 font-mono font-bold">{metric.value} / 100</span>
                        </div>
                        {/* Progress Bar Container */}
                        <div className="h-2 w-full rounded-full bg-gray-900 overflow-hidden border border-gray-800/50">
                          <motion.div
                            initial={{ width: 0 }}
                            animate={{ width: `${metric.value}%` }}
                            transition={{ duration: 0.8, delay: 0.1 }}
                            className={`h-full rounded-full bg-gradient-to-r ${
                              metric.value >= 85
                                ? 'from-teal-500 to-emerald-400'
                                : metric.value >= 60
                                ? 'from-blue-500 to-teal-500'
                                : 'from-amber-500 to-orange-500'
                            }`}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

              </div>
            )}

            {/* MARKETPLACE TAB */}
            {activeSubTab === 'marketplace' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-mono text-gray-500 uppercase tracking-widest">
                    Doğrudan Pazar Yeri Satıcıları
                  </h3>
                  <span className="text-xs text-gray-400 font-mono">
                    *Fiyatlar USD bazında karşılaştırılmıştır.
                  </span>
                </div>

                <div className="grid grid-cols-1 gap-3">
                  {product.marketplace.map((store) => (
                    <div
                      key={store.id}
                      className="flex flex-col sm:flex-row sm:items-center sm:justify-between rounded-xl border border-gray-800 bg-gray-900/40 p-4 transition-all hover:border-teal-500/30 hover:bg-gray-900/60"
                    >
                      {/* Left: Store Name and Rating */}
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="font-display font-bold text-white text-base">
                            {store.storeName}
                          </span>
                          <span className="inline-flex items-center gap-1 text-[10px] bg-yellow-500/10 text-yellow-400 px-1.5 py-0.5 rounded border border-yellow-500/20 font-mono">
                            <Star className="h-2.5 w-2.5 fill-current" />
                            {store.rating.toFixed(1)}
                          </span>
                        </div>
                        <div className="flex items-center gap-3 text-xs text-gray-400 font-mono">
                          <span className="flex items-center gap-1">
                            <Clock className="h-3 w-3 text-teal-500" />
                            {store.deliveryDays} günde teslimat
                          </span>
                          <span>•</span>
                          <span className="flex items-center gap-1.5">
                            <span className={`h-1.5 w-1.5 rounded-full ${
                              store.stockStatus === 'InStock'
                                ? 'bg-emerald-500'
                                : store.stockStatus === 'LowStock'
                                ? 'bg-amber-500'
                                : 'bg-red-500'
                            }`} />
                            {store.stockStatus === 'InStock' ? 'Stokta Var' : store.stockStatus === 'LowStock' ? 'Son Ürünler!' : 'Tükendi'}
                          </span>
                        </div>
                      </div>

                      {/* Right: Price and Action Button */}
                      <div className="mt-4 sm:mt-0 flex items-center justify-between sm:justify-end gap-4 border-t sm:border-t-0 border-gray-800/80 pt-3 sm:pt-0">
                        <div className="text-left sm:text-right">
                          <div className="text-xs text-gray-500 font-mono">Pazar Yeri Fiyatı</div>
                          <div className="text-xl font-bold font-mono text-teal-400">
                            ${store.price.toLocaleString()}
                          </div>
                        </div>
                        <button
                          id={`btn-buy-${store.id}`}
                          onClick={() => onPurchaseSimulate(product, store)}
                          className="rounded-xl bg-gradient-to-r from-teal-500 to-emerald-500 hover:from-teal-600 hover:to-emerald-600 px-4 py-2 text-xs font-bold text-dark-bg transition-all flex items-center gap-1.5"
                        >
                          Mağazaya Git
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TREND & ALERTS TAB */}
            {activeSubTab === 'trend' && (
              <div className="space-y-6">
                {/* Recharts Price Trend Plot */}
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <div>
                      <h3 className="text-xs font-mono text-gray-500 uppercase tracking-widest">
                        6 Aylık Tarihsel Fiyat Trendi
                      </h3>
                      <p className="text-xs text-gray-400 mt-0.5">Cihazın son 6 aydaki minimum pazar yeri fiyat dalgalanması</p>
                    </div>
                    <span className="text-[10px] bg-teal-950/50 border border-teal-800/50 text-teal-400 px-2.5 py-1 rounded-md font-mono">
                      Son Fiyat: ${lowestPrice} USD
                    </span>
                  </div>

                  <div className="h-64 w-full bg-gray-900/40 rounded-xl border border-gray-800/80 p-4">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={priceHistoryData} margin={{ top: 10, right: 10, left: -15, bottom: 0 }}>
                        <defs>
                          <linearGradient id="colorPriceDetails" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#14b8a6" stopOpacity={0.25}/>
                            <stop offset="95%" stopColor="#14b8a6" stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" stroke="#1f2937" vertical={false} />
                        <XAxis dataKey="name" stroke="#6b7280" fontSize={11} tickLine={false} axisLine={false} />
                        <YAxis stroke="#6b7280" fontSize={11} tickLine={false} axisLine={false} domain={['auto', 'auto']} />
                        <Tooltip 
                          contentStyle={{ backgroundColor: '#111827', borderColor: '#374151', borderRadius: '0.75rem' }} 
                          labelClassName="text-gray-400 text-xs font-mono font-bold"
                          itemStyle={{ color: '#14b8a6', fontSize: '12px' }}
                        />
                        <Area type="monotone" dataKey="fiyat" stroke="#14b8a6" strokeWidth={2.5} fillOpacity={1} fill="url(#colorPriceDetails)" />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                {/* Grid for Price Drop Alerts & Report Download */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Price Drop Alert Form */}
                  <div className="rounded-xl border border-gray-800 bg-gray-950/30 p-4 space-y-4">
                    <h4 className="font-display text-sm font-bold text-white flex items-center gap-1.5">
                      <Bell className="h-4 w-4 text-teal-400" />
                      Fiyat Düşüş Alarmı Kur
                    </h4>
                    <p className="text-xs text-gray-400">
                      Cihazın fiyatı belirlediğiniz hedef fiyatın altına düştüğünde anında e-posta bildirimi alın.
                    </p>

                    {alertSuccess ? (
                      <motion.div
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className="rounded-lg bg-emerald-950/30 border border-emerald-800/40 p-3.5 text-xs text-emerald-400 flex items-start gap-2.5"
                      >
                        <Check className="h-4 w-4 text-emerald-400 shrink-0 mt-0.5" />
                        <div>
                          <div className="font-bold">Fiyat Alarmı Etkinleştirildi!</div>
                          <p className="text-gray-300 mt-1">
                            Fiyat <strong>${targetPrice} USD</strong> altına indiğinde <strong>{email}</strong> adresine bildirim gönderilecektir.
                          </p>
                        </div>
                      </motion.div>
                    ) : (
                      <form onSubmit={handleSaveAlert} className="space-y-3">
                        {/* Target Price */}
                        <div>
                          <div className="flex justify-between text-xs font-mono mb-1.5">
                            <span className="text-gray-400">Hedef Fiyat:</span>
                            <span className="text-teal-400 font-bold">${targetPrice} USD</span>
                          </div>
                          <input
                            type="range"
                            min={Math.round(lowestPrice * 0.5)}
                            max={lowestPrice}
                            value={targetPrice}
                            onChange={(e) => setTargetPrice(parseInt(e.target.value))}
                            className="w-full accent-teal-500 h-1.5 bg-gray-800 rounded-lg cursor-pointer"
                          />
                        </div>

                        {/* Email Input */}
                        <div>
                          <label className="block text-[10px] font-mono text-gray-400 mb-1">Bildirim E-posta Adresi:</label>
                          <div className="relative">
                            <Mail className="absolute left-3 top-2.5 h-4 w-4 text-gray-500" />
                            <input
                              type="email"
                              required
                              placeholder="sans.dell340@gmail.com"
                              value={email}
                              onChange={(e) => setEmail(e.target.value)}
                              className="w-full rounded-xl border border-gray-800 bg-gray-900/60 pl-9 pr-4 py-2 text-xs text-white placeholder-gray-600 focus:border-teal-500 focus:outline-none focus:ring-1 focus:ring-teal-500"
                            />
                          </div>
                        </div>

                        <button
                          type="submit"
                          className="w-full rounded-xl bg-teal-500 hover:bg-teal-600 py-2 text-xs font-bold text-dark-bg transition-all flex items-center justify-center gap-1.5"
                        >
                          <TrendingDown className="h-4 w-4" />
                          Alarmı Etkinleştir
                        </button>
                      </form>
                    )}

                    {/* Active Alarms List */}
                    {activeAlerts.length > 0 && (
                      <div className="border-t border-gray-800/60 pt-4 mt-4 space-y-2.5">
                        <div className="text-[10px] font-mono font-bold text-gray-500 uppercase tracking-widest">
                          Aktif Alarmlarınız ({activeAlerts.length})
                        </div>
                        <div className="space-y-1.5 max-h-32 overflow-y-auto pr-1">
                          {activeAlerts.map((alert, idx) => (
                            <div 
                              key={idx} 
                              className="flex items-center justify-between rounded-lg bg-gray-900/40 border border-gray-800/50 px-2.5 py-1.5 text-[11px]"
                            >
                              <div className="truncate pr-2">
                                <span className="font-semibold text-teal-400 font-mono">${alert.targetPrice}</span>
                                <span className="text-gray-400 mx-1.5">•</span>
                                <span className="text-gray-400 truncate font-mono">{alert.email}</span>
                              </div>
                              <button
                                type="button"
                                onClick={() => handleDeleteAlert(alert)}
                                className="text-gray-500 hover:text-red-400 p-0.5 rounded transition-all shrink-0"
                                title="Alarmı Sil"
                              >
                                <X className="h-3 w-3" />
                              </button>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Report Download Section */}
                  <div className="rounded-xl border border-gray-800 bg-gray-950/30 p-4 flex flex-col justify-between">
                    <div className="space-y-3">
                      <h4 className="font-display text-sm font-bold text-white flex items-center gap-1.5">
                        <Download className="h-4 w-4 text-teal-400" />
                        Teknik Analiz Raporunu İndir
                      </h4>
                      <p className="text-xs text-gray-400 leading-relaxed">
                        Cihazın donanım şemasını, artıları/eksilerini, pazar yeri fiyatlarını ve derin yapay zeka kullanıcı duygu analizi özetini içeren kapsamlı bir rapor dosyasını indirin.
                      </p>
                      
                      {/* Sentiment metrics badges */}
                      <div className="rounded-lg bg-gray-900/50 border border-gray-800/80 p-2.5 flex items-center justify-between text-[11px] font-mono">
                        <span className="text-gray-400">Kullanıcı Duygusu (AI):</span>
                        <div className="flex gap-2">
                          <span className="text-emerald-400 font-bold">%94 Olumlu</span>
                          <span className="text-gray-500">|</span>
                          <span className="text-gray-400">%4 Nötr</span>
                        </div>
                      </div>
                    </div>

                    <button
                      onClick={handleDownloadReport}
                      disabled={isDownloading}
                      className="mt-4 w-full rounded-xl border border-teal-500/30 bg-teal-500/10 text-teal-400 hover:bg-teal-500/20 py-2.5 text-xs font-bold transition-all flex items-center justify-center gap-1.5"
                    >
                      {isDownloading ? (
                        <>
                          <div className="h-4 w-4 rounded-full border-2 border-teal-500 border-t-transparent animate-spin" />
                          Rapor Derleniyor...
                        </>
                      ) : (
                        <>
                          <Download className="h-4 w-4" />
                          Detaylı Teknik Raporu İndir (.TXT)
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            )}

            {activeSubTab === 'reviews' && (
              <UserReviews product={product} />
            )}

          </div>

          {/* Modal Footer */}
          <div className="p-6 bg-gray-900/30 border-t border-gray-800 flex items-center justify-between flex-wrap gap-4">
            <div className="flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-teal-400 animate-pulse" />
              <span className="text-xs text-gray-400">Pazar yerlerimiz bağımsız tedarikçilerden doğrulanmaktadır.</span>
            </div>

            <div className="flex items-center gap-2">
              <button
                id="btn-compare-modal"
                onClick={() => onAddToCompare(product)}
                disabled={!isComparing && isCompareDisabled}
                className={`rounded-xl border px-4 py-2 text-xs font-semibold transition-all ${
                  isComparing
                    ? 'bg-teal-500 border-teal-500 text-dark-bg hover:bg-teal-600'
                    : isCompareDisabled
                    ? 'border-gray-800 text-gray-600 cursor-not-allowed bg-transparent'
                    : 'border-gray-700 text-gray-300 hover:border-teal-500 hover:text-teal-400 bg-transparent'
                }`}
              >
                {isComparing ? 'Karşılaştırmadan Çıkar' : 'Karşılaştırmaya Ekle'}
              </button>
              
              <button
                id="btn-close-modal-bottom"
                onClick={onClose}
                className="rounded-xl bg-gray-800 border border-gray-700 hover:bg-gray-700 px-4 py-2 text-xs font-semibold transition-all"
              >
                Kapat
              </button>
            </div>
          </div>

        </motion.div>
      </div>
    </AnimatePresence>
  );
}
