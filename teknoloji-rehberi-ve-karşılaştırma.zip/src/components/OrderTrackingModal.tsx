import React, { useState, useEffect } from 'react';
import { 
  X, ShoppingBag, Truck, Check, Clock, RefreshCw, Smartphone, 
  Landmark, Wallet, CreditCard, Trash2, ArrowRight, ExternalLink, 
  FileText, RotateCcw
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { generateInvoicePDF, InvoiceData } from '../utils/pdfGenerator';

export interface Order {
  id: string; // trackingNumber
  productId: string;
  productName: string;
  productImage: string;
  storeName: string;
  totalPrice: number;
  fullName: string;
  address: string;
  paymentMethod: 'card' | 'bank' | 'crypto' | 'mobile';
  paymentDetails: {
    cardNumber?: string;
    cardHolder?: string;
    bankName?: string;
    senderName?: string;
    currency?: string;
    network?: string;
    wallet?: string;
    phone?: string;
    carrier?: string;
  };
  shippingMethod: 'standard' | 'express';
  status: 'ordered' | 'preparing' | 'shipped' | 'delivered';
  orderDate: string;
  estimatedDelivery: string;
  history: { status: string; date: string; description: string }[];
  basePrice?: number;
  tax?: number;
  shippingCost?: number;
  warrantyCost?: number;
  specs?: { label: string; value: string }[];
}

interface OrderTrackingModalProps {
  isOpen: boolean;
  onClose: () => void;
  orders: Order[];
  onCancelOrder: (id: string) => void;
  onClearHistory: () => void;
  onRepeatPurchase?: (productId: string, storeName: string) => void;
  onViewProduct?: (productId: string) => void;
}

// Live calculation helper to simulate delivery logistics progress in real-time
export function getOrderLiveStatus(orderDateStr: string, shippingMethod: 'standard' | 'express') {
  const orderTime = new Date(orderDateStr).getTime();
  const now = Date.now();
  const elapsedSecs = (now - orderTime) / 1000;

  // Timing limits (in seconds) for demonstration purposes
  const isExpress = shippingMethod === 'express';
  const prepLimit = isExpress ? 15 : 35;
  const shipLimit = isExpress ? 45 : 100;
  const delLimit = isExpress ? 110 : 240;

  if (elapsedSecs < prepLimit) {
    return {
      status: 'ordered' as const,
      label: 'Sipariş Alındı',
      percent: 20,
      color: 'text-indigo-400 bg-indigo-500/10 border-indigo-500/20',
      description: 'Ödemeniz güvenli sunucuda başarıyla doğrulandı. Sipariş detaylarınız satıcıya iletildi.',
      history: [
        { status: 'Sipariş Alındı', date: new Date(orderTime).toLocaleTimeString('tr-TR'), description: 'Ödeme onaylandı ve sipariş kaydı başarıyla oluşturuldu.' }
      ]
    };
  } else if (elapsedSecs < shipLimit) {
    return {
      status: 'preparing' as const,
      label: 'Hazırlanıyor',
      percent: 50,
      color: 'text-amber-400 bg-amber-500/10 border-amber-500/20',
      description: 'Cihazınızın paketleme ve seri numarası eşleme işlemleri yapılıyor. Faturanız düzenleniyor.',
      history: [
        { status: 'Sipariş Alındı', date: new Date(orderTime).toLocaleTimeString('tr-TR'), description: 'Ödeme onaylandı ve sipariş kaydı başarıyla oluşturuldu.' },
        { status: 'Hazırlanıyor', date: new Date(orderTime + prepLimit * 1000).toLocaleTimeString('tr-TR'), description: 'Güvenli koruyucu paketleme uygulandı. Fatura ve garanti belgesi basıldı.' }
      ]
    };
  } else if (elapsedSecs < delLimit) {
    return {
      status: 'shipped' as const,
      label: 'Kargoya Verildi',
      percent: 80,
      color: 'text-teal-400 bg-teal-500/10 border-teal-500/20',
      description: 'Siparişiniz yola çıktı! Kurye paketleri dağıtım şubesinden teslim aldı.',
      history: [
        { status: 'Sipariş Alındı', date: new Date(orderTime).toLocaleTimeString('tr-TR'), description: 'Ödeme onaylandı ve sipariş kaydı başarıyla oluşturuldu.' },
        { status: 'Hazırlanıyor', date: new Date(orderTime + prepLimit * 1000).toLocaleTimeString('tr-TR'), description: 'Güvenli koruyucu paketleme uygulandı. Fatura ve garanti belgesi basıldı.' },
        { status: 'Kargoya Verildi', date: new Date(orderTime + shipLimit * 1000).toLocaleTimeString('tr-TR'), description: 'Kargo çıkışı yapıldı. Kurye dağıtım aracına yüklendi.' }
      ]
    };
  } else {
    return {
      status: 'delivered' as const,
      label: 'Teslim Edildi',
      percent: 100,
      color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20',
      description: 'Siparişiniz adrese başarıyla ulaştı. Cihazınızı iyi günlerde kullanın!',
      history: [
        { status: 'Sipariş Alındı', date: new Date(orderTime).toLocaleTimeString('tr-TR'), description: 'Ödeme onaylandı ve sipariş kaydı başarıyla oluşturuldu.' },
        { status: 'Hazırlanıyor', date: new Date(orderTime + prepLimit * 1000).toLocaleTimeString('tr-TR'), description: 'Güvenli koruyucu paketleme uygulandı. Fatura ve garanti belgesi basıldı.' },
        { status: 'Kargoya Verildi', date: new Date(orderTime + shipLimit * 1000).toLocaleTimeString('tr-TR'), description: 'Kargo çıkışı yapıldı. Kurye dağıtım aracına yüklendi.' },
        { status: 'Teslim Edildi', date: new Date(orderTime + delLimit * 1000).toLocaleTimeString('tr-TR'), description: 'Alıcıya (Bizzat kendisine) imzalı teslim edilmiştir.' }
      ]
    };
  }
}

export default function OrderTrackingModal({
  isOpen,
  onClose,
  orders,
  onCancelOrder,
  onClearHistory,
  onRepeatPurchase,
  onViewProduct
}: OrderTrackingModalProps) {
  const [selectedOrderId, setSelectedOrderId] = useState<string | null>(null);
  const [refreshTrigger, setRefreshTrigger] = useState<number>(0);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);

  // Automatically refresh status estimates every 3 seconds when open
  useEffect(() => {
    if (!isOpen) return;
    const interval = setInterval(() => {
      setRefreshTrigger(prev => prev + 1);
    }, 3000);
    return () => clearInterval(interval);
  }, [isOpen]);

  const handleManualRefresh = () => {
    setIsRefreshing(true);
    setTimeout(() => {
      setRefreshTrigger(prev => prev + 1);
      setIsRefreshing(false);
    }, 800);
  };

  const handleDownloadInvoice = (order: Order) => {
    const data: InvoiceData = {
      orderId: order.id,
      productName: order.productName,
      storeName: order.storeName,
      fullName: order.fullName,
      address: order.address,
      paymentMethod: order.paymentMethod,
      basePrice: order.basePrice || Math.round(order.totalPrice * 0.82),
      tax: order.tax || Math.round((order.basePrice || Math.round(order.totalPrice * 0.82)) * 0.18),
      shippingCost: order.shippingCost || 0,
      warrantyCost: order.warrantyCost || 0,
      totalPrice: order.totalPrice,
      orderDate: order.orderDate,
      specs: order.specs || []
    };
    generateInvoicePDF(data);
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-end bg-black/80 backdrop-blur-sm">
        
        {/* Backdrop close area */}
        <div className="absolute inset-0 cursor-default" onClick={onClose} />

        {/* Panel Content (Slide from right) */}
        <motion.div
          initial={{ x: '100%' }}
          animate={{ x: 0 }}
          exit={{ x: '100%' }}
          transition={{ type: 'spring', damping: 25, stiffness: 200 }}
          className="relative w-full max-w-lg h-full border-l border-gray-800 bg-dark-bg text-white shadow-2xl flex flex-col z-10"
        >
          {/* Header background glow decoration */}
          <div className="absolute top-0 left-0 right-0 h-32 bg-gradient-to-b from-teal-500/5 to-transparent pointer-events-none -z-10" />

          {/* Header */}
          <div className="flex items-center justify-between p-5 border-b border-gray-800 shrink-0">
            <div className="flex items-center gap-2.5">
              <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-teal-500/10 border border-teal-500/20 text-teal-400">
                <Truck className="h-4.5 w-4.5" />
              </div>
              <div>
                <h3 className="font-display font-bold text-base">Sipariş Takip Merkezi</h3>
                <p className="text-[10px] font-mono text-gray-500">CANLI LOJİSTİK SİMÜLASYONU</p>
              </div>
            </div>

            <div className="flex items-center gap-1.5">
              <button
                onClick={handleManualRefresh}
                className="p-1.5 rounded-lg border border-gray-800 text-gray-400 hover:text-white hover:bg-gray-900 transition-all cursor-pointer"
                title="Süreç Durumunu Güncelle"
              >
                <RefreshCw className={`h-4 w-4 ${isRefreshing ? 'animate-spin text-teal-400' : ''}`} />
              </button>
              <button
                onClick={onClose}
                className="p-1.5 rounded-lg border border-gray-800 text-gray-400 hover:text-white hover:bg-gray-900 transition-all cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          </div>

          {/* Body */}
          <div className="flex-1 overflow-y-auto p-5 space-y-4">
            {orders.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-8 space-y-4">
                <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-gray-900 border border-gray-800 text-gray-600">
                  <ShoppingBag className="h-8 w-8" />
                </div>
                <div className="space-y-1">
                  <h4 className="font-display font-bold text-gray-300">Henüz Siparişiniz Yok</h4>
                  <p className="text-xs text-gray-500 max-w-xs leading-relaxed">
                    Katalogdaki bir cihazın tedarikçileri arasından satın alma simülatörünü başlatarak sipariş verebilir, kargo sürecini bu panelden canlı izleyebilirsiniz.
                  </p>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                {/* Clear All Option */}
                <div className="flex items-center justify-between pb-1">
                  <span className="text-xs font-mono text-gray-400">Toplam {orders.length} Sipariş Listeleniyor</span>
                  <button
                    onClick={onClearHistory}
                    className="text-[11px] font-semibold text-red-400 hover:text-red-300 flex items-center gap-1 cursor-pointer bg-red-950/20 px-2 py-1 rounded border border-red-900/30 transition-all"
                  >
                    <Trash2 className="h-3 w-3" />
                    Tümünü Temizle
                  </button>
                </div>

                {orders.map((order) => {
                  const live = getOrderLiveStatus(order.orderDate, order.shippingMethod);
                  const isSelected = selectedOrderId === order.id;

                  // Get payment method icon and text
                  let payIcon = <CreditCard className="h-3.5 w-3.5" />;
                  let payText = 'Kart';
                  if (order.paymentMethod === 'bank') {
                    payIcon = <Landmark className="h-3.5 w-3.5" />;
                    payText = `Havale (${order.paymentDetails.bankName})`;
                  } else if (order.paymentMethod === 'crypto') {
                    payIcon = <Wallet className="h-3.5 w-3.5" />;
                    payText = `Kripto (${order.paymentDetails.currency})`;
                  } else if (order.paymentMethod === 'mobile') {
                    payIcon = <Smartphone className="h-3.5 w-3.5" />;
                    payText = `Mobil (${order.paymentDetails.carrier})`;
                  }

                  return (
                    <div
                      key={order.id}
                      className={`rounded-2xl border transition-all ${
                        isSelected 
                          ? 'border-teal-500 bg-teal-950/5' 
                          : 'border-gray-800/80 bg-gray-900/10 hover:border-gray-700/80 hover:bg-gray-900/20'
                      }`}
                    >
                      {/* Summary Row */}
                      <div 
                        onClick={() => setSelectedOrderId(isSelected ? null : order.id)}
                        className="p-4 flex items-start gap-3.5 cursor-pointer select-none"
                      >
                        {/* Product Thumbnail */}
                        <div className="h-14 w-14 rounded-xl border border-gray-800 bg-gray-950/60 overflow-hidden flex-shrink-0 flex items-center justify-center p-1.5">
                          <img 
                            src={order.productImage} 
                            alt={order.productName} 
                            className="h-full w-full object-contain"
                            referrerPolicy="no-referrer"
                          />
                        </div>

                        {/* Order info */}
                        <div className="flex-1 min-w-0 space-y-1">
                          <div className="flex items-center gap-1.5 justify-between">
                            <span className="text-[10px] font-mono text-gray-500 tracking-wider">
                              {order.id}
                            </span>
                            <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full border ${live.color}`}>
                              {live.label}
                            </span>
                          </div>

                          <h4 className="font-display font-bold text-white text-sm truncate">
                            {order.productName}
                          </h4>

                          <div className="flex items-center justify-between text-[11px] text-gray-400">
                            <span className="truncate max-w-[150px]">{order.storeName}</span>
                            <span className="font-mono font-bold text-teal-400">${order.totalPrice.toLocaleString()}</span>
                          </div>
                        </div>
                      </div>

                      {/* Expandable Logistics Progress & Timeline Details */}
                      {isSelected && (
                        <div className="border-t border-gray-800/60 p-4 space-y-4 bg-black/25 rounded-b-2xl">
                          
                          {/* Live delivery estimate header */}
                          <div className="grid grid-cols-2 gap-4 text-xs font-mono">
                            <div>
                              <span className="text-gray-500 block mb-0.5">Alıcı Müşteri:</span>
                              <span className="text-white font-semibold">{order.fullName}</span>
                            </div>
                            <div>
                              <span className="text-gray-500 block mb-0.5">Tahmini Teslimat:</span>
                              <span className="text-emerald-400 font-bold">{order.estimatedDelivery}</span>
                            </div>
                            <div className="col-span-2">
                              <span className="text-gray-500 block mb-0.5">Teslimat Adresi:</span>
                              <span className="text-white block truncate" title={order.address}>{order.address}</span>
                            </div>
                            <div>
                              <span className="text-gray-500 block mb-0.5">Ödeme Detayı:</span>
                              <span className="text-white flex items-center gap-1 font-sans text-[11px]">
                                {payIcon}
                                {payText}
                              </span>
                            </div>
                            <div>
                              <span className="text-gray-500 block mb-0.5">Lojistik Kargo Sınıfı:</span>
                              <span className="text-white">{order.shippingMethod === 'standard' ? 'Standart Kargo' : 'DHL Express Kurye'}</span>
                            </div>
                          </div>

                          {/* Progress bar */}
                          <div className="space-y-1.5">
                            <div className="flex justify-between items-center text-xs">
                              <span className="text-gray-400 font-medium">Anlık Süreç Durumu</span>
                              <span className="text-teal-400 font-mono font-bold">{live.percent}%</span>
                            </div>
                            <div className="h-1.5 w-full bg-gray-800 rounded-full overflow-hidden">
                              <div 
                                className="h-full bg-gradient-to-r from-teal-500 to-emerald-400 transition-all duration-700"
                                style={{ width: `${live.percent}%` }}
                              />
                            </div>
                            <p className="text-[11px] text-gray-400 leading-relaxed italic pt-1">
                              "{live.description}"
                            </p>
                          </div>

                          {/* Stepper Dots Visualizer */}
                          <div className="relative flex justify-between items-center px-2 py-1">
                            {/* Horizontal connection line */}
                            <div className="absolute left-6 right-6 top-1/2 -translate-y-1/2 h-0.5 bg-gray-800 -z-10" />
                            <div 
                              className="absolute left-6 top-1/2 -translate-y-1/2 h-0.5 bg-emerald-500/60 transition-all duration-500 -z-10" 
                              style={{ width: `${Math.max(0, live.percent - 20) * 1.15}%` }}
                            />

                            {/* Step Ordered */}
                            <div className="flex flex-col items-center">
                              <div className={`h-6 w-6 rounded-full flex items-center justify-center border text-[10px] font-bold ${
                                live.percent >= 20 ? 'bg-emerald-500 border-emerald-500 text-dark-bg' : 'bg-gray-900 border-gray-800 text-gray-500'
                              }`}>
                                {live.percent >= 20 ? <Check className="h-3 w-3" /> : '1'}
                              </div>
                              <span className="text-[9px] font-mono text-gray-400 mt-1">Alındı</span>
                            </div>

                            {/* Step Preparing */}
                            <div className="flex flex-col items-center">
                              <div className={`h-6 w-6 rounded-full flex items-center justify-center border text-[10px] font-bold ${
                                live.percent >= 50 ? 'bg-emerald-500 border-emerald-500 text-dark-bg' : 'bg-gray-900 border-gray-800 text-gray-500'
                              }`}>
                                {live.percent >= 50 ? <Check className="h-3 w-3" /> : '2'}
                              </div>
                              <span className="text-[9px] font-mono text-gray-400 mt-1">Hazırlık</span>
                            </div>

                            {/* Step Shipped */}
                            <div className="flex flex-col items-center">
                              <div className={`h-6 w-6 rounded-full flex items-center justify-center border text-[10px] font-bold ${
                                live.percent >= 80 ? 'bg-emerald-500 border-emerald-500 text-dark-bg' : 'bg-gray-900 border-gray-800 text-gray-500'
                              }`}>
                                {live.percent >= 80 ? <Check className="h-3 w-3" /> : '3'}
                              </div>
                              <span className="text-[9px] font-mono text-gray-400 mt-1">Yolda</span>
                            </div>

                            {/* Step Delivered */}
                            <div className="flex flex-col items-center">
                              <div className={`h-6 w-6 rounded-full flex items-center justify-center border text-[10px] font-bold ${
                                live.percent >= 100 ? 'bg-emerald-500 border-emerald-500 text-dark-bg' : 'bg-gray-900 border-gray-800 text-gray-500'
                              }`}>
                                {live.percent >= 100 ? <Check className="h-3 w-3" /> : '4'}
                              </div>
                              <span className="text-[9px] font-mono text-gray-400 mt-1">Teslim</span>
                            </div>
                          </div>

                          {/* Historical logs */}
                          <div className="space-y-2 pt-1">
                            <span className="text-[10px] font-mono font-bold text-gray-500 uppercase tracking-wider block">Sipariş Günlük Kayıtları</span>
                            <div className="space-y-2 border-l border-gray-800 pl-3">
                              {live.history.map((log, index) => (
                                <div key={index} className="relative text-xs">
                                  <div className="absolute -left-[16.5px] top-1.5 h-1.5 w-1.5 rounded-full bg-emerald-500" />
                                  <div className="flex items-center gap-1.5 text-gray-400">
                                    <span className="font-bold text-white text-[11px]">{log.status}</span>
                                    <span className="font-mono text-[10px] text-gray-500">({log.date})</span>
                                  </div>
                                  <p className="text-[11px] text-gray-400 mt-0.5 leading-normal">{log.description}</p>
                                </div>
                              ))}
                            </div>
                          </div>

                          {/* Itemized billing details */}
                          <div className="rounded-xl border border-gray-800 bg-gray-900/30 p-3 space-y-1.5 text-xs font-mono">
                            <div className="flex justify-between items-center text-gray-500 font-bold uppercase text-[9px] border-b border-gray-800 pb-1.5">
                              <span>AYRINTILI FATURA KIRILIMI</span>
                              <span className="text-teal-400">GUVENLI ISLEM</span>
                            </div>
                            <div className="flex justify-between text-gray-400">
                              <span>Cihaz Bedeli:</span>
                              <span>${(order.basePrice || Math.round(order.totalPrice * 0.82)).toLocaleString()} USD</span>
                            </div>
                            <div className="flex justify-between text-gray-400">
                              <span>KDV (%18):</span>
                              <span>+${(order.tax || Math.round((order.basePrice || Math.round(order.totalPrice * 0.82)) * 0.18)).toLocaleString()} USD</span>
                            </div>
                            {(order.shippingCost ?? 0) > 0 && (
                              <div className="flex justify-between text-gray-400">
                               <span>Kargo Hizmet Bedeli:</span>
                               <span>+${order.shippingCost} USD</span>
                              </div>
                            )}
                            {(order.warrantyCost ?? 0) > 0 && (
                              <div className="flex justify-between text-gray-400">
                                <span>Teknik Guvence Paketi:</span>
                                <span>+${order.warrantyCost} USD</span>
                              </div>
                            )}
                            <div className="flex justify-between text-emerald-400 font-bold border-t border-gray-800 pt-1.5 text-[13px]">
                              <span>TOPLAM ODEME:</span>
                              <span>${order.totalPrice.toLocaleString()} USD</span>
                            </div>
                          </div>

                          {/* Interactive Product & Repeat Purchase Controls */}
                          <div className="grid grid-cols-2 gap-2 pt-1">
                            {onViewProduct && (
                              <button
                                type="button"
                                onClick={() => {
                                  onViewProduct(order.productId);
                                  onClose();
                                }}
                                className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg border border-gray-800 hover:border-gray-700 bg-gray-900/30 hover:bg-gray-900/60 text-gray-300 text-xs font-medium transition-all cursor-pointer"
                              >
                                <ExternalLink className="h-3.5 w-3.5 text-gray-400" />
                                Urunu Incele
                              </button>
                            )}
                            {onRepeatPurchase && (
                              <button
                                type="button"
                                onClick={() => {
                                  onRepeatPurchase(order.productId, order.storeName);
                                  onClose();
                                }}
                                className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg bg-teal-500 hover:bg-teal-600 text-dark-bg text-xs font-bold transition-all cursor-pointer"
                              >
                                <RotateCcw className="h-3.5 w-3.5 text-dark-bg" />
                                Tekrar Satin Al
                              </button>
                            )}
                          </div>

                          {/* Historical Invoice PDF Trigger */}
                          <button
                            type="button"
                            onClick={() => handleDownloadInvoice(order)}
                            className="w-full py-2 px-3 rounded-lg border border-teal-500/20 bg-teal-500/5 hover:bg-teal-500/10 text-teal-400 text-xs font-semibold flex items-center justify-center gap-2 transition-all cursor-pointer"
                          >
                            <FileText className="h-4 w-4" />
                            Gecmis E-Faturayi PDF Indir
                          </button>

                          {/* Order Actions */}
                          {live.status !== 'delivered' && (
                            <button
                              onClick={() => {
                                if (confirm('Siparisi iptal etmek istediginize emin misiniz?')) {
                                  onCancelOrder(order.id);
                                }
                              }}
                              className="w-full rounded-xl border border-red-900/30 bg-red-950/10 hover:bg-red-950/30 text-red-400 py-2.5 text-xs font-semibold transition-all cursor-pointer text-center"
                            >
                              Siparisi Iptal Et ve Odemeyi Iade Al
                            </button>
                          )}

                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Footer Info */}
          <div className="p-5 border-t border-gray-800 text-center text-[10px] text-gray-500 leading-normal bg-black/10 shrink-0">
            Kargo takip süreci tamamen yerel tarayıcı oturumunuza bağlı olarak simüle edilir. Sayfayı yenileseniz dahi sipariş zamanı baz alınarak lojistik adımları gerçek zamanlı ilerlemeye devam eder!
          </div>

        </motion.div>
      </div>
    </AnimatePresence>
  );
}
