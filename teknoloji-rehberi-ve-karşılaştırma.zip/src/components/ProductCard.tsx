import React from 'react';
import { Product } from '../data/products';
import { Layers, ShieldCheck, Scale, AlertCircle, ShoppingCart, HelpCircle, Heart } from 'lucide-react';

interface ProductCardProps {
  key?: string;
  product: Product;
  onViewDetails: (product: Product) => void;
  onToggleCompare: (product: Product) => void;
  isComparing: boolean;
  isCompareDisabled: boolean;
  isFavorite: boolean;
  onToggleFavorite: (product: Product) => void;
}

export default function ProductCard({
  product,
  onViewDetails,
  onToggleCompare,
  isComparing,
  isCompareDisabled,
  isFavorite,
  onToggleFavorite
}: ProductCardProps) {
  // Category Color helpers
  const getCategoryTheme = (category: string) => {
    switch (category) {
      case 'Sanal & Artırılmış Gerçeklik':
        return { bg: 'from-pink-500/10 to-purple-500/10 border-purple-500/20 text-purple-400', badge: 'bg-purple-950 text-purple-300 border-purple-800' };
      case 'Donanım & Bilgisayar':
        return { bg: 'from-blue-500/10 to-cyan-500/10 border-blue-500/20 text-blue-400', badge: 'bg-blue-950 text-blue-300 border-blue-800' };
      case 'Giyilebilir Teknoloji':
        return { bg: 'from-violet-500/10 to-indigo-500/10 border-indigo-500/20 text-indigo-400', badge: 'bg-indigo-950 text-indigo-300 border-indigo-800' };
      case 'Yapay Zeka & Robotik':
        return { bg: 'from-amber-500/10 to-orange-500/10 border-orange-500/20 text-orange-400', badge: 'bg-orange-950 text-orange-300 border-orange-800' };
      case 'Akıllı Çevre & İletişim':
        return { bg: 'from-teal-500/10 to-emerald-500/10 border-teal-500/20 text-teal-400', badge: 'bg-teal-950 text-teal-300 border-teal-800' };
      default:
        return { bg: 'from-gray-500/10 to-slate-500/10 border-gray-500/20 text-gray-400', badge: 'bg-gray-950 text-gray-300 border-gray-800' };
    }
  };

  const theme = getCategoryTheme(product.category);

  // Lowest Marketplace price finder
  const lowestPriceStore = product.marketplace.reduce((min, item) => (item.price < min.price ? item : min), product.marketplace[0]);

  return (
    <div 
      id={`product-card-${product.id}`}
      className="group relative flex flex-col justify-between overflow-hidden rounded-2xl border border-gray-800 bg-dark-card/60 p-5 transition-all duration-300 hover:-translate-y-1 hover:border-gray-700 hover:shadow-2xl hover:shadow-teal-500/5 backdrop-blur-sm"
    >
      {/* Glow Effect on Hover */}
      <div className="absolute inset-0 -z-10 bg-gradient-to-br from-teal-500/5 via-transparent to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100" />

      <div>
        {/* Category Badge, Heart Button & Price */}
        <div className="flex items-center justify-between">
          <span className={`inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-medium font-display ${theme.badge}`}>
            {product.category}
          </span>
          <div className="flex items-center space-x-2">
            <button
              onClick={(e) => {
                e.stopPropagation();
                onToggleFavorite(product);
              }}
              className="p-1.5 rounded-lg bg-gray-900/40 border border-gray-800 text-gray-400 hover:text-red-400 hover:border-red-500/20 transition-all focus:outline-none cursor-pointer"
              title={isFavorite ? "Favorilerden Çıkar" : "Favorilere Ekle"}
            >
              <Heart className={`h-3.5 w-3.5 ${isFavorite ? 'fill-red-500 text-red-500' : ''}`} />
            </button>
            <span className="font-mono text-sm font-semibold text-teal-400">
              {product.priceRange}
            </span>
          </div>
        </div>

        {/* Title and Tagline */}
        <div className="mt-4">
          <h3 className="font-display text-xl font-bold text-white tracking-tight group-hover:text-teal-300 transition-colors duration-200">
            {product.name}
          </h3>
          <p className="mt-1 text-xs text-gray-400 line-clamp-1 italic">
            "{product.tagline}"
          </p>
        </div>

        {/* Short Description */}
        <p className="mt-3 text-sm text-gray-300 line-clamp-3 leading-relaxed">
          {product.description}
        </p>

        {/* Highlight Specifications */}
        <div className="mt-4 border-t border-gray-800/80 pt-3">
          <h4 className="text-[10px] font-mono text-gray-500 uppercase tracking-wider mb-2">Öne Çıkan Donanım Özellikleri</h4>
          <div className="grid grid-cols-2 gap-2 text-xs">
            {product.specs.slice(0, 4).map((spec, idx) => (
              <div key={idx} className="flex flex-col border-l border-teal-500/20 pl-2">
                <span className="text-gray-500 truncate">{spec.label}</span>
                <span className="font-semibold text-gray-300 truncate font-mono">{spec.value}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Lowest Price and Store Badge */}
        <div className="mt-4 rounded-lg bg-gray-900/60 p-2.5 border border-gray-800/50 flex items-center justify-between text-xs">
          <div className="flex items-center gap-1.5">
            <ShoppingCart className="h-3.5 w-3.5 text-teal-500" />
            <span className="text-gray-400">En Uygun Pazar Yeri:</span>
          </div>
          <div className="text-right">
            <div className="font-bold text-teal-300 font-mono">${lowestPriceStore.price}</div>
            <div className="text-[9px] text-gray-500 font-medium">{lowestPriceStore.storeName}</div>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="mt-5 flex items-center gap-2">
        <button
          id={`btn-view-${product.id}`}
          onClick={() => onViewDetails(product)}
          className="flex-1 rounded-xl bg-gray-800 border border-gray-700 py-2 text-center text-xs font-semibold text-white transition-all hover:bg-gray-700"
        >
          Kapsamlı Detaylar
        </button>

        <button
          id={`btn-compare-${product.id}`}
          onClick={() => onToggleCompare(product)}
          disabled={!isComparing && isCompareDisabled}
          className={`flex items-center justify-center gap-1.5 rounded-xl border px-3 py-2 text-xs font-semibold transition-all duration-200 ${
            isComparing
              ? 'bg-teal-500 border-teal-500 text-dark-bg hover:bg-teal-600'
              : isCompareDisabled
              ? 'border-gray-800 text-gray-600 cursor-not-allowed bg-transparent'
              : 'border-gray-700 text-gray-300 hover:border-teal-500 hover:text-teal-400 bg-transparent'
          }`}
          title={isCompareDisabled && !isComparing ? "En fazla 3 ürün karşılaştırılabilir" : "Karşılaştırma listesine ekle"}
        >
          <Scale className="h-3.5 w-3.5" />
          <span>{isComparing ? 'Eklendi' : 'Karşılaştır'}</span>
        </button>
      </div>
    </div>
  );
}
