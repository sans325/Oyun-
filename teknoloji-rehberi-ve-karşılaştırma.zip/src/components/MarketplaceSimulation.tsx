import React, { useState, useEffect } from 'react';
import { Product, MarketplaceStore } from '../data/products';
import { 
  X, ShoppingBag, ShieldCheck, CreditCard, Truck, Check, Star, 
  HelpCircle, Loader2, Landmark, Wallet, Smartphone, ShieldAlert,
  Lock, Plus, Trash2, FileText, ChevronDown, Download, Key
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { encryptPaymentData, decryptPaymentData } from '../utils/cryptoSim';
import { generateInvoicePDF, InvoiceData } from '../utils/pdfGenerator';

export interface SavedPaymentMethod {
  id: string;
  type: 'card' | 'bank' | 'crypto' | 'mobile';
  label: string;
  encryptedData: string;
}

interface MarketplaceSimulationProps {
  product: Product | null;
  store: MarketplaceStore | null;
  onClose: () => void;
  onOrderPlaced?: (order: any) => void;
}

export default function MarketplaceSimulation({
  product,
  store,
  onClose,
  onOrderPlaced
}: MarketplaceSimulationProps) {
  const [shippingMethod, setShippingMethod] = useState<'standard' | 'express'>('standard');
  const [warranty, setWarranty] = useState<boolean>(false);
  const [fullName, setFullName] = useState<string>('');
  const [address, setAddress] = useState<string>('');
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'bank' | 'crypto' | 'mobile'>('card');
  const [loading, setLoading] = useState<boolean>(false);
  const [success, setSuccess] = useState<boolean>(false);

  // Credit Card States
  const [cardNumber, setCardNumber] = useState<string>('');
  const [cardHolder, setCardHolder] = useState<string>('');
  const [cardExpiry, setCardExpiry] = useState<string>('');
  const [cardCvv, setCardCvv] = useState<string>('');

  // Bank Transfer States
  const [selectedBank, setSelectedBank] = useState<string>('Garanti BBVA');
  const [bankSenderName, setBankSenderName] = useState<string>('');

  // Crypto States
  const [cryptoNetwork, setCryptoNetwork] = useState<string>('TRC-20');
  const [cryptoCurrency, setCryptoCurrency] = useState<string>('USDT');
  const [cryptoWalletAddress, setCryptoWalletAddress] = useState<string>('');

  // Mobile Payment States
  const [mobilePhone, setMobilePhone] = useState<string>('');
  const [mobileCarrier, setMobileCarrier] = useState<string>('Turkcell');

  // Persistence State
  const [savePaymentInfo, setSavePaymentInfo] = useState<boolean>(false);

  // Secure Wallet Manager States
  const [walletMethods, setWalletMethods] = useState<SavedPaymentMethod[]>([]);
  const [selectedWalletId, setSelectedWalletId] = useState<string>('');
  const [newMethodLabel, setNewMethodLabel] = useState<string>('');
  const [isAddingToWallet, setIsAddingToWallet] = useState<boolean>(false);
  const [showWalletLog, setShowWalletLog] = useState<boolean>(false); // Debug tool to show encrypted structure!
  const [orderIdRef, setOrderIdRef] = useState<string>(''); // For invoice download post-purchase

  // Initialize and load saved payment methods
  useEffect(() => {
    const stored = localStorage.getItem('tekno_secure_wallet_methods');
    if (stored) {
      try {
        setWalletMethods(JSON.parse(stored));
      } catch (e) {
        console.error(e);
      }
    } else {
      // Set default pre-loaded methods representing encryption
      const defaultMethods: SavedPaymentMethod[] = [
        {
          id: 'default-card-1',
          type: 'card',
          label: 'Guvenli Quantum Test Karti (Simule)',
          encryptedData: encryptPaymentData({
            cardNumber: '4355 9820 1144 1983',
            cardHolder: 'Ahmet Yilmaz',
            cardExpiry: '12/30',
            cardCvv: '777'
          })
        },
        {
          id: 'default-crypto-1',
          type: 'crypto',
          label: 'Defi Web3 Cuzdani (Simule)',
          encryptedData: encryptPaymentData({
            cryptoNetwork: 'Solana',
            cryptoCurrency: 'USDT',
            cryptoWalletAddress: 'H8uR9t2DsfSfsdfWe34sdf9sdff'
          })
        }
      ];
      setWalletMethods(defaultMethods);
      localStorage.setItem('tekno_secure_wallet_methods', JSON.stringify(defaultMethods));
    }
  }, []);

  // Load saved details on mount
  useEffect(() => {
    if (!product || !store) return;
    
    const savedSavePref = localStorage.getItem('tekno_saved_payment_save_pref');
    if (savedSavePref === 'true') {
      setSavePaymentInfo(true);
      setFullName(localStorage.getItem('tekno_saved_payment_fullName') || '');
      setAddress(localStorage.getItem('tekno_saved_payment_address') || '');
      
      const card = localStorage.getItem('tekno_saved_payment_card');
      if (card) {
        try {
          const parsed = JSON.parse(card);
          setCardNumber(parsed.cardNumber || '');
          setCardHolder(parsed.cardHolder || '');
          setCardExpiry(parsed.cardExpiry || '');
          setCardCvv(parsed.cardCvv || '');
        } catch (e) {}
      }
      
      const bank = localStorage.getItem('tekno_saved_payment_bank');
      if (bank) {
        try {
          const parsed = JSON.parse(bank);
          setSelectedBank(parsed.selectedBank || 'Garanti BBVA');
          setBankSenderName(parsed.bankSenderName || '');
        } catch (e) {}
      }

      const crypto = localStorage.getItem('tekno_saved_payment_crypto');
      if (crypto) {
        try {
          const parsed = JSON.parse(crypto);
          setCryptoNetwork(parsed.cryptoNetwork || 'TRC-20');
          setCryptoCurrency(parsed.cryptoCurrency || 'USDT');
          setCryptoWalletAddress(parsed.cryptoWalletAddress || '');
        } catch (e) {}
      }

      const mobile = localStorage.getItem('tekno_saved_payment_mobile');
      if (mobile) {
        try {
          const parsed = JSON.parse(mobile);
          setMobilePhone(parsed.mobilePhone || '');
          setMobileCarrier(parsed.mobileCarrier || 'Turkcell');
        } catch (e) {}
      }
    }
  }, [product, store]);

  if (!product || !store) return null;

  const basePrice = store.price;
  const shippingCost = shippingMethod === 'standard' ? 0 : 49;
  const warrantyCost = warranty ? Math.round(basePrice * 0.08) : 0;
  const tax = Math.round(basePrice * 0.18); // 18% KDV
  const totalPrice = basePrice + shippingCost + warrantyCost + tax;

  const handleSelectWalletMethod = (id: string) => {
    setSelectedWalletId(id);
    if (!id) return;
    const found = walletMethods.find(w => w.id === id);
    if (found) {
      setPaymentMethod(found.type);
      const decrypted = decryptPaymentData(found.encryptedData);
      if (decrypted) {
        if (found.type === 'card') {
          setCardNumber(decrypted.cardNumber || '');
          setCardHolder(decrypted.cardHolder || '');
          setCardExpiry(decrypted.cardExpiry || '');
          setCardCvv(decrypted.cardCvv || '');
        } else if (found.type === 'crypto') {
          setCryptoNetwork(decrypted.cryptoNetwork || 'TRC-20');
          setCryptoCurrency(decrypted.cryptoCurrency || 'USDT');
          setCryptoWalletAddress(decrypted.cryptoWalletAddress || '');
        } else if (found.type === 'bank') {
          setSelectedBank(decrypted.selectedBank || 'Garanti BBVA');
          setBankSenderName(decrypted.bankSenderName || '');
        } else if (found.type === 'mobile') {
          setMobilePhone(decrypted.mobilePhone || '');
          setMobileCarrier(decrypted.mobileCarrier || 'Turkcell');
        }
      }
    }
  };

  const handleSaveToWallet = () => {
    if (!newMethodLabel.trim()) {
      alert('Lutfen cuzdan kaydi icin bir isim giriniz (Orn: Bonus Kartim).');
      return;
    }

    let rawData: any = {};
    if (paymentMethod === 'card') {
      if (!cardNumber || !cardHolder) {
        alert('Lutfen kart bilgilerini doldurunuz.');
        return;
      }
      rawData = { cardNumber, cardHolder, cardExpiry, cardCvv };
    } else if (paymentMethod === 'crypto') {
      if (!cryptoWalletAddress) {
        alert('Lutfen kripto cuzdani adresinizi doldurunuz.');
        return;
      }
      rawData = { cryptoNetwork, cryptoCurrency, cryptoWalletAddress };
    } else if (paymentMethod === 'bank') {
      if (!bankSenderName) {
        alert('Lutfen gonderen ismini doldurunuz.');
        return;
      }
      rawData = { selectedBank, bankSenderName };
    } else if (paymentMethod === 'mobile') {
      if (!mobilePhone) {
        alert('Lutfen telefon numarasini doldurunuz.');
        return;
      }
      rawData = { mobilePhone, mobileCarrier };
    }

    const encryptedStr = encryptPaymentData(rawData);
    const newMethod: SavedPaymentMethod = {
      id: `wallet-${Date.now()}`,
      type: paymentMethod,
      label: newMethodLabel,
      encryptedData: encryptedStr
    };

    const updated = [...walletMethods, newMethod];
    setWalletMethods(updated);
    localStorage.setItem('tekno_secure_wallet_methods', JSON.stringify(updated));
    setSelectedWalletId(newMethod.id);
    setNewMethodLabel('');
    setIsAddingToWallet(false);
  };

  const handleRemoveWalletMethod = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (id.startsWith('default-')) {
      alert('Varsayilan simule kartlar silinemez.');
      return;
    }
    if (confirm('Bu kayitli odeme yontemini guvenli cuzdaninizdan silmek istediginize emin misiniz?')) {
      const updated = walletMethods.filter(w => w.id !== id);
      setWalletMethods(updated);
      localStorage.setItem('tekno_secure_wallet_methods', JSON.stringify(updated));
      if (selectedWalletId === id) {
        setSelectedWalletId('');
      }
    }
  };

  const handleDownloadInvoice = () => {
    const invoiceData: InvoiceData = {
      orderId: orderIdRef || 'TR-MOCK-123',
      productName: product.name,
      storeName: store.storeName,
      basePrice: basePrice,
      tax: tax,
      shippingCost: shippingCost,
      warrantyCost: warrantyCost,
      totalPrice: totalPrice,
      fullName: fullName,
      address: address,
      paymentMethod: paymentMethod,
      orderDate: new Date().toISOString(),
      specs: product.specs
    };
    generateInvoicePDF(invoiceData);
  };

  const handleCheckoutSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName || !address) return;
    
    // Additional validation based on payment method
    if (paymentMethod === 'card' && (!cardNumber || !cardHolder || !cardExpiry || !cardCvv)) return;
    if (paymentMethod === 'bank' && !bankSenderName) return;
    if (paymentMethod === 'crypto' && !cryptoWalletAddress) return;
    if (paymentMethod === 'mobile' && !mobilePhone) return;

    setLoading(true);

    const generatedTrackingNumber = `TR-${Math.floor(100000 + Math.random() * 900000)}-${product.id.slice(0, 3).toUpperCase()}`;
    setOrderIdRef(generatedTrackingNumber);

    setTimeout(() => {
      // Save details if requested
      if (savePaymentInfo) {
        localStorage.setItem('tekno_saved_payment_save_pref', 'true');
        localStorage.setItem('tekno_saved_payment_fullName', fullName);
        localStorage.setItem('tekno_saved_payment_address', address);
        localStorage.setItem('tekno_saved_payment_card', JSON.stringify({ cardNumber, cardHolder, cardExpiry, cardCvv }));
        localStorage.setItem('tekno_saved_payment_bank', JSON.stringify({ selectedBank, bankSenderName }));
        localStorage.setItem('tekno_saved_payment_crypto', JSON.stringify({ cryptoNetwork, cryptoCurrency, cryptoWalletAddress }));
        localStorage.setItem('tekno_saved_payment_mobile', JSON.stringify({ mobilePhone, mobileCarrier }));
      } else {
        localStorage.removeItem('tekno_saved_payment_save_pref');
        localStorage.removeItem('tekno_saved_payment_fullName');
        localStorage.removeItem('tekno_saved_payment_address');
        localStorage.removeItem('tekno_saved_payment_card');
        localStorage.removeItem('tekno_saved_payment_bank');
        localStorage.removeItem('tekno_saved_payment_crypto');
        localStorage.removeItem('tekno_saved_payment_mobile');
      }

      // Format paymentDetails for the order
      let paymentDetails: any = {};
      if (paymentMethod === 'card') {
        const masked = cardNumber.replace(/\s/g, '');
        paymentDetails = {
          cardNumber: masked.length > 4 ? `**** **** **** ${masked.slice(-4)}` : '**** **** **** 1234',
          cardHolder: cardHolder
        };
      } else if (paymentMethod === 'bank') {
        paymentDetails = {
          bankName: selectedBank,
          senderName: bankSenderName
        };
      } else if (paymentMethod === 'crypto') {
        paymentDetails = {
          currency: cryptoCurrency,
          network: cryptoNetwork,
          wallet: cryptoWalletAddress.length > 8 
            ? `${cryptoWalletAddress.slice(0, 6)}...${cryptoWalletAddress.slice(-4)}`
            : '0x71C...392A'
        };
      } else if (paymentMethod === 'mobile') {
        paymentDetails = {
          phone: mobilePhone.length > 4 ? `+90 (***) *** ${mobilePhone.slice(-4)}` : '+90 (555) *** 1234',
          carrier: mobileCarrier
        };
      }

      // Create new order object
      const newOrder = {
        id: generatedTrackingNumber,
        productId: product.id,
        productName: product.name,
        productImage: product.image,
        storeName: store.storeName,
        totalPrice: totalPrice,
        fullName: fullName,
        address: address,
        paymentMethod: paymentMethod,
        paymentDetails: paymentDetails,
        shippingMethod: shippingMethod,
        status: 'ordered' as const, // 'ordered' | 'preparing' | 'shipped' | 'delivered'
        orderDate: new Date().toISOString(),
        estimatedDelivery: new Date(Date.now() + (shippingMethod === 'standard' ? 3 : 1) * 24 * 60 * 60 * 1000).toLocaleDateString('tr-TR', { day: 'numeric', month: 'long', year: 'numeric' }),
        basePrice: basePrice,
        tax: tax,
        shippingCost: shippingCost,
        warrantyCost: warrantyCost,
        specs: product.specs,
        history: [
          {
            status: 'ordered',
            date: new Date().toLocaleString('tr-TR'),
            description: 'Siparişiniz başarıyla alındı ve ödeme onaylandı.'
          }
        ]
      };

      if (onOrderPlaced) {
        onOrderPlaced(newOrder);
      }

      setLoading(false);
      setSuccess(true);
    }, 2000);
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md overflow-y-auto">
        
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className="relative w-full max-w-2xl rounded-2xl border border-gray-800 bg-dark-bg text-white shadow-2xl overflow-hidden flex flex-col my-8"
        >
          {/* Header background decoration */}
          <div className="absolute top-0 left-0 right-0 h-24 bg-gradient-to-b from-emerald-500/10 via-transparent to-transparent -z-10" />

          {/* Modal Header */}
          <div className="flex items-center justify-between p-6 border-b border-gray-800">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
                <ShoppingBag className="h-5 w-5" />
              </div>
              <div>
                <h3 className="font-display text-lg font-bold">Güvenli Pazar Yeri Satın Alma Simülatörü</h3>
                <p className="text-xs text-gray-400 mt-0.5">
                  {store.storeName} aracılığıyla satın alım simüle ediliyor.
                </p>
              </div>
            </div>
            
            <button
              id="btn-close-sim"
              onClick={onClose}
              className="rounded-lg p-2 text-gray-400 hover:bg-gray-800 hover:text-white transition-all"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          {!success ? (
            /* ACTIVE CHECKOUT FORM */
            <form onSubmit={handleCheckoutSubmit} className="p-6 overflow-y-auto max-h-[70vh] space-y-6">
              
              {/* Sandbox Warning */}
              <div className="rounded-xl border border-amber-500/20 bg-amber-500/5 p-4 text-xs text-amber-300 flex gap-2.5">
                <ShieldCheck className="h-4 w-4 shrink-0 text-amber-400 mt-0.5" />
                <div>
                  <span className="font-bold">Geliştirici Sandbox Uyarısı:</span> Bu bölüm, pazar yeri entegrasyonunu ve fiyat karşılaştırma sonrası doğrudan satın alma akışını görselleştirmek amacıyla tasarlanmış bir simülasyondur. Gerçek ödeme bilgilerinizi <span className="font-bold">girmeyiniz</span>.
                </div>
              </div>

              {/* Product Info Summary */}
              <div className="rounded-xl border border-gray-800 bg-gray-900/40 p-4 flex justify-between items-center">
                <div className="space-y-1">
                  <div className="text-[10px] font-mono text-gray-500 uppercase tracking-widest">Seçilen Cihaz</div>
                  <h4 className="font-display font-bold text-white text-base">{product.name}</h4>
                  <p className="text-xs text-gray-400 font-mono italic">"{product.tagline}"</p>
                </div>
                <div className="text-right">
                  <div className="text-xs text-gray-500 font-mono">Tedarikçi Fiyatı</div>
                  <div className="text-lg font-bold font-mono text-teal-400">${basePrice.toLocaleString()}</div>
                </div>
              </div>

              {/* Form inputs */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                
                {/* Full name */}
                <div className="space-y-1.5">
                  <label className="text-[11px] font-mono font-bold text-gray-400 uppercase tracking-wide">
                    Ad Soyad
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Örn: Ahmet Yılmaz"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="w-full rounded-xl border border-gray-800 bg-gray-900/60 p-3 text-xs text-white focus:border-emerald-500 focus:outline-none"
                  />
                </div>

                {/* Delivery options */}
                <div className="space-y-1.5">
                  <label className="text-[11px] font-mono font-bold text-gray-400 uppercase tracking-wide">
                    Teslimat Hızı
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setShippingMethod('standard')}
                      className={`rounded-xl border p-2.5 text-xs font-semibold text-center transition-all ${
                        shippingMethod === 'standard'
                          ? 'border-emerald-500 bg-emerald-500/10 text-emerald-400'
                          : 'border-gray-800 bg-gray-900/40 text-gray-400 hover:border-gray-700'
                      }`}
                    >
                      Standart (Ücretsiz)
                    </button>
                    <button
                      type="button"
                      onClick={() => setShippingMethod('express')}
                      className={`rounded-xl border p-2.5 text-xs font-semibold text-center transition-all ${
                        shippingMethod === 'express'
                          ? 'border-emerald-500 bg-emerald-500/10 text-emerald-400'
                          : 'border-gray-800 bg-gray-900/40 text-gray-400 hover:border-gray-700'
                      }`}
                    >
                      Hızlı Kargo (+$49)
                    </button>
                  </div>
                </div>

                {/* Address */}
                <div className="md:col-span-2 space-y-1.5">
                  <label className="text-[11px] font-mono font-bold text-gray-400 uppercase tracking-wide">
                    Teslimat Adresi
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Örn: Kadıköy / İstanbul, Türkiye"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    className="w-full rounded-xl border border-gray-800 bg-gray-900/60 p-3 text-xs text-white focus:border-emerald-500 focus:outline-none"
                  />
                </div>

                {/* SECURE WALLET MANAGER (CUZDAN) SECTION */}
                <div className="md:col-span-2 rounded-xl border border-teal-500/30 bg-teal-500/5 p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-teal-500/10 border border-teal-500/30 text-teal-400">
                        <Lock className="h-4 w-4" />
                      </div>
                      <div>
                        <h4 className="text-xs font-bold text-white">Quantum Guvenli Cuzdanim (Wallet Manager)</h4>
                        <p className="text-[10px] text-gray-400">Sifreli olarak saklanan odeme yontemlerinizi yonetin ve secin.</p>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => setShowWalletLog(!showWalletLog)}
                      className="text-[10px] font-mono font-bold text-teal-400 hover:underline cursor-pointer"
                    >
                      {showWalletLog ? 'Sifreli Veriyi Gizle' : 'Sifreli Yapiyi Goster (AES Log)'}
                    </button>
                  </div>

                  {/* Saved Cards Selection Carousel / List */}
                  {walletMethods.length > 0 ? (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {walletMethods.map((method) => {
                        const isSelected = selectedWalletId === method.id;
                        return (
                          <div
                            key={method.id}
                            onClick={() => handleSelectWalletMethod(method.id)}
                            className={`p-3 rounded-xl border transition-all cursor-pointer flex flex-col justify-between h-20 ${
                              isSelected
                                ? 'border-teal-400 bg-teal-500/10'
                                : 'border-gray-800 bg-gray-900/40 hover:border-gray-700'
                            }`}
                          >
                            <div className="flex items-center justify-between">
                              <span className="text-[10px] font-mono font-bold text-teal-400 bg-teal-500/10 px-1.5 py-0.5 rounded uppercase">
                                {method.type === 'card' ? 'KREDI KARTI' : method.type === 'crypto' ? 'KRIPTO' : method.type === 'bank' ? 'HAVALE' : 'MOBIL'}
                              </span>
                              <button
                                type="button"
                                onClick={(e) => handleRemoveWalletMethod(method.id, e)}
                                className="text-gray-500 hover:text-rose-400 transition-colors"
                              >
                                <Trash2 className="h-3.5 w-3.5" />
                              </button>
                            </div>
                            <span className="text-xs font-bold text-white truncate mt-1">{method.label}</span>
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="text-xs text-gray-500 italic py-2 text-center">
                      Henuz kayitli guvenli odeme yontemi yok.
                    </div>
                  )}

                  {/* Encrypted data debug log */}
                  {showWalletLog && (
                    <div className="rounded-lg bg-black p-3 font-mono text-[9px] text-emerald-400 border border-emerald-500/20 max-h-28 overflow-y-auto space-y-1.5">
                      <div className="font-bold text-white border-b border-emerald-500/10 pb-1 mb-1">
                        LOCALSTORAGE SIFRELENMIS TABLO LOGU (AES-256 SIMULATION):
                      </div>
                      {walletMethods.map((m) => (
                        <div key={m.id} className="truncate">
                          <span className="text-teal-400">[{m.label}]:</span> {m.encryptedData}
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Add current method to wallet trigger */}
                  {!isAddingToWallet ? (
                    <button
                      type="button"
                      onClick={() => setIsAddingToWallet(true)}
                      className="w-full py-1.5 rounded-lg border border-dashed border-gray-800 text-gray-400 hover:border-teal-500/40 hover:text-teal-400 text-xs font-semibold flex items-center justify-center gap-1 transition-all cursor-pointer"
                    >
                      <Plus className="h-3.5 w-3.5" />
                      Mevcut Form Bilgilerini Sifreli Cuzdana Kaydet
                    </button>
                  ) : (
                    <div className="p-3 rounded-xl border border-gray-800 bg-gray-900/60 space-y-2">
                      <div className="text-xs font-semibold text-gray-300">Cuzdan Takma Adi (Label)</div>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          placeholder="Orn: Garanti Siyah Kartim"
                          value={newMethodLabel}
                          onChange={(e) => setNewMethodLabel(e.target.value)}
                          className="flex-1 rounded-lg border border-gray-800 bg-gray-950 p-2 text-xs text-white focus:border-teal-500 focus:outline-none"
                        />
                        <button
                          type="button"
                          onClick={handleSaveToWallet}
                          className="bg-teal-500 hover:bg-teal-600 text-dark-bg px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer"
                        >
                          Kaydet
                        </button>
                        <button
                          type="button"
                          onClick={() => setIsAddingToWallet(false)}
                          className="bg-gray-800 hover:bg-gray-700 text-white px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer"
                        >
                          Iptal
                        </button>
                      </div>
                    </div>
                  )}
                </div>

                {/* Payment Options (4 methods) */}
                <div className="md:col-span-2 space-y-3">
                  <label className="text-[11px] font-mono font-bold text-gray-400 uppercase tracking-wide flex items-center gap-1.5">
                    <ShieldCheck className="h-3.5 w-3.5 text-emerald-400" />
                    Ödeme Yöntemi Seçin
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    <button
                      type="button"
                      onClick={() => setPaymentMethod('card')}
                      className={`rounded-xl border p-3 text-xs font-bold flex flex-col items-center justify-center gap-1.5 transition-all cursor-pointer ${
                        paymentMethod === 'card'
                          ? 'border-emerald-500 bg-emerald-500/10 text-emerald-400'
                          : 'border-gray-800 bg-gray-900/40 text-gray-400 hover:border-gray-700'
                      }`}
                    >
                      <CreditCard className="h-4 w-4" />
                      <span>Kredi Kartı</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setPaymentMethod('bank')}
                      className={`rounded-xl border p-3 text-xs font-bold flex flex-col items-center justify-center gap-1.5 transition-all cursor-pointer ${
                        paymentMethod === 'bank'
                          ? 'border-emerald-500 bg-emerald-500/10 text-emerald-400'
                          : 'border-gray-800 bg-gray-900/40 text-gray-400 hover:border-gray-700'
                      }`}
                    >
                      <Landmark className="h-4 w-4" />
                      <span>Havale / EFT</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setPaymentMethod('crypto')}
                      className={`rounded-xl border p-3 text-xs font-bold flex flex-col items-center justify-center gap-1.5 transition-all cursor-pointer ${
                        paymentMethod === 'crypto'
                          ? 'border-emerald-500 bg-emerald-500/10 text-emerald-400'
                          : 'border-gray-800 bg-gray-900/40 text-gray-400 hover:border-gray-700'
                      }`}
                    >
                      <Wallet className="h-4 w-4" />
                      <span>Kripto Cüzdan</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setPaymentMethod('mobile')}
                      className={`rounded-xl border p-3 text-xs font-bold flex flex-col items-center justify-center gap-1.5 transition-all cursor-pointer ${
                        paymentMethod === 'mobile'
                          ? 'border-emerald-500 bg-emerald-500/10 text-emerald-400'
                          : 'border-gray-800 bg-gray-900/40 text-gray-400 hover:border-gray-700'
                      }`}
                    >
                      <Smartphone className="h-4 w-4" />
                      <span>Mobil Ödeme</span>
                    </button>
                  </div>
                </div>

                {/* CONDITIONAL PAYMENT DETAIL INPUTS */}
                <div className="md:col-span-2 rounded-xl border border-gray-800/80 bg-gray-950/40 p-4 space-y-4">
                  
                  {/* Option 1: Credit Card Form */}
                  {paymentMethod === 'card' && (
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="text-xs font-bold text-white flex items-center gap-1.5">
                          <CreditCard className="h-3.5 w-3.5 text-teal-400" />
                          <span>Kart Bilgileri</span>
                        </div>
                        <span className="text-[10px] font-mono text-gray-500">256-bit SSL Güvenliği</span>
                      </div>
                      
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        {/* Cardholder Name */}
                        <div className="space-y-1">
                          <label className="text-[10px] font-mono text-gray-400">Kart Üzerindeki İsim</label>
                          <input
                            type="text"
                            placeholder="Örn: Ahmet Yılmaz"
                            value={cardHolder}
                            onChange={(e) => setCardHolder(e.target.value)}
                            className="w-full rounded-lg border border-gray-800 bg-gray-900/40 p-2.5 text-xs text-white focus:border-emerald-500 focus:outline-none"
                            required={paymentMethod === 'card'}
                          />
                        </div>

                        {/* Card Number */}
                        <div className="space-y-1">
                          <label className="text-[10px] font-mono text-gray-400">Kart Numarası</label>
                          <input
                            type="text"
                            maxLength={19}
                            placeholder="4355 **** **** 1983"
                            value={cardNumber}
                            onChange={(e) => {
                              // Simple formatter: 16 digits spaced by 4
                              const val = e.target.value.replace(/\D/g, '').slice(0, 16);
                              const formatted = val.match(/.{1,4}/g)?.join(' ') || val;
                              setCardNumber(formatted);
                            }}
                            className="w-full rounded-lg border border-gray-800 bg-gray-900/40 p-2.5 text-xs text-white font-mono focus:border-emerald-500 focus:outline-none"
                            required={paymentMethod === 'card'}
                          />
                        </div>

                        {/* Expiry Date */}
                        <div className="space-y-1">
                          <label className="text-[10px] font-mono text-gray-400">Son Kullanma (AA/YY)</label>
                          <input
                            type="text"
                            maxLength={5}
                            placeholder="08/29"
                            value={cardExpiry}
                            onChange={(e) => {
                              const val = e.target.value.replace(/\D/g, '').slice(0, 4);
                              const formatted = val.length >= 2 ? `${val.slice(0, 2)}/${val.slice(2)}` : val;
                              setCardExpiry(formatted);
                            }}
                            className="w-full rounded-lg border border-gray-800 bg-gray-900/40 p-2.5 text-xs text-white font-mono focus:border-emerald-500 focus:outline-none"
                            required={paymentMethod === 'card'}
                          />
                        </div>

                        {/* CVV Code */}
                        <div className="space-y-1">
                          <label className="text-[10px] font-mono text-gray-400">Güvenlik Kodu (CVV)</label>
                          <input
                            type="password"
                            maxLength={3}
                            placeholder="***"
                            value={cardCvv}
                            onChange={(e) => setCardCvv(e.target.value.replace(/\D/g, '').slice(0, 3))}
                            className="w-full rounded-lg border border-gray-800 bg-gray-900/40 p-2.5 text-xs text-white font-mono focus:border-emerald-500 focus:outline-none"
                            required={paymentMethod === 'card'}
                          />
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Option 2: Bank Transfer / EFT */}
                  {paymentMethod === 'bank' && (
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="text-xs font-bold text-white flex items-center gap-1.5">
                          <Landmark className="h-3.5 w-3.5 text-teal-400" />
                          <span>Banka Havalesi / EFT Bilgileri</span>
                        </div>
                        <span className="text-[10px] font-mono text-gray-500">Otomatik Sipariş Onayı</span>
                      </div>

                      <div className="rounded-lg border border-gray-800/80 bg-gray-900/30 p-3 text-xs space-y-2">
                        <div className="flex justify-between items-center text-gray-400">
                          <span>Alıcı Hesap Adı:</span>
                          <span className="text-white font-semibold font-mono">{store.storeName} Teknoloji A.Ş.</span>
                        </div>
                        <div className="flex justify-between items-center text-gray-400">
                          <span>Seçilen Banka:</span>
                          <span className="text-emerald-400 font-bold">{selectedBank}</span>
                        </div>
                        <div className="flex justify-between items-center text-gray-400">
                          <span>TR IBAN Numarası:</span>
                          <span className="text-white font-mono font-bold select-all bg-black/40 px-2 py-0.5 rounded border border-gray-800/50">
                            TR29 0001 5001 5800 7300 1234 56
                          </span>
                        </div>
                        <div className="text-[10px] text-gray-500 italic mt-1 text-center">
                          Açıklama alanına otomatik üretilen takip kodunu (sipariş sonrası verilecek) yazmanız gerekmektedir.
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                        <div className="space-y-1">
                          <label className="text-[10px] font-mono text-gray-400">Transfer Yapılacak Banka</label>
                          <select
                            value={selectedBank}
                            onChange={(e) => setSelectedBank(e.target.value)}
                            className="w-full rounded-lg border border-gray-800 bg-gray-900/40 p-2.5 text-xs text-white focus:border-emerald-500 focus:outline-none"
                          >
                            <option value="Garanti BBVA">Garanti BBVA</option>
                            <option value="Ziraat Bankası">Ziraat Bankası</option>
                            <option value="İş Bankası">Türkiye İş Bankası</option>
                            <option value="Akbank">Akbank</option>
                            <option value="Yapı Kredi">Yapı Kredi</option>
                          </select>
                        </div>

                        <div className="space-y-1">
                          <label className="text-[10px] font-mono text-gray-400">Gönderen Adı Soyadı</label>
                          <input
                            type="text"
                            placeholder="Hesap Sahibi Adı Soyadı"
                            value={bankSenderName}
                            onChange={(e) => setBankSenderName(e.target.value)}
                            className="w-full rounded-lg border border-gray-800 bg-gray-900/40 p-2.5 text-xs text-white focus:border-emerald-500 focus:outline-none"
                            required={paymentMethod === 'bank'}
                          />
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Option 3: Crypto Transfer */}
                  {paymentMethod === 'crypto' && (
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="text-xs font-bold text-white flex items-center gap-1.5">
                          <Wallet className="h-3.5 w-3.5 text-teal-400" />
                          <span>Kripto Cüzdan / Web3 Ödemesi</span>
                        </div>
                        <span className="text-[10px] font-mono text-gray-500">Yarı-Otomatik Blockchain Onayı</span>
                      </div>

                      <div className="rounded-lg border border-gray-800/80 bg-gray-900/30 p-3 text-xs space-y-2">
                        <div className="flex justify-between items-center text-gray-400">
                          <span>Alıcı Cüzdan Adresi:</span>
                          <span className="text-emerald-400 font-bold">Store Smart Contract</span>
                        </div>
                        <div className="flex justify-between items-center text-gray-400">
                          <span>Ağ / Protokol:</span>
                          <span className="text-white font-mono bg-emerald-950/30 border border-emerald-900/50 px-1.5 py-0.5 rounded text-[11px]">{cryptoNetwork}</span>
                        </div>
                        <div className="flex justify-between items-center text-gray-400">
                          <span>Ödeme Birimi:</span>
                          <span className="text-white font-mono font-bold bg-indigo-950/30 border border-indigo-900/50 px-1.5 py-0.5 rounded text-[11px]">{cryptoCurrency}</span>
                        </div>
                        <div className="flex justify-between items-center text-gray-400">
                          <span>Cüzdan Adresi (Copy):</span>
                          <span className="text-white font-mono text-[10px] select-all bg-black/40 px-2 py-0.5 rounded border border-gray-800/50 truncate max-w-[60%]">
                            0x71C2496D8016421832A8C847178330B58418392A
                          </span>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-1">
                        <div className="space-y-1">
                          <label className="text-[10px] font-mono text-gray-400">Kripto Para</label>
                          <select
                            value={cryptoCurrency}
                            onChange={(e) => setCryptoCurrency(e.target.value)}
                            className="w-full rounded-lg border border-gray-800 bg-gray-900/40 p-2 text-xs text-white focus:border-emerald-500 focus:outline-none"
                          >
                            <option value="USDT">USDT (Tether)</option>
                            <option value="BTC">BTC (Bitcoin)</option>
                            <option value="ETH">ETH (Ethereum)</option>
                            <option value="USDC">USDC (USD Coin)</option>
                          </select>
                        </div>

                        <div className="space-y-1">
                          <label className="text-[10px] font-mono text-gray-400">Transfer Ağı</label>
                          <select
                            value={cryptoNetwork}
                            onChange={(e) => setCryptoNetwork(e.target.value)}
                            className="w-full rounded-lg border border-gray-800 bg-gray-900/40 p-2 text-xs text-white focus:border-emerald-500 focus:outline-none"
                          >
                            <option value="TRC-20">TRC-20 (Tron)</option>
                            <option value="ERC-20">ERC-20 (Ethereum)</option>
                            <option value="BSC">BEP-20 (BSC)</option>
                            <option value="Solana">Solana Network</option>
                            <option value="Bitcoin">Bitcoin Native</option>
                          </select>
                        </div>

                        <div className="space-y-1">
                          <label className="text-[10px] font-mono text-gray-400">Gönderen Cüzdan Adresiniz</label>
                          <input
                            type="text"
                            placeholder="Örn: 0x..."
                            value={cryptoWalletAddress}
                            onChange={(e) => setCryptoWalletAddress(e.target.value)}
                            className="w-full rounded-lg border border-gray-800 bg-gray-900/40 p-2 text-xs text-white font-mono focus:border-emerald-500 focus:outline-none"
                            required={paymentMethod === 'crypto'}
                          />
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Option 4: Mobile Payment */}
                  {paymentMethod === 'mobile' && (
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="text-xs font-bold text-white flex items-center gap-1.5">
                          <Smartphone className="h-3.5 w-3.5 text-teal-400" />
                          <span>Hızlı Mobil Ödeme Entegrasyonu</span>
                        </div>
                        <span className="text-[10px] font-mono text-gray-500">Faturanıza Yansıtılır</span>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        {/* Mobile Phone */}
                        <div className="space-y-1">
                          <label className="text-[10px] font-mono text-gray-400">Telefon Numaranız</label>
                          <input
                            type="text"
                            placeholder="0 (555) 123 4567"
                            value={mobilePhone}
                            onChange={(e) => {
                              // Phone numbers numbers only
                              const cleaned = e.target.value.replace(/\D/g, '');
                              setMobilePhone(cleaned);
                            }}
                            className="w-full rounded-lg border border-gray-800 bg-gray-900/40 p-2.5 text-xs text-white font-mono focus:border-emerald-500 focus:outline-none"
                            required={paymentMethod === 'mobile'}
                          />
                        </div>

                        {/* Mobile Carrier */}
                        <div className="space-y-1">
                          <label className="text-[10px] font-mono text-gray-400">Gsm Operatörü</label>
                          <select
                            value={mobileCarrier}
                            onChange={(e) => setMobileCarrier(e.target.value)}
                            className="w-full rounded-lg border border-gray-800 bg-gray-900/40 p-2.5 text-xs text-white focus:border-emerald-500 focus:outline-none"
                          >
                            <option value="Turkcell">Turkcell</option>
                            <option value="Vodafone">Vodafone</option>
                            <option value="Türk Telekom">Türk Telekom</option>
                            <option value="BIMcell">BIMcell</option>
                          </select>
                        </div>
                      </div>

                      <div className="rounded-lg border border-gray-800 bg-amber-500/5 p-2.5 text-[10px] text-amber-300 flex items-start gap-1.5">
                        <ShieldAlert className="h-3.5 w-3.5 shrink-0 text-amber-400 mt-0.5" />
                        <div>
                          Ödeme butonuna bastıktan sonra telefonunuza gelecek olan onay SMS'ini onaylamanız durumunda ödeme bir sonraki faturanıza yansıtılacaktır. Ek komisyon oranı %1.5.
                        </div>
                      </div>
                    </div>
                  )}

                  {/* SAVE DETAILS CHECKBOX & REMEMBER ME */}
                  <div className="flex items-center gap-2 pt-2 border-t border-gray-800/60">
                    <input
                      type="checkbox"
                      id="save-payment-pref"
                      checked={savePaymentInfo}
                      onChange={(e) => setSavePaymentInfo(e.target.checked)}
                      className="rounded border-gray-800 bg-gray-900 text-emerald-500 focus:ring-0 cursor-pointer h-4 w-4"
                    />
                    <label htmlFor="save-payment-pref" className="text-[11px] text-gray-300 font-sans cursor-pointer select-none">
                      Ödeme ve fatura detaylarımı gelecekteki alışverişler için bu tarayıcıda <strong>güvenle kaydet (Yerel Depolama)</strong>.
                    </label>
                  </div>
                </div>

                {/* Extended Warranty */}
                <div className="md:col-span-2 space-y-1.5">
                  <button
                    type="button"
                    onClick={() => setWarranty(!warranty)}
                    className={`w-full rounded-xl border p-3 text-xs font-semibold transition-all flex items-center justify-between cursor-pointer ${
                      warranty
                        ? 'border-emerald-500 bg-emerald-500/10 text-emerald-400 font-bold'
                        : 'border-gray-800 bg-gray-900/40 text-gray-400 hover:border-gray-700'
                    }`}
                  >
                    <span className="flex items-center gap-2">
                      <ShieldCheck className={`h-4 w-4 ${warranty ? 'text-emerald-400' : 'text-gray-500'}`} />
                      +3 Yıl Ekstra Güvence Paketi & Teknik Destek Desteği
                    </span>
                    <span className="font-mono text-[10px] text-gray-500">(+8% - ${Math.round(basePrice * 0.08)} USD)</span>
                  </button>
                </div>

              </div>

              {/* Price Calculation Breakdowns */}
              <div className="rounded-xl border border-gray-800 bg-gray-900/20 p-4 space-y-2 text-xs font-mono">
                <div className="flex justify-between text-gray-400">
                  <span>Cihaz Bedeli:</span>
                  <span>${basePrice.toLocaleString()}</span>
                </div>
                {shippingCost > 0 && (
                  <div className="flex justify-between text-gray-400">
                    <span>Hızlı Kurye Kargo:</span>
                    <span>+${shippingCost}</span>
                  </div>
                )}
                {warrantyCost > 0 && (
                  <div className="flex justify-between text-gray-400">
                    <span>+3 Yıl Ekstra Güvence:</span>
                    <span>+${warrantyCost}</span>
                  </div>
                )}
                <div className="flex justify-between text-gray-400">
                  <span>Vergiler ve KDV (%18):</span>
                  <span>+${tax.toLocaleString()}</span>
                </div>
                <div className="border-t border-gray-800 pt-2 flex justify-between font-bold text-sm text-emerald-400">
                  <span className="font-display font-bold">Toplam Ödeme Tutarı:</span>
                  <span>${totalPrice.toLocaleString()} USD</span>
                </div>
              </div>

              {/* Checkout CTA */}
              <button
                id="btn-confirm-checkout"
                type="submit"
                disabled={loading || !fullName || !address}
                className="w-full rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 py-3 text-xs font-bold text-dark-bg transition-all disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                {loading ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin text-dark-bg" />
                    Ödeme Güvenlik Sunucusu Doğrulanıyor...
                  </>
                ) : (
                  <>
                    <Check className="h-4 w-4 text-dark-bg" />
                    Ödemeyi Tamamla ve Siparişi Onayla
                  </>
                )}
              </button>

            </form>
          ) : (
            /* SUCCESS CONFIRMATION PANEL */
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="p-8 text-center space-y-6"
            >
              <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
                <Check className="h-8 w-8" />
              </div>

              <div className="space-y-2">
                <h3 className="font-display text-xl font-bold text-white">Siparişiniz Başarıyla Oluşturuldu!</h3>
                <p className="text-sm text-gray-300 leading-relaxed max-w-md mx-auto">
                  Sayın <strong>{fullName}</strong>, <strong>{product.name}</strong> cihazınızın sipariş simülasyonu <strong>{store.storeName}</strong> üzerinde başarıyla tamamlanmıştır.
                </p>
              </div>

              {/* Shipping card details */}
              <div className="rounded-xl border border-gray-800 bg-gray-900/40 p-4 max-w-sm mx-auto text-left space-y-2 text-xs font-mono">
                <div className="flex justify-between text-gray-400">
                  <span>Takip Numarasi:</span>
                  <span className="text-emerald-400 font-bold">{orderIdRef}</span>
                </div>
                <div className="flex justify-between text-gray-400">
                  <span>Gonderici Magaza:</span>
                  <span className="text-white">{store.storeName}</span>
                </div>
                <div className="flex justify-between text-gray-400">
                  <span>Teslimat Adresi:</span>
                  <span className="text-white max-w-[60%] truncate text-right">{address}</span>
                </div>
                <div className="flex justify-between text-gray-400">
                  <span>Kargo Hizi:</span>
                  <span className="text-white">{shippingMethod === 'standard' ? 'Standart (Ucretsiz)' : 'Hizli Kurye (Express)'}</span>
                </div>
              </div>

              {/* PDF Download Button */}
              <div className="max-w-xs mx-auto">
                <button
                  type="button"
                  id="btn-download-pdf-invoice"
                  onClick={handleDownloadInvoice}
                  className="w-full rounded-xl bg-teal-500/10 border border-teal-500/30 text-teal-400 hover:bg-teal-500/20 py-2.5 text-xs font-semibold flex items-center justify-center gap-2 transition-all cursor-pointer"
                >
                  <FileText className="h-4 w-4" />
                  E-Faturayi PDF Olarak Indir
                </button>
              </div>

              <div className="text-xs text-gray-500 max-w-sm mx-auto leading-relaxed">
                Bu akis, fiyat karsilastirma ve pazar yeri entegrasyonu deneyimini canlandirmak amaciyla kurgulanan bir gorsel akistir. Herhangi bir ucret tahsilati yapilmamistir.
              </div>

              <button
                id="btn-sim-success-close"
                onClick={onClose}
                className="w-full max-w-xs rounded-xl bg-gray-800 border border-gray-700 hover:bg-gray-700 py-2.5 text-xs font-semibold text-white transition-all cursor-pointer"
              >
                Pencereyi Kapat ve Ana Sayfaya Don
              </button>

            </motion.div>
          )}

        </motion.div>
      </div>
    </AnimatePresence>
  );
}
