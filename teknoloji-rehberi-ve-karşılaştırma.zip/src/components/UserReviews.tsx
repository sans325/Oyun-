import React, { useState, useEffect } from 'react';
import { Product } from '../data/products';
import { Star, MessageSquare, Send, CheckCircle2, User, Award } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface UserReview {
  id: string;
  username: string;
  rating: number;
  comment: string;
  date: string;
  isVerified: boolean;
}

interface UserReviewsProps {
  product: Product;
}

const PRESET_REVIEWS: Record<string, UserReview[]> = {
  'apple-vision-pro-2': [
    {
      id: 'r1',
      username: 'Ahsen Yılmaz',
      rating: 5,
      comment: 'Ekran kalitesi ve piksel yoğunluğu tek kelimeyle kusursuz. visionOS 3.0 ile el hareketleri inanılmaz doğal hissettiriyor. Mekansal sinema modunda film izlemek devasa IMAX salonunda olmak gibi.',
      date: '10 Haziran 2026',
      isVerified: true
    },
    {
      id: 'r2',
      username: 'Caner Demirel',
      rating: 4,
      comment: 'Cihazın sunduğu teknoloji harika ancak ağırlığı 600 grama yakın olduğu için bir saatten sonra yüzü yorabiliyor. Batarya kablosu bazen takılıyor fakat ekran netliği tüm eksileri unutturuyor.',
      date: '28 Mayıs 2026',
      isVerified: true
    }
  ],
  'nvidia-rtx-5090': [
    {
      id: 'r3',
      username: 'Volkan Şahin',
      rating: 5,
      comment: 'Yapay zeka çıkarım hızları ve Unreal Engine render sürelerim tam anlamıyla yarı yarıya düştü. 32GB GDDR7 devasa modelleri yüklemek için muhteşem. Güç tüketimi yüksek ama performans rakipsiz.',
      date: '12 Temmuz 2026',
      isVerified: true
    },
    {
      id: 'r4',
      username: 'Gökhan Kaya',
      rating: 4,
      comment: 'Canavar gibi bir kart ancak almadan önce kasanızın derinliğini ve güç kaynağınızı (min 1000W) kesinlikle kontrol edin. DLSS 4.5 ile 4K çözünürlükte ışın izleme açıkken bile 150 FPS üstü stabil.',
      date: '2 Temmuz 2026',
      isVerified: false
    }
  ],
  'framework-laptop-16': [
    {
      id: 'r5',
      username: 'Buse Aksoy',
      rating: 5,
      comment: 'Sürdürülebilirlik felsefesine bayıldım. Anakartı ve portları kendim saniyeler içinde değiştirebiliyorum. Modüler GPU bölmesi sayesinde gelecekte tüm kasayı değiştirmeden sadece ekran kartını yükselteceğim.',
      date: '18 Haziran 2026',
      isVerified: true
    }
  ],
  'samsung-galaxy-ring': [
    {
      id: 'r6',
      username: 'Murat Aktaş',
      rating: 5,
      comment: 'Akıllı saatlerin hantallığından sonra bu yüzük mucize gibi. Uyurken parmağımda olduğunu bile hissetmiyorum. Kalp ritmi ve HRV takibi son derece stabil çalışıyor, şarjı tam 7 gün gidiyor.',
      date: '3 Temmuz 2026',
      isVerified: true
    }
  ],
  'tesla-optimus-devkit': [
    {
      id: 'r7',
      username: 'Doç. Dr. Emre Çelik',
      rating: 5,
      comment: 'Üniversite yapay zeka ve robotik laboratuvarımız için aldık. Python SDK desteği son derece derinlemesine hazırlanmış. Tesla FSD yongasının gerçek zamanlı çevre haritalama kararlılığı nefes kesici.',
      date: '25 Haziran 2026',
      isVerified: true
    }
  ],
  'starlink-mini': [
    {
      id: 'r8',
      username: 'Selin Deniz',
      rating: 5,
      comment: 'Ege kıyılarında ve dağlık kamp rotalarında denedim. 100W Powerbank ile çalışabilmesi inanılmaz pratik. Ormanın göbeğinde 130 Mbps download hızına ulaştık, karavancılar için kesinlikle olmazsa olmaz.',
      date: '1 Temmuz 2026',
      isVerified: true
    }
  ]
};

export default function UserReviews({ product }: UserReviewsProps) {
  const [reviews, setReviews] = useState<UserReview[]>([]);
  const [newUsername, setNewUsername] = useState('');
  const [newRating, setNewRating] = useState(5);
  const [newComment, setNewComment] = useState('');
  const [newIsVerified, setNewIsVerified] = useState(true);
  const [formSuccess, setFormSuccess] = useState(false);

  // Load reviews on mount or product change
  useEffect(() => {
    const key = `tekno_reviews_${product.id}`;
    const stored = localStorage.getItem(key);
    if (stored) {
      setReviews(JSON.parse(stored));
    } else {
      const presets = PRESET_REVIEWS[product.id] || [];
      setReviews(presets);
      localStorage.setItem(key, JSON.stringify(presets));
    }
    setFormSuccess(false);
  }, [product.id]);

  // Handle new review submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUsername.trim() || !newComment.trim()) return;

    const newReview: UserReview = {
      id: `r_${Date.now()}`,
      username: newUsername.trim(),
      rating: newRating,
      comment: newComment.trim(),
      date: new Date().toLocaleDateString('tr-TR', { day: 'numeric', month: 'long', year: 'numeric' }),
      isVerified: newIsVerified
    };

    const updatedReviews = [newReview, ...reviews];
    setReviews(updatedReviews);
    localStorage.setItem(`tekno_reviews_${product.id}`, JSON.stringify(updatedReviews));

    // Reset fields
    setNewUsername('');
    setNewComment('');
    setNewRating(5);
    setFormSuccess(true);
    setTimeout(() => setFormSuccess(false), 4000);
  };

  // Stats calculation
  const totalReviews = reviews.length;
  const avgRating = totalReviews > 0 
    ? parseFloat((reviews.reduce((acc, r) => acc + r.rating, 0) / totalReviews).toFixed(1))
    : 5.0;

  const starDistribution = [5, 4, 3, 2, 1].map(star => {
    const count = reviews.filter(r => r.rating === star).length;
    const percentage = totalReviews > 0 ? (count / totalReviews) * 100 : 0;
    return { star, count, percentage };
  });

  return (
    <div className="space-y-6">
      {/* Summary Scorecard Box */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-gray-900/40 border border-gray-800/80 rounded-2xl p-5">
        {/* Big score */}
        <div className="flex flex-col items-center justify-center text-center border-b md:border-b-0 md:border-r border-gray-800 pb-4 md:pb-0">
          <span className="text-4xl font-extrabold font-display text-white">{avgRating}</span>
          <div className="flex items-center gap-0.5 my-1.5">
            {Array.from({ length: 5 }).map((_, i) => (
              <Star
                key={i}
                className={`h-4.5 w-4.5 ${
                  i < Math.round(avgRating) ? 'fill-teal-400 text-teal-400' : 'text-gray-700'
                }`}
              />
            ))}
          </div>
          <span className="text-xs font-mono text-gray-400">
            {totalReviews} Değerlendirme
          </span>
        </div>

        {/* Breakdown bar chart */}
        <div className="col-span-1 md:col-span-2 space-y-2.5">
          <h4 className="text-[11px] font-mono text-gray-400 uppercase tracking-wider font-semibold">
            Puan Dağılımı
          </h4>
          {starDistribution.map(({ star, count, percentage }) => (
            <div key={star} className="flex items-center gap-3 text-xs font-mono">
              <span className="w-3 text-gray-400">{star}★</span>
              <div className="flex-1 h-2 bg-gray-950 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-teal-500 rounded-full transition-all duration-500" 
                  style={{ width: `${percentage}%` }}
                />
              </div>
              <span className="w-8 text-right text-gray-500">{count}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Main Grid: Feedback list + Submission form */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        
        {/* Submission Form (2/5 size) */}
        <div className="lg:col-span-2 rounded-xl border border-gray-800 bg-gray-950/20 p-4 space-y-4 h-fit">
          <div className="flex items-center gap-1.5 border-b border-gray-900 pb-2">
            <MessageSquare className="h-4 w-4 text-teal-400" />
            <h4 className="font-display text-sm font-bold text-white">Deneyimini Paylaş</h4>
          </div>

          {formSuccess ? (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="rounded-lg bg-emerald-950/30 border border-emerald-800/40 p-4 text-xs text-emerald-400 flex items-start gap-2.5"
            >
              <CheckCircle2 className="h-5 w-5 text-emerald-400 shrink-0" />
              <div>
                <div className="font-bold mb-1">Değerlendirmeniz Gönderildi!</div>
                <p className="text-gray-300 leading-relaxed">
                  Geri bildiriminiz başarıyla kaydedildi ve pazar yeri topluluğuna katıldı. Teşekkür ederiz!
                </p>
              </div>
            </motion.div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Username */}
              <div>
                <label className="block text-[10px] font-mono text-gray-400 mb-1">Adınız Soyadınız:</label>
                <div className="relative">
                  <User className="absolute left-3 top-2.5 h-4 w-4 text-gray-500" />
                  <input
                    type="text"
                    required
                    placeholder="Örn: Sencer Karahan"
                    value={newUsername}
                    onChange={(e) => setNewUsername(e.target.value)}
                    className="w-full rounded-xl border border-gray-800 bg-gray-900/60 pl-9 pr-4 py-2 text-xs text-white placeholder-gray-600 focus:border-teal-500 focus:outline-none focus:ring-1 focus:ring-teal-500"
                  />
                </div>
              </div>

              {/* Stars selection */}
              <div>
                <label className="block text-[10px] font-mono text-gray-400 mb-1">Puanınız:</label>
                <div className="flex items-center gap-1">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      type="button"
                      key={star}
                      onClick={() => setNewRating(star)}
                      className="p-1 hover:scale-110 transition-transform"
                    >
                      <Star
                        className={`h-6 w-6 ${
                          star <= newRating 
                            ? 'fill-teal-400 text-teal-400' 
                            : 'text-gray-700 hover:text-teal-400/40'
                        }`}
                      />
                    </button>
                  ))}
                </div>
              </div>

              {/* Verified purchase checkbox */}
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setNewIsVerified(!newIsVerified)}
                  className={`relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                    newIsVerified ? 'bg-teal-500' : 'bg-gray-800'
                  }`}
                >
                  <span
                    className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                      newIsVerified ? 'translate-x-4' : 'translate-x-0'
                    }`}
                  />
                </button>
                <div className="space-y-0">
                  <span className="block text-[11px] font-semibold text-white">Doğrulanmış Satın Alım</span>
                  <span className="block text-[9px] text-gray-500">Cihaza sahip olduğunuzu onaylar</span>
                </div>
              </div>

              {/* Comment text */}
              <div>
                <label className="block text-[10px] font-mono text-gray-400 mb-1">Değerlendirmeniz (Türkçe):</label>
                <textarea
                  required
                  rows={4}
                  placeholder="Cihazın donanım performansı, ekranı, pazar yeri teslimat süresi ve günlük deneyiminiz hakkında detaylı görüşlerinizi yazın..."
                  value={newComment}
                  onChange={(e) => setNewComment(e.target.value)}
                  className="w-full rounded-xl border border-gray-800 bg-gray-900/60 p-3 text-xs text-white placeholder-gray-600 focus:border-teal-500 focus:outline-none focus:ring-1 focus:ring-teal-500 resize-none leading-relaxed"
                />
              </div>

              {/* Submit btn */}
              <button
                type="submit"
                className="w-full rounded-xl bg-teal-500 hover:bg-teal-600 py-2.5 text-xs font-bold text-dark-bg transition-all flex items-center justify-center gap-1.5"
              >
                <Send className="h-3.5 w-3.5" />
                Yorumu Gönder
              </button>
            </form>
          )}
        </div>

        {/* Feedback List (3/5 size) */}
        <div className="lg:col-span-3 space-y-4">
          <div className="flex items-center justify-between border-b border-gray-900 pb-2">
            <h4 className="text-xs font-mono text-gray-400 uppercase tracking-wider font-semibold">
              Kullanıcı Yorumları ({reviews.length})
            </h4>
            <span className="text-[10px] text-teal-400 bg-teal-950/40 border border-teal-800/40 px-2 py-0.5 rounded-md font-mono">
              Live Topluluk
            </span>
          </div>

          <div className="max-h-[420px] overflow-y-auto space-y-3.5 pr-1.5">
            {reviews.length === 0 ? (
              <div className="text-center py-12 text-gray-500 text-xs">
                Bu cihaz için henüz kullanıcı incelemesi yapılmamış. İlk yorumu siz yazın!
              </div>
            ) : (
              reviews.map((review) => (
                <div 
                  key={review.id} 
                  className="p-4 rounded-xl border border-gray-800/60 bg-gray-900/20 space-y-2.5 hover:border-gray-800 transition-colors"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      {/* Name + verify badge */}
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-bold text-white font-sans">{review.username}</span>
                        {review.isVerified && (
                          <span className="inline-flex items-center gap-0.5 text-[9px] bg-emerald-950/50 border border-emerald-800/30 text-emerald-400 px-1.5 py-0.5 rounded-full font-mono font-bold">
                            <Award className="h-2.5 w-2.5" />
                            Doğrulandı
                          </span>
                        )}
                      </div>
                      <span className="text-[10px] text-gray-500 font-mono block mt-0.5">{review.date}</span>
                    </div>

                    {/* Star row */}
                    <div className="flex items-center gap-0.5 bg-gray-950/40 border border-gray-800/40 px-2 py-1 rounded-lg">
                      {Array.from({ length: 5 }).map((_, idx) => (
                        <Star
                          key={idx}
                          className={`h-3 w-3 ${
                            idx < review.rating ? 'fill-teal-400 text-teal-400' : 'text-gray-800'
                          }`}
                        />
                      ))}
                    </div>
                  </div>

                  <p className="text-xs text-gray-300 leading-relaxed break-words font-sans font-normal">
                    {review.comment}
                  </p>
                </div>
              ))
            )}
          </div>
        </div>

      </div>
    </div>
  );
}
