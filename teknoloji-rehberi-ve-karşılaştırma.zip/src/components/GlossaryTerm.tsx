import React, { useState } from 'react';
import { GLOSSARY } from '../data/glossary';
import { HelpCircle } from 'lucide-react';

interface GlossaryTermProps {
  children: string;
}

// Interactive Sub-Component for each individual highlighted term
function InteractiveTerm({ term, definition }: { term: string; definition: string; key?: React.Key }) {
  const [showTooltip, setShowTooltip] = useState(false);

  return (
    <span
      className="relative inline-flex items-center gap-0.5 group cursor-help focus:outline-none"
      onMouseEnter={() => setShowTooltip(true)}
      onMouseLeave={() => setShowTooltip(false)}
      onFocus={() => setShowTooltip(true)}
      onBlur={() => setShowTooltip(false)}
      tabIndex={0}
      aria-haspopup="true"
    >
      <span className="underline decoration-dashed decoration-teal-400/80 underline-offset-4 font-semibold text-teal-300 hover:text-teal-400 transition-colors">
        {term}
      </span>
      <HelpCircle className="h-3 w-3 text-teal-400/60 group-hover:text-teal-400 transition-colors" />

      {showTooltip && (
        <span 
          className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2.5 w-64 p-3 bg-gray-950 border border-teal-500/40 rounded-xl shadow-2xl shadow-black/80 z-50 text-left pointer-events-none animate-in fade-in slide-in-from-bottom-1 duration-150"
          role="tooltip"
        >
          <span className="block text-xs font-bold text-teal-400 font-display mb-1 border-b border-gray-800 pb-1">
            {term}
          </span>
          <span className="block text-[11px] leading-relaxed text-gray-300 font-sans normal-case font-normal whitespace-normal">
            {definition}
          </span>
        </span>
      )}
    </span>
  );
}

export default function GlossaryTerm({ children }: GlossaryTermProps) {
  if (!children || typeof children !== 'string') {
    return <span>{children}</span>;
  }

  // Get keys sorted by length descending so that longer keys (e.g., "Mikro-OLED") match before shorter keys ("OLED")
  const keys = Object.keys(GLOSSARY).sort((a, b) => b.length - a.length);
  
  if (keys.length === 0) {
    return <span>{children}</span>;
  }

  // Escape regex special chars
  const escapeRegExp = (string: string) => {
    return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  };

  // Construct match pattern: \b(term1|term2|term3)\b or matches without strict boundary for Turkish characters
  // Because \b doesn't support Turkish chars perfectly, we use custom capturing
  const pattern = `(${keys.map(escapeRegExp).join('|')})`;
  const regex = new RegExp(pattern, 'gi');

  const parts = children.split(regex);

  return (
    <span>
      {parts.map((part, index) => {
        // Find exact casing matching key in glossary
        const matchingKey = keys.find(k => k.toLowerCase() === part.toLowerCase());
        
        if (matchingKey) {
          const definition = GLOSSARY[matchingKey];
          return (
            <InteractiveTerm 
              key={index} 
              term={part} 
              definition={definition} 
            />
          );
        }
        return <span key={index}>{part}</span>;
      })}
    </span>
  );
}
