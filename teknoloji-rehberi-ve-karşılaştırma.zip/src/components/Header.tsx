import React, { useState } from 'react';
import { 
  Cpu, Scale, Sparkles, ShoppingBag, Terminal, Sun, Moon, Heart, 
  Keyboard, Truck, Bell, BellRing, CheckCheck, Trash2 
} from 'lucide-react';

interface HeaderProps {
  activeTab: 'catalog' | 'compare' | 'ai-advisor';
  setActiveTab: (tab: 'catalog' | 'compare' | 'ai-advisor') => void;
  compareCount: number;
  favoritesCount: number;
  ordersCount: number;
  theme: 'dark' | 'light';
  toggleTheme: () => void;
  onOpenFavorites: () => void;
  onOpenShortcuts: () => void;
  onOpenOrders: () => void;
  notifications: any[];
  setNotifications: React.Dispatch<React.SetStateAction<any[]>>;
}

export default function Header({ 
  activeTab, 
  setActiveTab, 
  compareCount, 
  favoritesCount,
  ordersCount,
  theme, 
  toggleTheme,
  onOpenFavorites,
  onOpenShortcuts,
  onOpenOrders,
  notifications,
  setNotifications
}: HeaderProps) {
  const [showBellDropdown, setShowBellDropdown] = useState(false);

  const unreadCount = notifications.filter(n => !n.read).length;

  const handleMarkAllRead = () => {
    const updated = notifications.map(n => ({ ...n, read: true }));
    setNotifications(updated);
    localStorage.setItem('tekno_notifications', JSON.stringify(updated));
  };

  const handleToggleRead = (id: string) => {
    const updated = notifications.map(n => n.id === id ? { ...n, read: !n.read } : n);
    setNotifications(updated);
    localStorage.setItem('tekno_notifications', JSON.stringify(updated));
  };

  const handleClearNotifications = () => {
    setNotifications([]);
    localStorage.removeItem('tekno_notifications');
  };

  return (
    <header className="sticky top-0 z-40 w-full border-b border-gray-800 bg-dark-bg/85 backdrop-blur-md">
      <div className="mx-auto flex max-w-7xl h-16 items-center justify-between px-4 sm:px-6 lg:px-8">
        
        {/* Logo and Brand */}
        <div className="flex items-center space-x-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-tr from-teal-500 to-emerald-400 p-2 text-dark-bg shadow-lg shadow-teal-500/10">
            <Cpu className="h-6 w-6" />
          </div>
          <div>
            <span className="font-display text-xl font-bold tracking-tight text-white flex items-center gap-1.5">
              TEKNO<span className="text-teal-400">ANALİZ</span>
            </span>
            <div className="hidden sm:flex items-center gap-1 text-[10px] font-mono text-gray-500 uppercase tracking-widest">
              <Terminal className="h-2.5 w-2.5 text-teal-500" />
              <span>Gelecegin Teknolojik Karsilastirma Portali</span>
            </div>
          </div>
        </div>

        {/* Navigation Tabs and Theme Toggle */}
        <div className="flex items-center space-x-1.5 sm:space-x-3">
          <nav className="flex space-x-1 sm:space-x-1.5">
            <button
              id="tab-catalog"
              onClick={() => setActiveTab('catalog')}
              className={`flex items-center space-x-1.5 rounded-lg px-2.5 py-1.5 text-xs sm:text-sm font-medium transition-all duration-200 ${
                activeTab === 'catalog'
                  ? 'bg-gray-800 text-teal-400 border border-gray-700'
                  : 'text-gray-400 hover:bg-gray-900 hover:text-white'
              }`}
            >
              <ShoppingBag className="h-3.5 w-3.5" />
              <span className="hidden md:inline">Teknoloji Katalogu</span>
              <span className="inline md:hidden">Katalog</span>
            </button>

            <button
              id="tab-compare"
              onClick={() => setActiveTab('compare')}
              className={`relative flex items-center space-x-1.5 rounded-lg px-2.5 py-1.5 text-xs sm:text-sm font-medium transition-all duration-200 ${
                activeTab === 'compare'
                  ? 'bg-gray-800 text-teal-400 border border-gray-700'
                  : 'text-gray-400 hover:bg-gray-900 hover:text-white'
              }`}
            >
              <Scale className="h-3.5 w-3.5" />
              <span className="hidden md:inline">Karsilastirma Arenasi</span>
              <span className="inline md:hidden">Kiyasla</span>
              {compareCount > 0 && (
                <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-teal-500 text-[10px] font-bold text-dark-bg">
                  {compareCount}
                </span>
              )}
            </button>

            <button
              id="tab-advisor"
              onClick={() => setActiveTab('ai-advisor')}
              className={`flex items-center space-x-1.5 rounded-lg px-2.5 py-1.5 text-xs sm:text-sm font-medium transition-all duration-200 ${
                activeTab === 'ai-advisor'
                  ? 'bg-teal-500/10 text-teal-400 border border-teal-500/20'
                  : 'text-gray-400 hover:bg-gray-900 hover:text-white'
              }`}
            >
              <Sparkles className="h-3.5 w-3.5 animate-pulse text-teal-400" />
              <span>TeknoAsistan AI</span>
            </button>
          </nav>

          <div className="flex items-center space-x-1.5">
            {/* Keyboard Shortcuts Button */}
            <button
              onClick={onOpenShortcuts}
              id="shortcuts-btn"
              className="flex h-8 w-8 sm:h-9 sm:w-9 items-center justify-center rounded-lg border border-gray-800 text-gray-400 hover:text-white hover:bg-gray-900 transition-all focus:outline-none shrink-0"
              title="Klavye Kisayollari (Ctrl+K)"
            >
              <Keyboard className="h-4 w-4" />
            </button>

            {/* Favorites Button */}
            <button
              onClick={onOpenFavorites}
              id="favorites-btn"
              className="relative flex h-8 w-8 sm:h-9 sm:w-9 items-center justify-center rounded-lg border border-gray-800 text-gray-400 hover:text-red-400 hover:bg-gray-900 transition-all focus:outline-none shrink-0"
              title="Favorilerim"
            >
              <Heart className={`h-4 w-4 ${favoritesCount > 0 ? 'fill-red-500 text-red-500' : ''}`} />
              {favoritesCount > 0 && (
                <span className="absolute -top-1 -right-1 flex h-4.5 w-4.5 items-center justify-center rounded-full bg-red-500 text-[9px] font-bold text-white font-mono">
                  {favoritesCount}
                </span>
              )}
            </button>

            {/* Order Tracking Button */}
            <button
              onClick={onOpenOrders}
              id="orders-btn"
              className="relative flex h-8 w-8 sm:h-9 sm:w-9 items-center justify-center rounded-lg border border-gray-800 text-gray-400 hover:text-teal-400 hover:bg-gray-900 transition-all focus:outline-none shrink-0"
              title="Siparis Takip"
            >
              <Truck className={`h-4 w-4 ${ordersCount > 0 ? 'text-teal-400 animate-pulse' : ''}`} />
              {ordersCount > 0 && (
                <span className="absolute -top-1 -right-1 flex h-4.5 w-4.5 items-center justify-center rounded-full bg-teal-500 text-[9px] font-bold text-dark-bg font-mono">
                  {ordersCount}
                </span>
              )}
            </button>

            {/* Notification Bell Dropdown Button */}
            <div className="relative shrink-0">
              <button
                onClick={() => setShowBellDropdown(!showBellDropdown)}
                id="notification-bell-btn"
                className="relative flex h-8 w-8 sm:h-9 sm:w-9 items-center justify-center rounded-lg border border-gray-800 text-gray-400 hover:text-teal-400 hover:bg-gray-900 transition-all focus:outline-none shrink-0 cursor-pointer"
                title="Bildirimler"
              >
                {unreadCount > 0 ? (
                  <BellRing className="h-4 w-4 text-amber-400 animate-bounce" />
                ) : (
                  <Bell className="h-4 w-4" />
                )}
                {unreadCount > 0 && (
                  <span className="absolute -top-1 -right-1 flex h-4.5 w-4.5 items-center justify-center rounded-full bg-red-500 text-[9px] font-bold text-white font-mono">
                    {unreadCount}
                  </span>
                )}
              </button>

              {showBellDropdown && (
                <div className="absolute right-0 mt-2.5 w-80 rounded-2xl border border-gray-800 bg-dark-bg/95 backdrop-blur-md shadow-2xl p-4 text-white z-50 space-y-3">
                  <div className="flex items-center justify-between border-b border-gray-800 pb-2">
                    <span className="text-xs font-bold flex items-center gap-1.5">
                      <Bell className="h-3.5 w-3.5 text-teal-400" />
                      Bildirim Kutusu
                    </span>
                    <div className="flex gap-2">
                      <button
                        onClick={handleMarkAllRead}
                        className="text-[9px] font-bold text-teal-400 hover:underline cursor-pointer"
                        title="Tumunu Okundu Say"
                      >
                        Tumunu Oku
                      </button>
                      <button
                        onClick={handleClearNotifications}
                        className="text-[9px] font-bold text-rose-400 hover:underline cursor-pointer"
                        title="Bildirimleri Temizle"
                      >
                        Temizle
                      </button>
                    </div>
                  </div>

                  <div className="max-h-60 overflow-y-auto space-y-2 pr-1 select-none">
                    {notifications.length === 0 ? (
                      <div className="text-center py-6 text-xs text-gray-500 italic">
                        Yeni bildirim bulunmuyor.
                      </div>
                    ) : (
                      notifications.map((notif) => (
                        <div
                          key={notif.id}
                          onClick={() => handleToggleRead(notif.id)}
                          className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                            notif.read 
                              ? 'border-gray-800/40 bg-gray-900/10 opacity-60' 
                              : 'border-teal-500/20 bg-teal-500/5'
                          }`}
                        >
                          <div className="flex items-start justify-between gap-1.5">
                            <span className="text-[11px] font-bold text-white leading-tight">
                              {notif.title}
                            </span>
                            {!notif.read && (
                              <span className="h-1.5 w-1.5 rounded-full bg-red-500 mt-1 shrink-0" />
                            )}
                          </div>
                          <p className="text-[10px] text-gray-300 mt-1 leading-normal">
                            {notif.message}
                          </p>
                          <div className="text-[8px] font-mono text-gray-500 text-right mt-1.5">
                            {notif.date}
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Theme Toggle */}
            <button
              onClick={toggleTheme}
              id="theme-toggle"
              className="flex h-8 w-8 sm:h-9 sm:w-9 items-center justify-center rounded-lg border border-gray-800 text-gray-400 hover:text-white hover:bg-gray-900 transition-all focus:outline-none shrink-0"
              title={theme === 'dark' ? 'Acik Temaya Gec' : 'Karanlik Temaya Gec'}
            >
              {theme === 'dark' ? <Sun className="h-4 w-4 text-amber-400" /> : <Moon className="h-4 w-4 text-indigo-500" />}
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}
