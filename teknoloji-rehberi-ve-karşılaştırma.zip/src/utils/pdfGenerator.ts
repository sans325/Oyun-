import { jsPDF } from 'jspdf';

export interface InvoiceData {
  orderId: string;
  productName: string;
  storeName: string;
  basePrice: number;
  tax: number;
  shippingCost: number;
  warrantyCost: number;
  totalPrice: number;
  fullName: string;
  address: string;
  paymentMethod: string;
  orderDate: string;
  specs: { label: string; value: string }[];
}

export function generateInvoicePDF(data: InvoiceData) {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  // Color Palette
  const primaryColor = [13, 148, 136]; // Teal #0d9488
  const darkColor = [31, 41, 55]; // Gray-800
  const lightColor = [243, 244, 246]; // Gray-100
  const accentColor = [16, 185, 129]; // Emerald #10b981

  // Page Width & Height
  const pageWidth = doc.internal.pageSize.width;
  
  // Header Accent Bar
  doc.setFillColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.rect(0, 0, pageWidth, 12, 'F');

  // Title / Logo
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(14);
  doc.text('TEKNOMARKET QUANTUM PLATFORM', 15, 8);

  // Invoice Label
  doc.setTextColor(darkColor[0], darkColor[1], darkColor[2]);
  doc.setFontSize(22);
  doc.text('SATIS FATURASI / RECEIPT', 15, 28);
  
  // Status Banner
  doc.setFillColor(209, 250, 229); // light green bg
  doc.rect(140, 20, 55, 10, 'F');
  doc.setTextColor(5, 150, 105); // dark green text
  doc.setFontSize(10);
  doc.setFont('helvetica', 'bold');
  doc.text('ODEME ALINDI / PAID', 145, 26);

  // Underline
  doc.setDrawColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.setLineWidth(0.8);
  doc.line(15, 32, pageWidth - 15, 32);

  // Metadata Columns
  doc.setTextColor(100, 116, 139);
  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.text('Fatura Detaylari / Invoice Details:', 15, 42);
  doc.text('Musteri Detaylari / Customer:', 110, 42);

  doc.setTextColor(darkColor[0], darkColor[1], darkColor[2]);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.text(`Fatura No / Order ID: ${data.orderId}`, 15, 48);
  doc.text(`Tarih / Date: ${new Date(data.orderDate).toLocaleString('tr-TR')}`, 15, 54);
  doc.text(`Odeme Tipi / Payment: ${data.paymentMethod.toUpperCase()}`, 15, 60);

  doc.text(data.fullName, 110, 48);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  const splitAddress = doc.splitTextToSize(data.address, 85);
  doc.text(splitAddress, 110, 54);

  // Line Separator
  doc.setDrawColor(229, 231, 235);
  doc.setLineWidth(0.5);
  doc.line(15, 70, pageWidth - 15, 70);

  // Table Header
  doc.setFillColor(lightColor[0], lightColor[1], lightColor[2]);
  doc.rect(15, 75, pageWidth - 30, 8, 'F');
  doc.setTextColor(75, 85, 99);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.text('Urun Aciklamasi / Product Name', 18, 80.5);
  doc.text('Satici / Store', 100, 80.5);
  doc.text('Tutar / Amount (USD)', 160, 80.5);

  // Table Body (Items)
  doc.setTextColor(darkColor[0], darkColor[1], darkColor[2]);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.text(data.productName, 18, 92);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.text(data.storeName, 100, 92);
  doc.setFont('helvetica', 'bold');
  doc.text(`$${data.basePrice.toLocaleString()}`, 160, 92);

  // Specifications block
  let currentY = 105;
  if (data.specs && data.specs.length > 0) {
    doc.setFillColor(lightColor[0], lightColor[1], lightColor[2]);
    doc.rect(15, currentY, pageWidth - 30, 6, 'F');
    doc.setTextColor(75, 85, 99);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8.5);
    doc.text('Teknik Ozellikler / Specifications', 18, currentY + 4);
    
    currentY += 10;
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(107, 114, 128);

    // Render top 4 specs
    data.specs.slice(0, 4).forEach((spec) => {
      doc.text(`${spec.label}:`, 18, currentY);
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(darkColor[0], darkColor[1], darkColor[2]);
      doc.text(spec.value, 65, currentY);
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(107, 114, 128);
      currentY += 5;
    });
  }

  currentY = Math.max(currentY + 5, 140);

  // Price calculation block
  doc.setDrawColor(229, 231, 235);
  doc.setLineWidth(0.5);
  doc.line(15, currentY, pageWidth - 15, currentY);
  currentY += 8;

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(107, 114, 128);

  doc.text('Cihaz Bedeli / Subtotal:', 110, currentY);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(darkColor[0], darkColor[1], darkColor[2]);
  doc.text(`$${data.basePrice.toLocaleString()} USD`, 165, currentY);
  currentY += 6;

  if (data.shippingCost > 0) {
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(107, 114, 128);
    doc.text('Hizli Kargo / Express Shipping:', 110, currentY);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(darkColor[0], darkColor[1], darkColor[2]);
    doc.text(`$${data.shippingCost.toLocaleString()} USD`, 165, currentY);
    currentY += 6;
  }

  if (data.warrantyCost > 0) {
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(107, 114, 128);
    doc.text('+3 Yil Ekstra Guvence / Warranty:', 110, currentY);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(darkColor[0], darkColor[1], darkColor[2]);
    doc.text(`$${data.warrantyCost.toLocaleString()} USD`, 165, currentY);
    currentY += 6;
  }

  doc.setFont('helvetica', 'normal');
  doc.setTextColor(107, 114, 128);
  doc.text('Vergi / Taxes (18% KDV):', 110, currentY);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(darkColor[0], darkColor[1], darkColor[2]);
  doc.text(`$${data.tax.toLocaleString()} USD`, 165, currentY);
  currentY += 8;

  // Total Payment
  doc.setFillColor(243, 255, 246);
  doc.rect(105, currentY - 5, pageWidth - 120, 10, 'F');
  doc.setDrawColor(accentColor[0], accentColor[1], accentColor[2]);
  doc.setLineWidth(0.4);
  doc.rect(105, currentY - 5, pageWidth - 120, 10, 'S');

  doc.setTextColor(accentColor[0], accentColor[1], accentColor[2]);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.text('TOPLAM / TOTAL:', 110, currentY + 1.5);
  doc.text(`$${data.totalPrice.toLocaleString()} USD`, 165, currentY + 1.5);

  currentY += 15;

  // Footer / Certificate of Simulation
  doc.setDrawColor(229, 231, 235);
  doc.setLineWidth(0.5);
  doc.line(15, currentY, pageWidth - 15, currentY);
  currentY += 8;

  doc.setTextColor(156, 163, 175);
  doc.setFont('helvetica', 'italic');
  doc.setFontSize(8);
  const footerText = 'Bu belge bir sandbox pazar yeri simülasyonu faturasıdır. Hiçbir gerçek ücret tahsil edilmemiştir ve resmi mali değeri bulunmamaktadır.';
  const splitFooter = doc.splitTextToSize(footerText, pageWidth - 30);
  doc.text(splitFooter, 15, currentY);

  // Download PDF file
  doc.save(`Fatura-${data.orderId}.pdf`);
}
