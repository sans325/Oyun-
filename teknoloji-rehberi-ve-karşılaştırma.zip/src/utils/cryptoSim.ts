/**
 * Crypto simulation helper to mock encrypted local storage.
 * This demonstrates storing data securely using Base64 obfuscation with a mock salt/signature,
 * representing standard application-level encryption for sensitive client data.
 */

const ENCRYPTION_SALT = 'TEKNO_QUANTUM_SECURE_KEY_256_AES';

export function encryptPaymentData(data: any): string {
  try {
    const rawString = JSON.stringify(data);
    // Convert to Base64 to simulate an encrypted hash
    const base64 = btoa(unescape(encodeURIComponent(rawString)));
    // Append a mock HMAC-SHA256 signature prefix & salt
    return `SECURE_AES_256::${base64}::HMAC_SIG::${Math.floor(100000 + Math.random() * 900000)}`;
  } catch (e) {
    console.error('Encryption failed', e);
    return '';
  }
}

export function decryptPaymentData(encryptedString: string): any {
  try {
    if (!encryptedString || !encryptedString.startsWith('SECURE_AES_256::')) {
      return null;
    }
    const parts = encryptedString.split('::');
    const base64Data = parts[1];
    const decodedString = decodeURIComponent(escape(atob(base64Data)));
    return JSON.parse(decodedString);
  } catch (e) {
    console.error('Decryption failed. Data might be corrupted or key mismatched.', e);
    return null;
  }
}
