import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import ProductCard from './components/ProductCard';
import ProductDetailsModal from './components/ProductDetailsModal';
import ComparisonArena from './components/ComparisonArena';
import AiRecommendationEngine from './components/AiRecommendationEngine';
import MarketplaceSimulation from './components/MarketplaceSimulation';
import OrderTrackingModal, { getOrderLiveStatus } from './components/OrderTrackingModal';
import { Product, MarketplaceStore, PRODUCTS } from './data/products';
import { Search, Sparkles, Scale, Info, Terminal, RefreshCw, Layers, Mic, MicOff, History, Trash2, Heart, Keyboard, X, Bookmark } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  const [activeTab, setActiveTab] = useState<'catalog' | 'compare' | 'ai-advisor'>('catalog');
  const [products, setProducts] = useState<Product[]>(PRODUCTS);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('Hepsi');

  // Global Theme Setup
  const [theme, setTheme] = useState<'dark' | 'light'>(() => {
    return (localStorage.getItem('tekno_theme') as 'dark' | 'light') || 'dark';
  });

  useEffect(() => {
    localStorage.setItem('tekno_theme', theme);
    if (theme === 'light') {
      document.documentElement.classList.add('light');
    } else {
      document.documentElement.classList.remove('light');
    }
  }, [theme]);

  const toggleTheme = () => {
    setTheme(prev => prev === 'dark' ? 'light' : 'dark');
  };

  // Voice Search Setup
  const [isListening, setIsListening] = useState<boolean>(false);
  const [voiceSupport, setVoiceSupport] = useState<boolean>(true);

  const handleVoiceSearch = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setVoiceSupport(false);
      alert('Tarayıcınız sesle aramayı desteklemiyor. Lütfen Chrome, Edge veya Safari kullanın.');
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = 'tr-TR';
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;

    recognition.onstart = () => {
      setIsListening(true);
    };

    recognition.onerror = (event: any) => {
      console.error('Speech recognition error', event);
      setIsListening(false);
    };

    recognition.onend = () => {
      setIsListening(false);
    };

    recognition.onresult = (event: any) => {
      const speechToText = event.results[0][0].transcript;
      if (speechToText) {
        setSearchQuery(speechToText);
      }
      setIsListening(false);
    };

    if (isListening) {
      recognition.stop();
    } else {
      recognition.start();
    }
  };

  // Recent Comparisons Persistence Setup
  const [recentSets, setRecentSets] = useState<Product[][]>(() => {
    const stored = localStorage.getItem('tekno_recent_sets');
    return stored ? JSON.parse(stored) : [];
  });

  const handleSaveComparisonSet = (set: Product[]) => {
    if (set.length < 2) return;
    
    // Check if set already exists in history to avoid duplicates
    const isDuplicate = recentSets.some(existingSet => {
      if (existingSet.length !== set.length) return false;
      const existingIds = existingSet.map(p => p.id).sort();
      const currentIds = set.map(p => p.id).sort();
      return existingIds.every((id, idx) => id === currentIds[idx]);
    });

    if (isDuplicate) return;

    // Keep up to 3 sets
    const updated = [set, ...recentSets].slice(0, 3);
    setRecentSets(updated);
    localStorage.setItem('tekno_recent_sets', JSON.stringify(updated));
  };

  const handleDeleteComparisonSet = (index: number) => {
    const updated = recentSets.filter((_, idx) => idx !== index);
    setRecentSets(updated);
    localStorage.setItem('tekno_recent_sets', JSON.stringify(updated));
  };

  const handleRestoreComparisonSet = (set: Product[]) => {
    setCompareList(set);
    setActiveTab('compare');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Advanced Catalog Filters
  const [maxPriceFilter, setMaxPriceFilter] = useState<number>(25000);
  const [onlyInStock, setOnlyInStock] = useState<boolean>(false);

  // Dynamic Google Search Discovery States
  const [discovering, setDiscovering] = useState<boolean>(false);
  const [discoverProgress, setDiscoverProgress] = useState<string>('');
  const [discoverSuccessMsg, setDiscoverSuccessMsg] = useState<string | null>(null);

  // State managers
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [compareList, setCompareList] = useState<Product[]>([]);
  const [checkoutProduct, setCheckoutProduct] = useState<Product | null>(null);
  const [checkoutStore, setCheckoutStore] = useState<MarketplaceStore | null>(null);

  // Favorites state and persistence
  const [favorites, setFavorites] = useState<string[]>(() => {
    const stored = localStorage.getItem('tekno_favorites');
    return stored ? JSON.parse(stored) : [];
  });
  const [isFavoritesOpen, setIsFavoritesOpen] = useState<boolean>(false);
  const [isShortcutsOpen, setIsShortcutsOpen] = useState<boolean>(false);

  // Dynamic simulated orders list with localStorage persistence
  const [orders, setOrders] = useState<any[]>(() => {
    const stored = localStorage.getItem('tekno_orders');
    return stored ? JSON.parse(stored) : [];
  });
  const [isOrdersOpen, setIsOrdersOpen] = useState<boolean>(false);

  // Dynamic system/order and price drop notifications
  const [notifications, setNotifications] = useState<any[]>(() => {
    const stored = localStorage.getItem('tekno_notifications');
    return stored ? JSON.parse(stored) : [
      {
        id: 'welcome',
        title: 'Kuantum Takip Aktif 🚀',
        message: 'TeknoAnaliz Pazar Yeri ve Kuantum Siparis Takip Sistemine hos geldiniz.',
        date: new Date().toLocaleTimeString('tr-TR'),
        read: false,
        type: 'system'
      }
    ];
  });

  const [refreshTrigger, setRefreshTrigger] = useState(0);

  // Poll order status transitions & push notifications
  useEffect(() => {
    // Increment a ticker every 4 seconds to force recalculation of statuses
    const interval = setInterval(() => {
      setRefreshTrigger(prev => prev + 1);
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (orders.length === 0) return;

    let hasChanges = false;
    const updatedOrders = orders.map(order => {
      // getOrderLiveStatus calculates the current simulated status based on purchase timestamp
      const live = getOrderLiveStatus(order.orderDate, order.shippingMethod);

      // If status has transitioned, trigger a gorgeous notification
      if (order.status !== live.status) {
        let statusTitle = 'Siparis Durumu Guncellendi 📦';
        let statusMessage = `"${order.productName}" siparisinizin yeni durumu: ${live.label}`;

        if (live.status === 'preparing') {
          statusTitle = 'Siparisiniz Hazirlaniyor 🛠️';
          statusMessage = `"${order.productName}" siparisiniz paketleniyor ve kalite kontrolunden geciriliyor.`;
        } else if (live.status === 'shipped') {
          statusTitle = 'Siparisiniz Kargoya Verildi! 🚚';
          statusMessage = `"${order.productName}" siparisiniz yola cikti. Tahmini teslimat: ${order.shippingMethod === 'express' ? '12 saniye' : '20 saniye'}.`;
        } else if (live.status === 'delivered') {
          statusTitle = 'Siparisiniz Teslim Edildi! 🎉';
          statusMessage = `"${order.productName}" siparisiniz basariyla adrese teslim edilmistir. Bizi tercih ettiginiz icin tesekkur ederiz!`;
        }

        const newNotif = {
          id: `order-status-${order.id}-${live.status}`,
          title: statusTitle,
          message: statusMessage,
          date: new Date().toLocaleTimeString('tr-TR'),
          read: false,
          type: 'order'
        };

        // Prepend new notification only if not already present
        setNotifications(prev => {
          if (prev.some(n => n.id === newNotif.id)) return prev;
          const next = [newNotif, ...prev];
          localStorage.setItem('tekno_notifications', JSON.stringify(next));
          return next;
        });

        order.status = live.status;
        hasChanges = true;
      }
      return order;
    });

    if (hasChanges) {
      setOrders(updatedOrders);
      localStorage.setItem('tekno_orders', JSON.stringify(updatedOrders));
    }
  }, [orders, refreshTrigger]);

  // Simulate periodic price drops for favorited items to alert the user
  useEffect(() => {
    if (favorites.length === 0) return;

    const interval = setInterval(() => {
      // 35% chance to trigger price drop notification on a favorited item
      if (Math.random() > 0.35) return;

      const randomFavId = favorites[Math.floor(Math.random() * favorites.length)];
      const product = products.find(p => p.id === randomFavId);
      if (!product) return;

      const storeIdx = Math.floor(Math.random() * product.stores.length);
      const store = product.stores[storeIdx];

      const originalPrice = store.price;
      const dropAmount = Math.round(originalPrice * (0.05 + Math.random() * 0.1));
      const droppedPrice = originalPrice - dropAmount;

      const newNotif = {
        id: `price-drop-${product.id}-${Date.now()}`,
        title: '🔥 Fiyat Dususu Alarmi!',
        message: `Favorilediginiz "${product.name}" urunu ${store.storeName} magazasinda $${originalPrice.toLocaleString()} yerine kisa sureligine $${droppedPrice.toLocaleString()} seviyesine geriledi!`,
        date: new Date().toLocaleTimeString('tr-TR'),
        read: false,
        type: 'price-drop'
      };

      setNotifications(prev => {
        const next = [newNotif, ...prev];
        localStorage.setItem('tekno_notifications', JSON.stringify(next));
        return next;
      });
    }, 20000); // Check every 20 seconds

    return () => clearInterval(interval);
  }, [favorites, products]);

  // Callbacks for OrderTrackingModal
  const handleRepeatPurchase = (productId: string, storeName: string) => {
    const prod = products.find(p => p.id === productId);
    if (!prod) return;
    const storeObj = prod.stores.find(s => s.storeName === storeName) || prod.stores[0];
    setCheckoutProduct(prod);
    setCheckoutStore(storeObj);
    setIsOrdersOpen(false); // Close tracking drawer to let checkout form shine
  };

  const handleViewProduct = (productId: string) => {
    const prod = products.find(p => p.id === productId);
    if (!prod) return;
    setSelectedProduct(prod);
    setIsOrdersOpen(false); // Close tracking drawer
  };

  const handleOrderPlaced = (newOrder: any) => {
    const updated = [newOrder, ...orders];
    setOrders(updated);
    localStorage.setItem('tekno_orders', JSON.stringify(updated));
    // Automatically open order tracking so they can watch the live progress!
    setTimeout(() => {
      setIsOrdersOpen(true);
    }, 800);
  };

  const handleCancelOrder = (id: string) => {
    const updated = orders.filter(o => o.id !== id);
    setOrders(updated);
    localStorage.setItem('tekno_orders', JSON.stringify(updated));
  };

  const handleClearOrders = () => {
    setOrders([]);
    localStorage.removeItem('tekno_orders');
  };

  const handleToggleFavorite = (product: Product) => {
    const isFav = favorites.includes(product.id);
    let updated: string[];
    if (isFav) {
      updated = favorites.filter(id => id !== product.id);
    } else {
      updated = [...favorites, product.id];
    }
    setFavorites(updated);
    localStorage.setItem('tekno_favorites', JSON.stringify(updated));
  };

  // View Presets Setup
  interface ViewPreset {
    id: string;
    name: string;
    searchQuery: string;
    selectedCategory: string;
    maxPriceFilter: number;
    onlyInStock: boolean;
    isDefault?: boolean;
  }

  const [presets, setPresets] = useState<ViewPreset[]>(() => {
    const defaultPresets: ViewPreset[] = [
      { id: 'all', name: 'Tüm Donanımlar', searchQuery: '', selectedCategory: 'Hepsi', maxPriceFilter: 25000, onlyInStock: false, isDefault: true },
      { id: 'wearables', name: 'Giyilebilir ve Şık', searchQuery: '', selectedCategory: 'Giyilebilir Teknoloji', maxPriceFilter: 1000, onlyInStock: true, isDefault: true },
      { id: 'ai-robotics', name: 'Yapay Zeka ve Robotik', searchQuery: '', selectedCategory: 'Yapay Zeka & Robotik', maxPriceFilter: 25000, onlyInStock: false, isDefault: true },
      { id: 'budget', name: 'Ekonomik Seçenekler', searchQuery: '', selectedCategory: 'Hepsi', maxPriceFilter: 1500, onlyInStock: true, isDefault: true }
    ];
    const stored = localStorage.getItem('tekno_presets');
    if (stored) {
      try {
        const custom = JSON.parse(stored);
        return [...defaultPresets, ...custom];
      } catch (e) {
        return defaultPresets;
      }
    }
    return defaultPresets;
  });

  const handleSavePreset = (name: string) => {
    if (!name.trim()) return;
    const newPreset: ViewPreset = {
      id: 'preset_' + Date.now(),
      name: name.trim(),
      searchQuery,
      selectedCategory,
      maxPriceFilter,
      onlyInStock
    };
    const customOnly = presets.filter(p => !p.isDefault);
    const updatedCustom = [...customOnly, newPreset];
    localStorage.setItem('tekno_presets', JSON.stringify(updatedCustom));
    setPresets([...presets.filter(p => p.isDefault), ...updatedCustom]);
  };

  const handleDeletePreset = (id: string) => {
    const customOnly = presets.filter(p => !p.isDefault && p.id !== id);
    localStorage.setItem('tekno_presets', JSON.stringify(customOnly));
    setPresets([...presets.filter(p => p.isDefault), ...customOnly]);
  };

  const handleApplyPreset = (preset: ViewPreset) => {
    setSearchQuery(preset.searchQuery);
    setSelectedCategory(preset.selectedCategory);
    setMaxPriceFilter(preset.maxPriceFilter);
    setOnlyInStock(preset.onlyInStock);
  };

  // Keyboard Shortcuts Listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      if (target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable)) {
        if (e.key === 'Escape') {
          target.blur();
          setSelectedProduct(null);
          setIsFavoritesOpen(false);
          setIsShortcutsOpen(false);
        }
        return;
      }

      if (e.key === '/') {
        e.preventDefault();
        const searchInput = document.getElementById('search-input');
        if (searchInput) {
          searchInput.focus();
        }
      }

      if (e.key === 'Escape') {
        setSelectedProduct(null);
        setIsFavoritesOpen(false);
        setIsShortcutsOpen(false);
      }

      if (e.key === '1') {
        setActiveTab('catalog');
      }
      if (e.key === '2') {
        setActiveTab('compare');
      }
      if (e.key === '3') {
        setActiveTab('ai-advisor');
      }

      if (e.key.toLowerCase() === 'f') {
        setIsFavoritesOpen(prev => !prev);
      }

      if (e.key.toLowerCase() === 'k' || e.key === '?') {
        setIsShortcutsOpen(prev => !prev);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [searchQuery, selectedCategory, maxPriceFilter, onlyInStock, presets]);

  const [loading, setLoading] = useState<boolean>(true);
  const [apiError, setApiError] = useState<string | null>(null);

  // Discovery Action Handler using Google Search Grounding on backend
  const handleDiscoverNewTech = async () => {
    setDiscovering(true);
    setDiscoverProgress('Tarama Başlatılıyor...');
    setDiscoverSuccessMsg(null);

    const steps = [
      'Google Arama indeksi taranıyor...',
      'Yeni donanım ve lansmanlar inceleniyor...',
      'Özellik matrisi şemalaştırılıyor...',
      'Tedarikçi pazar yeri entegre ediliyor...',
      'Kataloğunuz güncelleniyor...'
    ];

    let currentStep = 0;
    const interval = setInterval(() => {
      if (currentStep < steps.length) {
        setDiscoverProgress(steps[currentStep]);
        currentStep++;
      }
    }, 1500);

    try {
      const response = await fetch('/api/discover-new', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });
      clearInterval(interval);

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Arama yapılamadı.');
      }

      const data = await response.json();
      if (data.success && Array.isArray(data.addedProducts)) {
        const prodRes = await fetch('/api/products');
        if (prodRes.ok) {
          const prodData = await prodRes.json();
          if (prodData.products) {
            setProducts(prodData.products);
          }
        }
        
        if (data.addedCount > 0) {
          setDiscoverSuccessMsg(`Google Live araması başarıyla tamamlandı! ${data.addedCount} adet yeni modern cihaz kataloğa eklendi: ${data.addedProducts.map((p: any) => p.name).join(', ')}.`);
        } else {
          setDiscoverSuccessMsg("Google Live araması tamamlandı! Katalog zaten en güncel ürünlerle senkronize durumda.");
        }
      }
    } catch (err: any) {
      clearInterval(interval);
      console.error(err);
      setDiscoverSuccessMsg(`Keşif Başarısız: ${err.message || 'Lütfen Secrets panelinden GEMINI_API_KEY anahtarınızı girin.'}`);
    } finally {
      setDiscovering(false);
      setTimeout(() => {
        setDiscoverSuccessMsg(null);
      }, 10000);
    }
  };

  // Fetch real product array from API, fallback to imported PRODUCTS on fail
  useEffect(() => {
    async function loadProducts() {
      try {
        const response = await fetch('/api/products');
        if (!response.ok) {
          throw new Error('Veri tabanına erişilemedi.');
        }
        const data = await response.json();
        if (data.products && Array.isArray(data.products)) {
          setProducts(data.products);
        }
      } catch (err: any) {
        console.warn('API connection failed, falling back to local dataset.', err);
        setProducts(PRODUCTS);
      } finally {
        setLoading(false);
      }
    }
    loadProducts();
  }, []);

  const handleToggleCompare = (product: Product) => {
    setCompareList(prev => {
      const exists = prev.some(item => item.id === product.id);
      if (exists) {
        return prev.filter(item => item.id !== product.id);
      } else {
        if (prev.length >= 3) {
          return prev; // Max 3 items
        }
        return [...prev, product];
      }
    });
  };

  const handleRemoveCompare = (product: Product) => {
    setCompareList(prev => prev.filter(item => item.id !== product.id));
  };

  const handleClearCompare = () => {
    setCompareList([]);
  };

  const handlePurchaseSimulate = (product: Product, store: MarketplaceStore) => {
    setCheckoutProduct(product);
    setCheckoutStore(store);
  };

  // Filters calculation
  const filteredProducts = products.filter(product => {
    // Find lowest price
    const lowest = product.marketplace.length > 0 
      ? product.marketplace.reduce((min, item) => (item.price < min.price ? item : min), product.marketplace[0]).price
      : 0;

    const matchesPrice = lowest <= maxPriceFilter;

    const matchesStock = !onlyInStock || product.marketplace.some(m => m.stockStatus === 'InStock' || m.stockStatus === 'LowStock');

    const matchesSearch = 
      product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.tagline.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.specs.some(spec => spec.value.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesCategory = 
      selectedCategory === 'Hepsi' || product.category === selectedCategory;

    return matchesSearch && matchesCategory && matchesPrice && matchesStock;
  });

  const categories = ['Hepsi', 'Donanım & Bilgisayar', 'Giyilebilir Teknoloji', 'Sanal & Artırılmış Gerçeklik', 'Yapay Zeka & Robotik', 'Akıllı Çevre & İletişim'];

  return (
    <div className="min-h-screen flex flex-col bg-dark-bg text-white font-sans selection:bg-teal-500/30 selection:text-teal-200">
      
      {/* GLOW DECORATIVE BACKDROPS */}
      <div className="absolute top-0 left-1/4 w-[45rem] h-[45rem] bg-teal-500/5 rounded-full blur-[120px] -z-10 pulse-bg" />
      <div className="absolute top-1/3 right-1/4 w-[35rem] h-[35rem] bg-indigo-500/5 rounded-full blur-[100px] -z-10 pulse-bg" style={{ animationDelay: '2s' }} />

      {/* HEADER SECTION */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        compareCount={compareList.length}
        favoritesCount={favorites.length}
        ordersCount={orders.length}
        theme={theme}
        toggleTheme={toggleTheme}
        onOpenFavorites={() => setIsFavoritesOpen(true)}
        onOpenShortcuts={() => setIsShortcutsOpen(true)}
        onOpenOrders={() => setIsOrdersOpen(true)}
        notifications={notifications}
        setNotifications={setNotifications}
      />

      {/* MAIN CONTENT WORKSPACE */}
      <main className="flex-grow">
        <AnimatePresence mode="wait">
          
          {/* TAB 1: CATALOGUE VIEW */}
          {activeTab === 'catalog' && (
            <motion.div
              key="catalog-tab"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.3 }}
              className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 space-y-8"
            >
              
              {/* Promotional Hero Banner */}
              <div className="rounded-2xl border border-gray-800 bg-gradient-to-tr from-gray-950 via-dark-card/85 to-teal-950/20 p-6 sm:p-8 relative overflow-hidden flex flex-col md:flex-row md:items-center justify-between gap-6">
                <div className="space-y-3 max-w-2xl">
                  <div className="inline-flex items-center gap-1.5 text-xs text-teal-400 font-mono bg-teal-950/50 border border-teal-800/60 rounded-full px-3 py-1">
                    <Sparkles className="h-3 w-3 text-teal-400 animate-pulse" />
                    <span>Yapay Zeka Destekli Karşılaştırma & Pazar Yeri Entegrasyonu</span>
                  </div>
                  <h1 className="font-display text-3xl sm:text-4xl font-extrabold text-white tracking-tight leading-tight">
                    Yeni Nesil Teknolojileri <span className="text-teal-400">Karşılaştırın</span>, Doğru Kararı Alın.
                  </h1>
                  <p className="text-sm text-gray-400 leading-relaxed">
                    Yarım kalan kıyaslamalara son! Dünyanın en gelişmiş çiplerini, VR başlıklarını, giyilebilir teknolojilerini ve akıllı altyapılarını teknik özellikleriyle inceleyin. Tedarikçiler arası fiyat karşılaştırması yaparak en uygun pazar yerine tek tıkla ulaşın.
                  </p>
                </div>

                {/* Compare Status Float */}
                {compareList.length > 0 && (
                  <div className="shrink-0 bg-teal-950/30 border border-teal-500/20 rounded-xl p-4 flex flex-col items-center text-center space-y-2.5 backdrop-blur-sm">
                    <div className="flex h-10 w-10 items-center justify-center rounded-full bg-teal-500/10 border border-teal-500/20 text-teal-400 font-mono font-bold text-sm">
                      {compareList.length}
                    </div>
                    <div className="text-xs text-gray-300 font-medium">Cihaz Karşılaştırılmaya Hazır</div>
                    <button
                      id="hero-go-compare"
                      onClick={() => setActiveTab('compare')}
                      className="rounded-lg bg-teal-500 hover:bg-teal-600 px-3.5 py-1.5 text-xs font-bold text-dark-bg transition-all flex items-center gap-1"
                    >
                      Kıyaslama Alanına Git
                    </button>
                  </div>
                )}
              </div>

              {/* Advanced Filtering Controls Panel */}
              <div className="space-y-4">
                {/* Search Bar & Category Filter Row */}
                <div className="flex flex-col lg:flex-row gap-4 items-stretch lg:items-center justify-between bg-dark-card/30 border border-gray-800/80 rounded-2xl p-4 backdrop-blur-sm">
                  {/* Search Bar with Voice-to-Text integration */}
                  <div className="relative flex-1">
                    <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-500" />
                    <input
                      id="search-input"
                      type="text"
                      placeholder={isListening ? "Dinleniyor... Lütfen Türkçe konuşun." : "Ürün adı, işlemci gücü, çözünürlük veya donanım detayı arayın..."}
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className={`w-full rounded-xl border py-2.5 pl-10 pr-20 text-xs text-white placeholder-gray-500 focus:outline-none focus:ring-1 focus:ring-teal-500/30 transition-all font-medium ${
                        isListening 
                          ? 'border-red-500 bg-red-950/10 text-red-300 animate-pulse' 
                          : 'border-gray-800 bg-gray-900/60 focus:border-teal-500'
                      }`}
                    />
                    
                    <div className="absolute right-2.5 top-1/2 -translate-y-1/2 flex items-center gap-1">
                      {searchQuery && (
                        <button
                          id="clear-search"
                          onClick={() => setSearchQuery('')}
                          className="text-[10px] text-gray-500 hover:text-white px-1 py-0.5 rounded"
                        >
                          Temizle
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={handleVoiceSearch}
                        id="voice-search-btn"
                        className={`p-1.5 rounded-lg transition-all focus:outline-none ${
                          isListening 
                            ? 'bg-red-500 text-white animate-pulse shadow-md shadow-red-500/20' 
                            : 'text-gray-400 hover:text-teal-400 hover:bg-gray-800/40'
                        }`}
                        title={isListening ? 'Dinlemeyi Durdur' : 'Sesle Ara (Mikrofon)'}
                      >
                        <Mic className="h-4 w-4" />
                      </button>
                    </div>
                  </div>

                  {/* Categories Scroll Pills */}
                  <div className="flex items-center gap-1.5 overflow-x-auto pb-1 lg:pb-0 scrollbar-none">
                    {categories.map((category) => (
                      <button
                        key={category}
                        id={`cat-filter-${category}`}
                        onClick={() => setSelectedCategory(category)}
                        className={`rounded-lg px-3.5 py-2 text-xs font-semibold whitespace-nowrap transition-all ${
                          selectedCategory === category
                            ? 'bg-teal-500 text-dark-bg border border-teal-500'
                            : 'bg-gray-900/40 border border-gray-800 text-gray-400 hover:border-gray-700 hover:text-white'
                        }`}
                      >
                        {category}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Slider, Availability Toggle, and Google Search Discover row */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-dark-card/20 border border-gray-800/50 rounded-2xl p-4 items-center">
                  {/* Price Slider */}
                  <div className="space-y-1.5">
                    <div className="flex justify-between text-xs font-mono">
                      <span className="text-gray-400">Maksimum Fiyat Limiti:</span>
                      <span className="text-teal-400 font-bold">${maxPriceFilter.toLocaleString()} USD</span>
                    </div>
                    <input
                      type="range"
                      min={100}
                      max={25000}
                      step={100}
                      value={maxPriceFilter}
                      onChange={(e) => setMaxPriceFilter(parseInt(e.target.value))}
                      className="w-full accent-teal-500 h-1.5 bg-gray-800 rounded-lg cursor-pointer"
                    />
                  </div>

                  {/* Availability Toggle */}
                  <div className="flex items-center gap-3 justify-start md:justify-center">
                    <button
                      type="button"
                      onClick={() => setOnlyInStock(!onlyInStock)}
                      className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                        onlyInStock ? 'bg-teal-500' : 'bg-gray-800'
                      }`}
                    >
                      <span
                        className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                          onlyInStock ? 'translate-x-5' : 'translate-x-0'
                        }`}
                      />
                    </button>
                    <div className="space-y-0.5">
                      <span className="block text-xs font-semibold text-white">Sadece Stoktakiler</span>
                      <span className="block text-[10px] text-gray-400 font-mono">Tükenen ürünleri gizle</span>
                    </div>
                  </div>

                  {/* AI Google Discovery Button */}
                  <div className="flex justify-start md:justify-end">
                    <button
                      onClick={handleDiscoverNewTech}
                      disabled={discovering}
                      className="w-full md:w-auto rounded-xl bg-gradient-to-r from-teal-500 to-emerald-400 hover:from-teal-600 hover:to-emerald-500 text-dark-bg font-bold text-xs px-4 py-2.5 transition-all flex items-center justify-center gap-2 shadow-lg shadow-teal-500/10 disabled:opacity-50 disabled:cursor-not-allowed shrink-0"
                    >
                      {discovering ? (
                        <>
                          <RefreshCw className="h-4 w-4 animate-spin" />
                          <span className="font-mono text-[11px]">{discoverProgress}</span>
                        </>
                      ) : (
                        <>
                          <Sparkles className="h-4 w-4" />
                          <span>Google'da Yeni Teknolojiler Keşfet</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>

                {/* AI Google Search Discovery Feedback Message */}
                <AnimatePresence>
                  {discoverSuccessMsg && (
                    <motion.div
                      initial={{ opacity: 0, y: -8 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -8 }}
                      className={`p-3.5 rounded-xl border text-xs leading-relaxed font-mono ${
                        discoverSuccessMsg.includes('Başarısız') || discoverSuccessMsg.includes('Keşif')
                          ? 'bg-red-950/20 border-red-900/40 text-red-400'
                          : 'bg-teal-950/20 border-teal-800/40 text-teal-400'
                      }`}
                    >
                      {discoverSuccessMsg}
                    </motion.div>
                  )}
                </AnimatePresence>

                {/* View Presets Bar */}
                <div className="flex flex-col xl:flex-row gap-4 items-start xl:items-center justify-between bg-dark-card/20 border border-gray-800/50 rounded-2xl p-4 backdrop-blur-sm">
                  <div className="flex flex-col gap-0.5">
                    <span className="text-xs font-semibold text-white flex items-center gap-1.5">
                      <Bookmark className="h-4 w-4 text-teal-400" />
                      Görünüm Presetleri (Hızlı Filtre)
                    </span>
                    <span className="text-[10px] text-gray-400 font-mono leading-normal">
                      Sık keşfedilen senaryoları uygulayın veya mevcut filtrenizi yeni bir adla kaydedin.
                    </span>
                  </div>
                  
                  {/* Preset Pills */}
                  <div className="flex flex-wrap items-center gap-2 max-w-full">
                    {presets.map((preset) => (
                      <div key={preset.id} className="inline-flex items-center gap-1 bg-gray-900/60 border border-gray-800/80 rounded-lg px-2.5 py-1 text-xs transition-all hover:border-gray-700">
                        <button
                          onClick={() => handleApplyPreset(preset)}
                          className="font-medium text-gray-300 hover:text-teal-400 font-sans cursor-pointer text-left"
                        >
                          {preset.name}
                        </button>
                        {!preset.isDefault && (
                          <button
                            onClick={() => handleDeletePreset(preset.id)}
                            className="text-gray-500 hover:text-red-400 ml-1 rounded p-0.5 cursor-pointer"
                            title="Preseti Sil"
                          >
                            <Trash2 className="h-3 w-3" />
                          </button>
                        )}
                      </div>
                    ))}
                    
                    {/* Inline Save Preset UI */}
                    <div className="flex items-center gap-1 border border-gray-800 rounded-lg px-2 py-0.5 bg-gray-900/40">
                      <input
                        type="text"
                        placeholder="Yeni Filtre..."
                        id="preset-name-input"
                        className="bg-transparent border-none text-[11px] text-white focus:outline-none w-24 placeholder-gray-600 font-semibold"
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            const target = e.target as HTMLInputElement;
                            if (target.value.trim()) {
                              handleSavePreset(target.value);
                              target.value = '';
                            }
                          }
                        }}
                      />
                      <button
                        onClick={() => {
                          const input = document.getElementById('preset-name-input') as HTMLInputElement;
                          if (input && input.value.trim()) {
                            handleSavePreset(input.value);
                            input.value = '';
                          }
                        }}
                        className="text-[10px] font-bold text-teal-400 hover:text-white transition-all bg-teal-950/40 border border-teal-800/40 rounded px-1.5 py-0.5 cursor-pointer"
                      >
                        Kaydet
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Catalog Grid View wrapped with Recent Comparisons Sidebar */}
              <div className="flex flex-col lg:flex-row gap-6 items-start">
                
                {/* Main Catalogue Grid Left Side */}
                <div className="flex-1 w-full space-y-6">
                  {loading ? (
                    <div className="flex flex-col items-center justify-center py-20 space-y-3">
                      <RefreshCw className="h-8 w-8 animate-spin text-teal-400" />
                      <span className="text-xs text-gray-500 font-mono">Modern teknoloji veri tabanı yükleniyor...</span>
                    </div>
                  ) : filteredProducts.length === 0 ? (
                    <div className="rounded-2xl border border-dashed border-gray-800 p-12 text-center max-w-md mx-auto bg-dark-card/10">
                      <h3 className="text-base font-semibold text-white font-display">Aramanızla Eşleşen Ürün Bulunamadı</h3>
                      <p className="text-xs text-gray-400 mt-2">
                        Lütfen farklı bir anahtar kelime girmeyi deneyin ya da kategori filtrenizi temizleyin.
                      </p>
                      <button
                        id="reset-filters"
                        onClick={() => { setSearchQuery(''); setSelectedCategory('Hepsi'); }}
                        className="mt-4 rounded-lg bg-gray-800 border border-gray-700 text-xs px-4 py-2 font-semibold hover:bg-gray-700 transition-all text-teal-400"
                      >
                        Tüm Katalog Filtrelerini Sıfırla
                      </button>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                      {filteredProducts.map((product) => (
                        <ProductCard
                          key={product.id}
                          product={product}
                          onViewDetails={(p) => setSelectedProduct(p)}
                          onToggleCompare={handleToggleCompare}
                          isComparing={compareList.some(item => item.id === product.id)}
                          isCompareDisabled={compareList.length >= 3}
                          isFavorite={favorites.includes(product.id)}
                          onToggleFavorite={handleToggleFavorite}
                        />
                      ))}
                    </div>
                  )}
                </div>

                {/* Recent Comparisons Sidebar Right Side */}
                <div className="w-full lg:w-72 shrink-0 rounded-2xl border border-gray-800 bg-dark-card/30 p-5 space-y-4 backdrop-blur-sm lg:sticky lg:top-20">
                  <div className="flex items-center gap-1.5 border-b border-gray-800 pb-3">
                    <History className="h-4.5 w-4.5 text-teal-400" />
                    <h3 className="font-display text-sm font-bold text-white">Son Kıyaslamalarım</h3>
                    <span className="text-[10px] font-mono bg-teal-950/40 border border-teal-800/40 text-teal-400 px-2 py-0.5 rounded-md ml-auto font-bold">
                      {recentSets.length}/3
                    </span>
                  </div>

                  {recentSets.length === 0 ? (
                    <div className="text-center py-6 text-gray-500 text-xs font-sans space-y-2">
                      <p className="leading-relaxed font-medium">Henüz bir kıyaslama grubu kaydetmediniz.</p>
                      <p className="text-[10px] text-gray-600 leading-normal">
                        Karşılaştırma arenasında <strong>"Kıyaslama Setini Kaydet"</strong> butonuna basarak geçmişinizi oluşturabilirsiniz.
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {recentSets.map((set, idx) => (
                        <div 
                          key={idx}
                          className="group relative rounded-xl border border-gray-800/60 bg-gray-900/20 hover:border-teal-500/35 hover:bg-gray-900/40 p-3 transition-all cursor-pointer flex flex-col gap-2"
                          onClick={() => handleRestoreComparisonSet(set)}
                        >
                          {/* Title / Info row */}
                          <div className="flex items-center justify-between">
                            <span className="text-[10px] font-mono text-teal-400/80 uppercase font-bold tracking-wider">
                              Set #{idx + 1}
                            </span>
                            
                            {/* Individual delete */}
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleDeleteComparisonSet(idx);
                              }}
                              className="lg:opacity-0 lg:group-hover:opacity-100 p-1 rounded hover:bg-red-950/30 text-gray-500 hover:text-red-400 transition-all focus:outline-none"
                              title="Kaydı Sil"
                            >
                              <Trash2 className="h-3 w-3" />
                            </button>
                          </div>

                          {/* Chips list */}
                          <div className="flex flex-col gap-1.5">
                            {set.map((p) => (
                              <div key={p.id} className="flex items-center gap-2">
                                <div className="h-3.5 w-3.5 rounded-full bg-teal-500/10 border border-teal-500/20 flex items-center justify-center text-[9px] text-teal-400 font-bold font-mono">
                                  +
                                </div>
                                <span className="text-xs text-gray-300 font-medium truncate max-w-[190px]">
                                  {p.name}
                                </span>
                              </div>
                            ))}
                          </div>

                          <div className="text-[10px] text-teal-400/80 font-bold flex items-center gap-0.5 mt-1 group-hover:text-teal-400 transition-colors">
                            Yeniden Yükle ➔
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

              </div>

            </motion.div>
          )}

          {/* TAB 2: COMPARE ARENA */}
          {activeTab === 'compare' && (
            <motion.div
              key="compare-tab"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.3 }}
            >
              <ComparisonArena
                compareList={compareList}
                onRemove={handleRemoveCompare}
                onClear={handleClearCompare}
                onViewDetails={(p) => setSelectedProduct(p)}
                onSaveSet={handleSaveComparisonSet}
              />
            </motion.div>
          )}

          {/* TAB 3: AI ADVISOR */}
          {activeTab === 'ai-advisor' && (
            <motion.div
              key="advisor-tab"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.3 }}
            >
              <AiRecommendationEngine
                products={products}
                onAddToCompare={handleToggleCompare}
                onViewDetails={(p) => setSelectedProduct(p)}
                compareList={compareList}
              />
            </motion.div>
          )}

        </AnimatePresence>
      </main>

      {/* FOOTER CO-ORDINATION */}
      <footer className="border-t border-gray-800 bg-gray-950/60 py-6 text-center text-xs text-gray-500 font-mono">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row justify-between items-center gap-4">
          <span className="text-gray-500">TeknoAnaliz © 2026 • Tüm Hakları Saklıdır.</span>
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
              Yapay Zeka Sunucusu: Çevrimiçi (Online)
            </span>
            <span>|</span>
            <span className="text-gray-500">Gemini 3.1 Pro Entegre Karar Desteği</span>
          </div>
        </div>
      </footer>

      {/* DETAILED SPECS MODAL VIEW */}
      <ProductDetailsModal
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
        onAddToCompare={handleToggleCompare}
        isComparing={selectedProduct ? compareList.some(item => item.id === selectedProduct.id) : false}
        isCompareDisabled={compareList.length >= 3}
        onPurchaseSimulate={handlePurchaseSimulate}
      />

      {/* SECURE CHECKOUT SIMULATION MODAL */}
      <MarketplaceSimulation
        product={checkoutProduct}
        store={checkoutStore}
        onClose={() => { setCheckoutProduct(null); setCheckoutStore(null); }}
        onOrderPlaced={handleOrderPlaced}
      />

      {/* KEYBOARD SHORTCUTS MODAL */}
      <AnimatePresence>
        {isShortcutsOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsShortcutsOpen(false)}
              className="absolute inset-0 bg-black/80 backdrop-blur-sm"
            />
            
            {/* Content Card */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              className="relative w-full max-w-md overflow-hidden rounded-2xl border border-gray-800 bg-dark-card p-6 shadow-2xl text-left backdrop-blur-md"
            >
              <div className="flex items-center justify-between border-b border-gray-800 pb-3 mb-4">
                <div className="flex items-center gap-2">
                  <Keyboard className="h-5 w-5 text-teal-400" />
                  <h3 className="font-display text-base font-bold text-white">Klavye Kısayolları</h3>
                </div>
                <button
                  onClick={() => setIsShortcutsOpen(false)}
                  className="rounded-lg p-1.5 text-gray-500 hover:bg-gray-800 hover:text-white transition-all focus:outline-none cursor-pointer"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>

              <div className="space-y-4">
                <p className="text-xs text-gray-400 leading-relaxed font-sans">
                  Gezinti hızınızı ve portal içi üretkenliğinizi artırmak için aşağıdaki kısayolları kullanabilirsiniz:
                </p>

                <div className="space-y-2.5">
                  <div className="flex items-center justify-between border-b border-gray-850 pb-2 text-xs font-sans">
                    <span className="text-gray-300 font-medium">Teknoloji Kataloğu Sekmesi</span>
                    <kbd className="px-2 py-1 rounded bg-gray-950 border border-gray-800 text-teal-400 font-mono font-bold text-[10px]">1</kbd>
                  </div>

                  <div className="flex items-center justify-between border-b border-gray-850 pb-2 text-xs font-sans">
                    <span className="text-gray-300 font-medium">Karşılaştırma Arenası Sekmesi</span>
                    <kbd className="px-2 py-1 rounded bg-gray-950 border border-gray-800 text-teal-400 font-mono font-bold text-[10px]">2</kbd>
                  </div>

                  <div className="flex items-center justify-between border-b border-gray-850 pb-2 text-xs font-sans">
                    <span className="text-gray-300 font-medium">TeknoAsistan AI Sekmesi</span>
                    <kbd className="px-2 py-1 rounded bg-gray-950 border border-gray-800 text-teal-400 font-mono font-bold text-[10px]">3</kbd>
                  </div>

                  <div className="flex items-center justify-between border-b border-gray-850 pb-2 text-xs font-sans">
                    <span className="text-gray-300 font-medium">Arama Çubuğuna Odaklan</span>
                    <kbd className="px-2 py-1 rounded bg-gray-950 border border-gray-800 text-teal-400 font-mono font-bold text-[10px]">/</kbd>
                  </div>

                  <div className="flex items-center justify-between border-b border-gray-850 pb-2 text-xs font-sans">
                    <span className="text-gray-300 font-medium">Favorilerim Panelini Aç/Kapat</span>
                    <kbd className="px-2 py-1 rounded bg-gray-950 border border-gray-800 text-teal-400 font-mono font-bold text-[10px]">f</kbd>
                  </div>

                  <div className="flex items-center justify-between border-b border-gray-850 pb-2 text-xs font-sans">
                    <span className="text-gray-300 font-medium">Kısayolları Aç/Kapat</span>
                    <kbd className="px-2 py-1 rounded bg-gray-950 border border-gray-800 text-teal-400 font-mono font-bold text-[10px]">k</kbd>
                  </div>

                  <div className="flex items-center justify-between pb-1 text-xs font-sans">
                    <span className="text-gray-300 font-medium">Modalları Kapat</span>
                    <kbd className="px-2 py-1 rounded bg-gray-950 border border-gray-800 text-teal-400 font-mono font-bold text-[10px]">Esc</kbd>
                  </div>
                </div>

                <div className="rounded-xl bg-gray-950/60 border border-gray-800/60 p-3 text-[10px] text-gray-500 font-mono text-center leading-relaxed">
                  Arama çubuğu veya metin alanlarına yazı yazarken kısayollar geçici olarak devre dışı bırakılır.
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* MY FAVORITES MODAL */}
      <AnimatePresence>
        {isFavoritesOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsFavoritesOpen(false)}
              className="absolute inset-0 bg-black/80 backdrop-blur-sm"
            />
            
            {/* Content Card */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              className="relative w-full max-w-lg overflow-hidden rounded-2xl border border-gray-800 bg-dark-card p-6 shadow-2xl text-left backdrop-blur-md"
            >
              <div className="flex items-center justify-between border-b border-gray-800 pb-3 mb-4">
                <div className="flex items-center gap-2">
                  <Heart className="h-5 w-5 text-red-500 fill-red-500" />
                  <h3 className="font-display text-base font-bold text-white">Favori Teknolojilerim</h3>
                  <span className="text-xs font-mono font-bold bg-red-950/40 border border-red-900/40 text-red-400 px-2 py-0.5 rounded-full">
                    {favorites.length} Cihaz
                  </span>
                </div>
                <button
                  onClick={() => setIsFavoritesOpen(false)}
                  className="rounded-lg p-1.5 text-gray-500 hover:bg-gray-800 hover:text-white transition-all focus:outline-none cursor-pointer"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>

              {favorites.length === 0 ? (
                <div className="text-center py-12 text-gray-500 space-y-3 font-sans">
                  <div className="mx-auto flex h-10 w-10 items-center justify-center rounded-full bg-gray-900 border border-gray-800 text-gray-600">
                    <Heart className="h-5 w-5" />
                  </div>
                  <h4 className="font-semibold text-white">Favori Listeniz Boş</h4>
                  <p className="text-xs text-gray-400 max-w-xs mx-auto leading-relaxed">
                    Katalogdaki yenilikçi cihazların yanındaki kalp simgesine basarak onları favori listenize ekleyebilir ve daha sonra inceleyebilirsiniz.
                  </p>
                </div>
              ) : (
                <div className="space-y-4 max-h-[380px] overflow-y-auto pr-1">
                  {favorites.map((favId) => {
                    const product = products.find(p => p.id === favId);
                    if (!product) return null;
                    const lowest = product.marketplace.length > 0 
                      ? Math.min(...product.marketplace.map(m => m.price))
                      : 0;
                    return (
                      <div 
                        key={favId}
                        className="flex items-center justify-between rounded-xl border border-gray-800/80 bg-gray-900/20 p-3.5 hover:border-gray-700/80 hover:bg-gray-900/40 transition-all gap-4"
                      >
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="text-[10px] font-mono bg-teal-950/20 border border-teal-900/30 text-teal-400 px-2 py-0.5 rounded">
                              {product.category}
                            </span>
                            <span className="text-xs font-mono font-bold text-teal-300">${lowest.toLocaleString()}</span>
                          </div>
                          <h4 className="font-display font-bold text-white text-sm truncate">{product.name}</h4>
                          <p className="text-[11px] text-gray-400 truncate mt-0.5 font-sans leading-normal">
                            {product.tagline}
                          </p>
                        </div>

                        <div className="flex items-center gap-1.5 shrink-0">
                          {/* Details action */}
                          <button
                            onClick={() => {
                              setSelectedProduct(product);
                              setIsFavoritesOpen(false);
                            }}
                            className="rounded-lg bg-gray-800 border border-gray-700 hover:bg-gray-700 px-2.5 py-1.5 text-[11px] font-semibold text-white transition-all cursor-pointer"
                          >
                            İncele
                          </button>

                          {/* Compare action */}
                          <button
                            onClick={() => {
                              handleToggleCompare(product);
                            }}
                            className={`rounded-lg px-2.5 py-1.5 text-[11px] font-semibold border transition-all cursor-pointer ${
                              compareList.some(p => p.id === product.id)
                                ? 'bg-teal-500 border-teal-500 text-dark-bg hover:bg-teal-600'
                                : 'border-gray-700 text-gray-300 hover:border-teal-500/40 bg-transparent'
                            }`}
                            title={compareList.some(p => p.id === product.id) ? "Kıyaslamadan Çıkar" : "Kıyaslamaya Ekle"}
                          >
                            <Scale className="h-3 w-3" />
                          </button>

                          {/* Remove favorited */}
                          <button
                            onClick={() => handleToggleFavorite(product)}
                            className="p-1.5 rounded-lg border border-red-900/30 hover:border-red-500/30 hover:bg-red-950/20 text-gray-500 hover:text-red-400 transition-all cursor-pointer"
                            title="Favoriden Çıkar"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* LIVE SIMULATED ORDER TRACKING SIDE OVER PANEL */}
      <OrderTrackingModal
        isOpen={isOrdersOpen}
        onClose={() => setIsOrdersOpen(false)}
        orders={orders}
        onCancelOrder={handleCancelOrder}
        onClearHistory={handleClearOrders}
        onRepeatPurchase={handleRepeatPurchase}
        onViewProduct={handleViewProduct}
      />

    </div>
  );
}
