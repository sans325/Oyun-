export interface GlossaryItem {
  term: string;
  definition: string;
}

export const GLOSSARY: Record<string, string> = {
  'Mikro-OLED': 'Piksel yoğunluğu son derece yüksek olan, her bir pikselin kendi ışığını ürettiği ve olağanüstü siyah dengesi sunan yeni nesil ekran teknolojisi.',
  'M3': 'Apple tarafından üretilen, yüksek performanslı ve düşük güç tüketimli 3 nanometre mimarili ARM tabanlı işlemci ailesi.',
  'R2': 'Apple Vision Pro içinde yer alan, kameralardan, sensörlerden ve mikrofonlardan gelen verileri milisaniyeler içinde işleyen özel yardımcı işlemci.',
  'visionOS': 'Apple\'ın mekansal bilgi işlem ve karma gerçeklik başlıkları için özel geliştirdiği üç boyutlu kullanıcı arayüzüne sahip işletim sistemi.',
  'GDDR7': 'Ekran kartları için tasarlanmış, ultra yüksek bant genişliği ve veri iletim hızı sunan en gelişmiş grafik bellek standardı.',
  'Blackwell': 'NVIDIA\'nın üretken yapay zeka ve yüksek performanslı grafikler için geliştirdiği en yeni mikro mimari ailesi.',
  'DLSS 4.5': 'Derin Öğrenme Süper Örnekleme anlamına gelen, yapay zeka kullanarak düşük çözünürlüklü görüntüleri pürüzsüzce yükselten ve kare üreten NVIDIA teknolojisi.',
  'CUDA': 'NVIDIA tarafından geliştirilen, ekran kartının paralel işlem gücünü genel hesaplama görevleri için kullanılabilir hale getiren mimari ve programlama dili.',
  'TDP': 'Termal Tasarım Gücü anlamına gelen, bir donanım bileşeninin maksimum yük altında yaydığı ve soğutma sisteminin uzaklaştırması gereken ısı enerjisi miktarı (Watt cinsinden).',
  'SO-DIMM': 'Özellikle dizüstü bilgisayarlarda kullanılan, küçük boyutlu RAM (bellek) modülü standardı.',
  'NVMe SSD': 'Doğrudan PCIe veri yoluna bağlanarak klasik disklere kıyasla binlerce kat daha hızlı veri okuma ve yazma sağlayan depolama teknolojisi.',
  'IPS': 'Geniş görüş açıları, doğru renk üretimi ve yüksek parlaklık sunan popüler LCD panel teknolojisi.',
  'HRV': 'Kalp Atış Hızı Değişkenliği anlamına gelen, ardışık kalp atışları arasındaki milisaniyelik zaman farkı. Stres ve fiziksel toparlanma durumunu gösterir.',
  '10 ATM': 'Cihazın 100 metre derinliğindeki su basıncına kadar su geçirmez olduğunu gösteren dayanıklılık derecesi.',
  'IP68': 'Toza karşı tam korumalı olduğunu ve belirli bir derinlikteki suda sürekli kalmaya karşı dayanıklı olduğunu gösteren uluslararası standart.',
  'IP67': 'Toza karşı tam korumalı olduğunu ve 1 metre derinliğindeki suda 30 dakikaya kadar kalmaya karşı dayanıklı olduğunu belirten koruma standardı.',
  'FSD': 'Full Self-Driving anlamına gelen, otonom sürüş ve hareket yetenekleri sağlayan Tesla yapay zeka işlemcisi ve sinir ağı sistemi.',
  'Aktüatör': 'Elektrik enerjisini mekanik harekete ve torka dönüştüren, robotların eklem hareketlerini sağlayan motor ve dişli mekanizması.',
  'DOF': 'Serbestlik Derecesi anlamına gelen, bir mekanizmanın (örneğin robotik elin) kaç bağımsız yönde hareket edebildiğini gösteren değer.',
  'USB-PD': 'USB Power Delivery standardı. Tek bir Type-C kablosu üzerinden 100W ila 240W arasında yüksek güç aktarımı sağlayan teknoloji.',
  'Mbps': 'Saniyede iletilen megabit miktarı. İnternet indirme ve yükleme hızlarını ölçmek için kullanılır.',
  'Gecikme Süresi': 'Veri paketinin kaynaktan hedefe ulaşması için geçen milisaniye (ms) cinsinden süre (Ping).'
};
