export interface MarketplaceStore {
  id: string;
  storeName: string;
  price: number; // in USD
  rating: number; // Out of 5
  stockStatus: 'InStock' | 'LowStock' | 'OutOfStock';
  deliveryDays: number;
  url: string;
}

export interface TechnicalSpec {
  label: string;
  value: string;
}

export interface Product {
  id: string;
  name: string;
  tagline: string;
  category: 'Giyilebilir Teknoloji' | 'Yapay Zeka & Robotik' | 'Sanal & Artırılmış Gerçeklik' | 'Donanım & Bilgisayar' | 'Akıllı Çevre & İletişim';
  priceRange: string;
  image: string; // Theme-based or illustration description
  description: string;
  longDescription: string;
  pros: string[];
  cons: string[];
  specs: TechnicalSpec[];
  marketplace: MarketplaceStore[];
  performanceMetrics: {
    label: string;
    value: number; // 0 to 100 for visual bars
  }[];
}

export const PRODUCTS: Product[] = [
  {
    id: 'apple-vision-pro-2',
    name: 'Apple Vision Pro 2',
    tagline: 'Mekansal bilgi işlem dünyasının en gelişmiş karma gerçeklik başlığı.',
    category: 'Sanal & Artırılmış Gerçeklik',
    priceRange: '$3299 - $3499',
    image: 'vision_pro',
    description: 'Çift mikro-OLED ekranı, göz ve el takibi yetenekleri ve güçlü M3/R2 işlemci kombinasyonuyla dijital içeriği fiziksel dünyayla kusursuz şekilde birleştirir.',
    longDescription: 'Apple Vision Pro 2, profesyonel üretkenlik, mekansal eğlence ve yüksek kaliteli iletişim için tasarlanmış devrim niteliğinde bir mekansal bilgisayardır. Gelişmiş göz ve el takip kameraları sayesinde harici bir kontrolcüye ihtiyaç duymadan, sadece bakarak ve parmaklarınızı dokundurarak arayüzü kontrol edebilirsiniz. Ultra yüksek çözünürlüklü ekranları her bir göz için bir 4K televizyondan daha fazla piksel sunarak benzersiz bir netlik sağlar.',
    pros: [
      'Göz alıcı mikro-OLED 4K ekran çözünürlüğü',
      'Kusursuz el ve göz takip performansı',
      'Güçlü M3 ve R2 çip mimarisi',
      'Geniş uygulama ekosistemi entegrasyonu'
    ],
    cons: [
      'Yüksek başlangıç fiyatı',
      'Harici batarya kablosu kullanımı',
      'Uzun süreli kullanımda ağırlık hissi'
    ],
    specs: [
      { label: 'Ekran Teknolojisi', value: 'Çift Mikro-OLED, 23 Milyon Piksel' },
      { label: 'Yonga Seti (İşlemci)', value: 'Apple M3 ve Apple R2 (Sensör İşleme)' },
      { label: 'Görüş Açısı (FOV)', value: 'Yaklaşık 110 Derece' },
      { label: 'İşletim Sistemi', value: 'visionOS 3.0' },
      { label: 'Ağırlık', value: '595 gram' },
      { label: 'Batarya Ömrü', value: 'Harici Batarya ile 2.5 - 3 Saat' }
    ],
    performanceMetrics: [
      { label: 'Ekran Kalitesi', value: 98 },
      { label: 'Takip Hassasiyeti', value: 96 },
      { label: 'İşlem Gücü', value: 92 },
      { label: 'Taşınabilirlik', value: 65 },
      { label: 'Fiyat/Performans', value: 40 }
    ],
    marketplace: [
      {
        id: 'vatan-tech',
        storeName: 'TeknoGlobal Store',
        price: 3299,
        rating: 4.8,
        stockStatus: 'InStock',
        deliveryDays: 2,
        url: 'https://example.com/store/teknoglobal/vision-pro-2'
      },
      {
        id: 'vatan-arasi',
        storeName: 'VatanArası Teknoloji',
        price: 3399,
        rating: 4.6,
        stockStatus: 'LowStock',
        deliveryDays: 3,
        url: 'https://example.com/store/vatanarasi/vision-pro-2'
      },
      {
        id: 'global-cargo',
        storeName: 'GlobalImport Express',
        price: 3199,
        rating: 4.2,
        stockStatus: 'InStock',
        deliveryDays: 7,
        url: 'https://example.com/store/globalimport/vision-pro-2'
      }
    ]
  },
  {
    id: 'nvidia-rtx-5090',
    name: 'NVIDIA GeForce RTX 5090',
    tagline: 'Yapay zeka ve ultra-grafik çağını başlatan en güçlü masaüstü ekran kartı.',
    category: 'Donanım & Bilgisayar',
    priceRange: '$1999 - $2200',
    image: 'rtx_5090',
    description: 'Blackwell mimarisi üzerine kurulu 32GB GDDR7 belleği, yapay zeka destekli DLSS 4.5 teknolojisi ile profesyoneller ve ekstrem oyuncular için sınırları zorlar.',
    longDescription: 'NVIDIA RTX 5090, en zorlu yapay zeka model eğitimlerinden 8K çözünürlükte gerçek zamanlı ışın izleme (Ray Tracing) oyun deneyimine kadar her alanda liderlik koltuğundadır. Yeni Blackwell mimarisi sayesinde güç tüketim verimliliği optimize edilmiş ve Tensör çekirdekleri yapay zeka çıkarımlarında 2 kata kadar performans artışı sunacak şekilde güncellenmiştir.',
    pros: [
      'Deasa 32GB GDDR7 yüksek hızlı bellek kapasitesi',
      'Yapay zeka destekli DLSS 4.5 ve Frame Generation',
      'Profesyonel render ve AI iş yüklerinde rakipsiz hız',
      'Geliştirilmiş PCIe Gen 5 desteği'
    ],
    cons: [
      'Çok yüksek güç tüketimi (TDP ~500W)',
      'Büyük fiziksel boyut (Kasa uyumluluk sorunu)',
      'Ekstra güç kaynağı (PSU) yatırımı gerektirmesi'
    ],
    specs: [
      { label: 'Grafik Yongası', value: 'GB102 (Blackwell Mimarisi)' },
      { label: 'Video Belleği', value: '32 GB GDDR7' },
      { label: 'Bellek Arayüzü', value: '512-bit' },
      { label: 'CUDA Çekirdekleri', value: '21,760 Çekirdek' },
      { label: 'Güç Tüketimi (TDP)', value: '500W (Önerilen 1000W+ PSU)' },
      { label: 'Bağlantı Arayüzü', value: 'HDMI 2.1a, DisplayPort 2.1' }
    ],
    performanceMetrics: [
      { label: 'Oyun Performansı', value: 100 },
      { label: 'AI İşleme Gücü', value: 99 },
      { label: 'Grafik Belleği', value: 98 },
      { label: 'Güç Verimliliği', value: 50 },
      { label: 'Fiyat/Performans', value: 55 }
    ],
    marketplace: [
      {
        id: 'itopya-tech',
        storeName: 'SinerjiMaks Bilgisayar',
        price: 1999,
        rating: 4.9,
        stockStatus: 'InStock',
        deliveryDays: 1,
        url: 'https://example.com/store/sinerjimaks/rtx-5090'
      },
      {
        id: 'teknoloji-deposu',
        storeName: 'TeknolojiDeposu',
        price: 2049,
        rating: 4.7,
        stockStatus: 'InStock',
        deliveryDays: 2,
        url: 'https://example.com/store/teknodepo/rtx-5090'
      },
      {
        id: 'hepsitrend',
        storeName: 'Hepsitrend Market',
        price: 2150,
        rating: 4.4,
        stockStatus: 'LowStock',
        deliveryDays: 3,
        url: 'https://example.com/store/hepsitrend/rtx-5090'
      }
    ]
  },
  {
    id: 'framework-laptop-16',
    name: 'Framework Laptop 16',
    tagline: 'Tamamen özelleştirilebilir, yükseltilebilir ve onarılabilir modüler bilgisayar.',
    category: 'Donanım & Bilgisayar',
    priceRange: '$1699 - $1999',
    image: 'framework_16',
    description: 'Giriş-çıkış portlarından klavye düzenine, ekran kartı modülünden ana karta kadar her parçası kullanıcı tarafından kolayca değiştirilebilen sürdürülebilir dizüstü bilgisayar.',
    longDescription: 'Framework Laptop 16, elektronik atık miktarını azaltmak ve kullanıcılara tam cihaz kontrolü vermek amacıyla tasarlanmış yenilikçi bir modüler bilgisayardır. Yan kısımlardaki genişleme yuvaları sayesinde USB-C, HDMI, DisplayPort, MicroSD gibi portları anında değiştirebilirsiniz. Arka kısımdaki bağımsız GPU modülü, ilerleyen yıllarda bilgisayarınızı değiştirmeden sadece ekran kartını yükseltmenizi sağlar.',
    pros: [
      'Tamamen onarılabilir ve yükseltilebilir tasarım',
      'Kolayca değiştirilebilen giriş/çıkış port kartları',
      'Bağımsız ve yükseltilebilir harici grafik modülü',
      'Açık kaynaklı donanım şemaları ve sürdürülebilirlik'
    ],
    cons: [
      'Geleneksel ince dizüstü bilgisayarlara göre daha kalın',
      'İlk kurulum ve modül yönetimi teknik bilgi gerektirebilir',
      'Hoparlör ve kasa esnekliği ultrabook standartlarının biraz gerisinde'
    ],
    specs: [
      { label: 'İşlemci Seçeceği', value: 'AMD Ryzen 7 7840HS / Ryzen 9 7940HS' },
      { label: 'Grafik Kartı', value: 'Modüler AMD Radeon RX 7700S (8GB GDDR6)' },
      { label: 'Bellek (RAM)', value: '64 GB-a kadar DDR5 (Yükseltilebilir SO-DIMM)' },
      { label: 'Ekran', value: '16 inç, 2560x1600, 165Hz IPS' },
      { label: 'Depolama', value: 'Çift M.2 NVMe SSD Yuvası (Onarılabilir)' },
      { label: 'Genişleme Kartları', value: '6 Adet Değiştirilebilir Port Modülü' }
    ],
    performanceMetrics: [
      { label: 'Sürdürülebilirlik', value: 100 },
      { label: 'Yükseltilebilirlik', value: 100 },
      { label: 'İşlem Gücü', value: 80 },
      { label: 'Pil Ömrü', value: 70 },
      { label: 'Taşınabilirlik', value: 68 }
    ],
    marketplace: [
      {
        id: 'moduler-tekno',
        storeName: 'ModülerTekno Türkiye',
        price: 1749,
        rating: 4.7,
        stockStatus: 'InStock',
        deliveryDays: 2,
        url: 'https://example.com/store/modulertekno/framework-16'
      },
      {
        id: 'yesil-bilişim',
        storeName: 'Yeşil Bilişim Sürdürülebilir Market',
        price: 1699,
        rating: 4.9,
        stockStatus: 'LowStock',
        deliveryDays: 4,
        url: 'https://example.com/store/yesilbilisim/framework-16'
      }
    ]
  },
  {
    id: 'samsung-galaxy-ring',
    name: 'Samsung Galaxy Ring',
    tagline: '7/24 kesintisiz sağlık takibi sunan minimalist akıllı yüzük.',
    category: 'Giyilebilir Teknoloji',
    priceRange: '$399 - $449',
    image: 'galaxy_ring',
    description: 'Titanyum gövdesi, uyku analizi yapan yapay zekası, kalp ritmi ve cilt sıcaklığı sensörleriyle görünmez bir sağlık asistanı gibi çalışır.',
    longDescription: 'Samsung Galaxy Ring, ekran taşımayan, dikkatinizi dağıtmayan ve akıllı saatlere zarif bir alternatif sunan ultra hafif bir giyilebilir cihazdır. Şarj kutusuyla birlikte 7 güne kadar pil ömrü sunan bu cihaz, uyku kalitenizi, gece boyunca cilt sıcaklığı değişimlerinizi, kalp atış hızı değişkenliğinizi (HRV) ve günlük aktivitelerinizi Samsung Health uygulaması üzerinden yapay zeka analizleriyle size sunar.',
    pros: [
      'Son derece hafif (2.3g - 3g arası) ve dayanıklı titanyum tasarım',
      'Ekran olmadığı için 7 güne varan uzun pil ömrü',
      'Detaylı uyku evreleri ve stres seviyesi analizi',
      'Abonelik ücreti gerektirmeyen veri erişimi'
    ],
    cons: [
      'Görsel bildirim veya ekran uyarısı bulunmuyor',
      'Tam uyum için doğru yüzük ölçüsünü bulma zorunluluğu',
      'iOS / Apple ekosistemiyle sınırlı uyumluluk'
    ],
    specs: [
      { label: 'Gövde Malzemesi', value: 'Sınıf 5 Titanyum, Çizilmeye Dayanıklı Kaplama' },
      { label: 'Su Geçirmezlik', value: '10 ATM (100 Metre) ve IP68' },
      { label: 'Sensörler', value: 'Optik Kalp Atış Hızı, Sıcaklık Sensörü, İvmeölçer' },
      { label: 'Bağlantı', value: 'Bluetooth Low Energy 5.4' },
      { label: 'Ağırlık', value: 'Yalnızca 2.3 gram (Ölçü 5) - 3.0 gram (Ölçü 13)' },
      { label: 'Şarj Süresi', value: 'Şarj Kutusu ile 80 Dakikada %100' }
    ],
    performanceMetrics: [
      { label: 'Taşınabilirlik', value: 99 },
      { label: 'Pil Ömrü', value: 92 },
      { label: 'Sensör Hassasiyeti', value: 88 },
      { label: 'Dayanıklılık', value: 94 },
      { label: 'Ekosistem Entegrasyonu', value: 75 }
    ],
    marketplace: [
      {
        id: 'samsung-tr',
        storeName: 'Samsung Resmi Mağazası',
        price: 399,
        rating: 4.8,
        stockStatus: 'InStock',
        deliveryDays: 1,
        url: 'https://example.com/store/samsung/galaxy-ring'
      },
      {
        id: 'teknosa-ring',
        storeName: 'TeknoRing Mağazası',
        price: 419,
        rating: 4.5,
        stockStatus: 'InStock',
        deliveryDays: 2,
        url: 'https://example.com/store/teknoring/galaxy-ring'
      }
    ]
  },
  {
    id: 'tesla-optimus-devkit',
    name: 'Tesla Optimus Bot (Geliştirici Sürümü)',
    tagline: 'Yapay zeka ile hareket eden insansı robotik platform.',
    category: 'Yapay Zeka & Robotik',
    priceRange: '$19900 - $22000',
    image: 'optimus_bot',
    description: 'Tesla otopilot bilgisayarı ve sinir ağları ile eğitilen, 28 adet tork aktüatörü ve 11 serbestlik dereceli elleriyle karmaşık fiziksel görevleri üstlenen insansı robot kiti.',
    longDescription: 'Tesla Optimus Bot Developer Kit, yapay zeka araştırmacıları, endüstriyel otomasyon mühendisleri ve robotik meraklıları için özel olarak tasarlanmış insansı robot sürümüdür. Tesla araçlarında kullanılan FSD (Full Self-Driving) bilgisayarıyla donatılmış olan robot, çevresini 2B ve 3B kameralarla algılar, mekansal haritalama yapar ve derin pekiştirmeli öğrenme modellerini çalıştırabilir. Hassas elleri sayesinde aletleri tutabilir, nesneleri sınıflandırabilir ve tekrarlayan fabrikasyon işlerini yapabilir.',
    pros: [
      'Gelişmiş insan taklidi el becerisi (11 DOF eller)',
      'Tesla FSD yapay zeka işlemcisi ile gerçek zamanlı nesne algılama',
      'Zengin API ve SDK desteği ile özelleştirilebilir Python kod tabanı',
      'Yüksek torklu dayanıklı eklemler'
    ],
    cons: [
      'Aşırı yüksek fiyat segmenti',
      'Ev içi kullanım için henüz tam olgunlaşmamış güvenlik protokolleri',
      'Sınırlı batarya kapasitesi (yaklaşık 2-3 saat çalışma)'
    ],
    specs: [
      { label: 'Boy ve Ağırlık', value: '173 cm boy, 56 kg ağırlık' },
      { label: 'Yapay Zeka Beyni', value: 'Tesla FSD Çip Entegreli Sinir Ağı Bilgisayarı' },
      { label: 'Hareket Özgürlüğü', value: 'Tüm gövdede 28 Eklemli Aktüatör' },
      { label: 'Maksimum Taşıma', value: '20 kg yük kaldırma kapasitesi' },
      { label: 'Yürüme Hızı', value: '8 km/s maksimum hız' },
      { label: 'Batarya', value: '2.3 kWh nominal kapasiteli Lityum-İyon pil' }
    ],
    performanceMetrics: [
      { label: 'Robotik Beceri', value: 90 },
      { label: 'AI Karar Verme', value: 85 },
      { label: 'Mekanik Dayanıklılık', value: 88 },
      { label: 'Pil Yönetimi', value: 60 },
      { label: 'Kullanım Kolaylığı', value: 45 }
    ],
    marketplace: [
      {
        id: 'tesla-direct',
        storeName: 'Tesla Robotics Hub',
        price: 19900,
        rating: 4.9,
        stockStatus: 'LowStock',
        deliveryDays: 14,
        url: 'https://example.com/store/tesla/optimus-devkit'
      },
      {
        id: 'robo-borsa',
        storeName: 'RoboBorsa Gelişmiş Sistemler',
        price: 21500,
        rating: 4.3,
        stockStatus: 'OutOfStock',
        deliveryDays: 30,
        url: 'https://example.com/store/roboborsa/optimus-devkit'
      }
    ]
  },
  {
    id: 'starlink-mini',
    name: 'Starlink Mini',
    tagline: 'Sırt çantanıza sığabilen taşınabilir, ultra hızlı uydu internet terminali.',
    category: 'Akıllı Çevre & İletişim',
    priceRange: '$599 - $649',
    image: 'starlink_mini',
    description: 'Entegre Wi-Fi yönlendiricisi, düşük güç tüketimi ve USB-PD güç desteğiyle dünyanın her yerinden yüksek hızlı internete erişim sağlar.',
    longDescription: 'Starlink Mini, taşınabilirliği en üst seviyeye taşıyan kompakt bir uydu alıcısıdır. Geleneksel Starlink çanaklarının aksine Wi-Fi yönlendirici donanımını doğrudan anten gövdesine entegre eder ve DC veya standart bir Type-C Powerbank (100W PD) ile çalışabilir. Dağ tırmanışlarında, karavan seyahatlerinde veya şebekenin olmadığı ücra köşelerde 150 Mbps hızında düşük gecikmeli geniş bant internet sunar.',
    pros: [
      'Geleneksel Starlink çanaklarına göre yarı yarıya küçük ve hafif',
      'Type-C Powerbank ile çalışabilme özgürlüğü',
      'Dahili Wi-Fi 5 yönlendiricisi ile daha az kablo karmaşası',
      'Suya ve zorlu hava koşullarına tam dayanıklılık (IP67)'
    ],
    cons: [
      'Büyük çanak modeline göre daha düşük maksimum indirme hızı (100-150 Mbps)',
      'Kapsama alanı ağaçlık bölgelerde gökyüzünü tam görme zorunluluğu',
      'Aylık servis abonelik ücretinin yüksek olması'
    ],
    specs: [
      { label: 'Boyutlar', value: '298 x 259 x 38 mm' },
      { label: 'Ağırlık', value: '1.1 kg (Anten ve ayaklık dahil)' },
      { label: 'Güç Tüketimi', value: 'Ortalama 25W - 40W' },
      { label: 'Veri Hızı', value: '100 - 150 Mbps İndirme, 15 - 25 Mbps Yükleme' },
      { label: 'Gecikme Süresi', value: '23ms - 35ms' },
      { label: 'Giriş Voltajı', value: '12V - 48V DC, USB-PD 100W minimum destek' }
    ],
    performanceMetrics: [
      { label: 'Taşınabilirlik', value: 95 },
      { label: 'Bağlantı Hızı', value: 82 },
      { label: 'Gecikme Süresi', value: 85 },
      { label: 'Kurulum Kolaylığı', value: 94 },
      { label: 'Güç Verimliliği', value: 90 }
    ],
    marketplace: [
      {
        id: 'starlink-official',
        storeName: 'Starlink Global Store',
        price: 599,
        rating: 4.9,
        stockStatus: 'InStock',
        deliveryDays: 4,
        url: 'https://example.com/store/starlink/mini'
      },
      {
        id: 'outdoor-net',
        storeName: 'OutdoorNet Karavan Market',
        price: 649,
        rating: 4.7,
        stockStatus: 'InStock',
        deliveryDays: 2,
        url: 'https://example.com/store/outdoornet/starlink-mini'
      }
    ]
  }
];
