import express from "express";
import path from "path";
import dotenv from "dotenv";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, ThinkingLevel, Type } from "@google/genai";
import { PRODUCTS, Product } from "./src/data/products.js";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// In-memory data store that can be appended by AI discovery
let ALL_PRODUCTS = [...PRODUCTS];

// Fallback data for discovery when Gemini API is rate-limited or exhausted
const FALLBACK_DISCOVER_PRODUCTS: any[] = [
  {
    id: "meta-orion-glasses",
    name: "Meta Orion AR Gözlüğü",
    tagline: "Hafif ve şık tasarımıyla geleceğin artırılmış gerçeklik deneyimi.",
    category: "Sanal & Artırılmış Gerçeklik",
    priceRange: "$1499 - $1799",
    image: "meta_orion",
    description: "Meta'nın ilk gerçek hologram yansıtabilen, ultra geniş görüş açılı ve hafif akıllı AR gözlüğü prototipi.",
    longDescription: "Meta Orion, günlük kullanım gözlüğü boyutlarında üretilmiş devrimsel bir artırılmış gerçeklik donanımıdır. Silisyum karbür lensleri ve özel tasarlanmış mikro-LED projeksiyon motoru sayesinde doğrudan gözünüzün önüne son derece net dijital hologramlar yerleştirir. Yapay zeka destekli çevre algılama, sesli komut ve el hareketleriyle kontrol yetenekleri sunar.",
    pros: [
      "Normal gözlük ağırlığına son derece yakın şık form faktörü",
      "70 derece geniş görüş açılı parlak mikro-LED projeksiyonlar",
      "Gelişmiş AI sesli asistan ve nesne tanıma yetenekleri"
    ],
    cons: [
      "Şimdilik kısıtlı geliştirici sürümü bulunması",
      "Dış mekanda yoğun güneş ışığında hafif parlaklık kaybı"
    ],
    specs: [
      { label: "Lens Malzemesi", value: "Silisyum Karbür" },
      { label: "Projeksiyon Motoru", value: "Çift Mikro-LED" },
      { label: "Ağırlık", value: "98 gram" },
      { label: "Arayüz Kontrolü", value: "Nöral El Bandı ve Göz Takibi" },
      { label: "Pil Ömrü", value: "Kesintisiz kullanımda 4-5 Saat" }
    ],
    marketplace: [
      {
        id: "meta-shop",
        storeName: "Meta DevStore Turkey",
        price: 1499,
        rating: 4.9,
        stockStatus: "LowStock",
        deliveryDays: 5,
        url: "https://example.com/meta-orion"
      },
      {
        id: "hologram-center",
        storeName: "Hologram Tekno Center",
        price: 1599,
        rating: 4.7,
        stockStatus: "InStock",
        deliveryDays: 3,
        url: "https://example.com/meta-orion-hologram"
      }
    ],
    performanceMetrics: [
      { label: "Ekran Kalitesi", value: 92 },
      { label: "Takip Hassasiyeti", value: 95 },
      { label: "İşlem Gücü", value: 88 },
      { label: "Taşınabilirlik", value: 96 },
      { label: "Fiyat/Performans", value: 80 }
    ]
  },
  {
    id: "rabbit-r1-pro",
    name: "Rabbit R1 Pro AI",
    tagline: "Büyük Eylem Modeli (LAM) destekli yeni nesil akıllı el asistanı.",
    category: "Yapay Zeka & Robotik",
    priceRange: "$299 - $349",
    image: "rabbit_r1_pro",
    description: "Ekransız arayüz yönetimi, sesli komutlarla karmaşık web görevlerini otomatikleştirme ve gelişmiş yapay zeka işlem motoru.",
    longDescription: "Rabbit R1 Pro, sesinizle verdiğiniz karmaşık komutları arka planda web uygulamaları üzerinden sizin adınıza gerçekleştiren bir LAM (Large Action Model) asistanıdır. Yenilenen metal gövdesi, dönebilen 360 derecelik akıllı kamerası ve kesintisiz 5G bağlantısıyla akıllı telefon kullanımınızı en aza indirerek doğrudan eyleme odaklanır.",
    pros: [
      "LAM teknolojisi ile web sitelerinde sizin yerinize işlem yapabilme",
      "Kompakt, şık Teenage Engineering tasarımı",
      "Hızlı ve kesintisiz 5G hücresel bağlantı seçeneği"
    ],
    cons: [
      "Bazı özel entegrasyonlar için üçüncü parti hesap yetkilendirmesi gerektirmesi",
      "Ekranda çok yoğun veri okumak için küçük kalması"
    ],
    specs: [
      { label: "İşletim Sistemi", value: "rabbit OS 2.0" },
      { label: "Yapay Zeka Modeli", value: "Rabbit LAM & Gemini Flash Entegrasyonu" },
      { label: "Bağlantı Teknolojisi", value: "5G, Wi-Fi 6E, Bluetooth 5.3" },
      { label: "Kamera", value: "360 Derece Dönebilen 12MP Sensör" },
      { label: "Boyutlar", value: "7.8 x 7.8 x 1.3 cm" }
    ],
    marketplace: [
      {
        id: "rabbit-official",
        storeName: "Rabbit Global Distribütör",
        price: 299,
        rating: 4.6,
        stockStatus: "InStock",
        deliveryDays: 4,
        url: "https://example.com/rabbit-r1-pro"
      },
      {
        id: "turk-ai-store",
        storeName: "TurkAI Premium Mağaza",
        price: 329,
        rating: 4.4,
        stockStatus: "LowStock",
        deliveryDays: 2,
        url: "https://example.com/rabbit-r1-pro-turk"
      }
    ],
    performanceMetrics: [
      { label: "Ekran Kalitesi", value: 60 },
      { label: "Takip Hassasiyeti", value: 90 },
      { label: "İşlem Gücü", value: 85 },
      { label: "Taşınabilirlik", value: 98 },
      { label: "Fiyat/Performans", value: 88 }
    ]
  },
  {
    id: "neuralink-telepathy-band",
    name: "Neuralink Telepathy Band",
    tagline: "Odaklanma ve zihinsel komut desteği sunan gelişmiş kafa bandı.",
    category: "Giyilebilir Teknoloji",
    priceRange: "$499 - $549",
    image: "neuralink_band",
    description: "Cerrahi müdahale gerektirmeyen, saç derisinden yüksek hassasiyetli EEG okuyabilen nöral giyilebilir kafa bandı.",
    longDescription: "Neuralink Telepathy Band, cerrahi operasyon istemeyen kullanıcılar için kafa derisi üzerinden hassas beyin dalgaları (EEG) analizi gerçekleştiren giyilebilir bir teknolojidir. Bilgisayar oyunları kontrolü, odaklanma eğitimi, stres yönetimi ve akıllı ev otomasyonlarını doğrudan zihninizle kumanda etme imkanı sunar.",
    pros: [
      "Cerrahi müdahale gerektirmeyen tamamen güvenli EEG okuma",
      "Ev otomasyonları ve basit oyun kontrolleriyle eğlenceli entegrasyon",
      "Stres ve odaklanma seviyelerini anlık görselleştirme"
    ],
    cons: [
      "Zihinsel odak kontrolü için başlangıçta küçük bir alışma süresi gerektirmesi",
      "Kafa yapısına göre uzun süreli takmada alışkanlık istemesi"
    ],
    specs: [
      { label: "Sensör Sayısı", value: "16 Kanal Yüksek Hassasiyetli EEG Sensörü" },
      { label: "Kablosuz İletişim", value: "Ultra Düşük Gecikmeli Bluetooth 5.4" },
      { label: "Uyumlu Platformlar", value: "Windows, macOS, iOS, Android" },
      { label: "Batarya Süresi", value: "Tek şarjla 12 Saate kadar kullanım" },
      { label: "Şarj Tipi", value: "Kablosuz Manyetik Şarj" }
    ],
    marketplace: [
      {
        id: "neuro-direct",
        storeName: "NeuroTech Direct",
        price: 499,
        rating: 4.7,
        stockStatus: "InStock",
        deliveryDays: 3,
        url: "https://example.com/neuralink-band"
      }
    ],
    performanceMetrics: [
      { label: "Ekran Kalitesi", value: 10 },
      { label: "Takip Hassasiyeti", value: 85 },
      { label: "İşlem Gücü", value: 80 },
      { label: "Taşınabilirlik", value: 94 },
      { label: "Fiyat/Performans", value: 78 }
    ]
  }
];

// Helper to generate a smart matched recommendation offline
function generateLocalRecommendations(budget: number | null, primaryUse: string, selectedCategory: string, customNeeds: string) {
  let candidates = [...ALL_PRODUCTS];
  if (selectedCategory && selectedCategory !== "Hepsi") {
    candidates = candidates.filter(p => p.category === selectedCategory);
  }
  
  if (candidates.length === 0) {
    candidates = [...ALL_PRODUCTS];
  }
  
  if (budget) {
    candidates = candidates.map(p => {
      const prices = p.marketplace.map(m => m.price);
      const minPrice = prices.length > 0 ? Math.min(...prices) : 0;
      const diff = Math.abs(minPrice - budget);
      return { product: p, diff };
    })
    .sort((a, b) => a.diff - b.diff)
    .map(x => x.product);
  } else {
    candidates.sort((a, b) => {
      const aPower = a.performanceMetrics.find(m => m.label === "İşlem Gücü")?.value || 50;
      const bPower = b.performanceMetrics.find(m => m.label === "İşlem Gücü")?.value || 50;
      return bPower - aPower;
    });
  }

  const chosen = candidates.slice(0, Math.min(candidates.length, 3));
  
  const recommendedProducts = chosen.map((p, index) => {
    let score = 95 - index * 5;
    if (budget) {
      const prices = p.marketplace.map(m => m.price);
      const minPrice = prices.length > 0 ? Math.min(...prices) : 0;
      if (minPrice > budget) score -= 15;
    }
    if (score < 50) score = 65;

    let reasoning = "";
    if (p.id === 'apple-vision-pro-2') {
      reasoning = `Apple Vision Pro 2, sunduğu benzersiz mekansal hesaplama yetenekleriyle ${primaryUse || 'günlük kullanım'} ihtiyaçlarınız için harika bir derinlik ve üretkenlik sunar. Yüksek çözünürlüklü çift mikro-OLED ekranları, çalışmalarınızda ve eğlence aktivitelerinizde sınırları ortadan kaldıracaktır.`;
    } else if (p.id === 'nvidia-rtx-5090') {
      reasoning = `NVIDIA GeForce RTX 5090, 32GB GDDR7 belleği ve yüksek işlem gücüyle grafik tasarımı, 3D render, yapay zeka geliştirme ve üst düzey oyun hedefleriniz için mutlak lider seçenektir. Bütçeniz dahilindeki en güçlü seçenektir.`;
    } else if (p.id === 'framework-laptop-16') {
      reasoning = `Framework Laptop 16, tamamen modüler ve tamir edilebilir yapısıyla ${primaryUse || 'mobilite/günlük'} kullanımda benzersiz bir esneklik sunar. Parçaları dilediğiniz gibi güncelleyerek uzun ömürlü ve verimli bir yatırıma imza atabilirsiniz.`;
    } else if (p.id === 'samsung-galaxy-ring') {
      reasoning = `Samsung Galaxy Ring, gün boyu konforlu tasarımı ve hassas biyometrik takip yetenekleriyle sağlık ve mobilite öncelikleriniz için mükemmel bir günlük asistandır.`;
    } else if (p.id === 'tesla-optimus-devkit') {
      reasoning = `Tesla Optimus Devkit, yapay zeka, otomasyon ve yazılım geliştirme vizyonunuz için eşsiz bir deneysel platformdur. Robotik sistemlere meraklıysanız teknik gücüyle sizi tatmin edecektir.`;
    } else if (p.id === 'starlink-mini') {
      reasoning = `Starlink Mini, her yerde kesintisiz ve yüksek hızlı uydu interneti sağlayarak ${primaryUse || 'taşınabilir/uzaktan çalışma'} ihtiyaçlarınızı dünyanın her yerinden karşılamanızı sağlar.`;
    } else {
      reasoning = `${p.name}, bütçeniz ve ${primaryUse || 'günlük'} kullanım amacınızla yüksek oranda eşleşen modern donanımı ve optimize edilmiş özellikleri sayesinde mükemmel bir performans/verimlilik dengesi sunar.`;
    }

    return {
      productId: p.id,
      matchScore: score,
      reasoning: reasoning
    };
  });

  const userAnalysis = `Belirttiğiniz kriterleri (Bütçe: ${budget ? `$${budget}` : "Belirtilmemiş"}, Amaç: ${primaryUse || "Genel kullanım"}, Kategori: ${selectedCategory || "Hepsi"}) analiz ettik. ${customNeeds ? `"${customNeeds}" yönündeki özel talepleriniz de teknik kriterlerimize dahil edilmiştir.` : ""} Size en yüksek verimlilik, işlem gücü ve kullanım memnuniyeti sağlayacak alternatif cihazları belirleyerek eşleştirdik.`;

  const genericAdvice = `Geleceğe yönelik teknoloji yatırımlarınızda donanım modülerliğine, enerji verimliliğine ve ekosistem uyumluluğuna dikkat etmeniz uzun vadeli memnuniyetiniz açısından faydalı olacaktır. Portföyümüzdeki ${selectedCategory && selectedCategory !== "Hepsi" ? selectedCategory : "yenilikçi"} cihazları inceleyerek ihtiyaçlarınızı en verimli şekilde karşılayabilirsiniz.`;

  return {
    userAnalysis,
    recommendedProducts,
    genericAdvice,
    isSimulated: true
  };
}

// Helper to generate a smart product comparison offline
function generateLocalComparison(selectedProducts: any[]) {
  const summaries: any = {};
  selectedProducts.forEach(p => {
    summaries[p.id] = `${p.name}, ${p.category} kategorisinde yer alan ve "${p.tagline}" vizyonuyla üretilmiş yüksek teknolojili bir donanımdır. Ana nitelikleri: ${p.description}`;
  });

  const keyDifferences: string[] = [];
  if (selectedProducts.length >= 2) {
    const p1 = selectedProducts[0];
    const p2 = selectedProducts[1];
    
    keyDifferences.push(`${p1.name} cihazının ana odak noktası daha çok ${p1.category} iken, ${p2.name} doğrudan ${p2.category} alanına hitap etmektedir.`);
    
    const p1Power = p1.performanceMetrics.find((m: any) => m.label === "İşlem Gücü")?.value || 80;
    const p2Power = p2.performanceMetrics.find((m: any) => m.label === "İşlem Gücü")?.value || 80;
    if (Math.abs(p1Power - p2Power) > 10) {
      const stronger = p1Power > p2Power ? p1 : p2;
      const weaker = p1Power > p2Power ? p2 : p1;
      keyDifferences.push(`Donanımsal ham güç ve işlem kapasitesi bakımından ${stronger.name} (${stronger.performanceMetrics.find((m: any) => m.label === "İşlem Gücü")?.value}/100), ${weaker.name} cihazına göre daha yüksek bir performans barındırır.`);
    }

    const p1Port = p1.performanceMetrics.find((m: any) => m.label === "Taşınabilirlik")?.value || 80;
    const p2Port = p2.performanceMetrics.find((m: any) => m.label === "Taşınabilirlik")?.value || 80;
    if (Math.abs(p1Port - p2Port) > 10) {
      const lighter = p1Port > p2Port ? p1 : p2;
      const heavier = p1Port > p2Port ? p2 : p1;
      keyDifferences.push(`Taşınabilirlik, hafiflik ve hareket özgürlüğü kriterlerinde ${lighter.name} cihazı, daha yüksek mobil kullanım konforu (${lighter.performanceMetrics.find((m: any) => m.label === "Taşınabilirlik")?.value}/100) sunar.`);
    } else {
      keyDifferences.push(`Taşınabilirlik ve mobilite açısından her iki cihaz da benzer kullanım pratiklikleri sunmaktadır.`);
    }
    
    const p1Prices = p1.marketplace.map((m: any) => m.price);
    const p2Prices = p2.marketplace.map((m: any) => m.price);
    const p1Min = p1Prices.length > 0 ? Math.min(...p1Prices) : 0;
    const p2Min = p2Prices.length > 0 ? Math.min(...p2Prices) : 0;
    if (p1Min > 0 && p2Min > 0) {
      const expensive = p1Min > p2Min ? p1 : p2;
      const cheaper = p1Min > p2Min ? p2 : p1;
      keyDifferences.push(`Maliyet ve edinilebilirlik boyutunda ${cheaper.name} daha bütçe dostu bir alternatif sunarken, ${expensive.name} üst düzey premium fiyat segmentinde konumlanmıştır.`);
    }
  } else {
    keyDifferences.push("Karşılaştırma için yeterli ürün teknik verisi bulunmamaktadır.");
  }

  if (selectedProducts.length === 3) {
    const p3 = selectedProducts[2];
    keyDifferences.push(`Kıyaslamaya dahil edilen üçüncü cihaz olan ${p3.name} ise benzersiz teknik özellikleri ve modüler yetenekleriyle alternatif bir kullanım çizgisi çizmektedir.`);
  }

  const p1Name = selectedProducts[0]?.name || "Seçilen Ürün";

  const useCaseVerdict = {
    scenarioGamingOrAI: `Oyun, profesyonel yapay zeka geliştirme veya ağır 3D iş yükleri için en yüksek işlem gücüne ve grafik donanımına sahip olan cihaz (${p1Name}) kesinlikle ilk tercihiniz olmalıdır.`,
    scenarioMobilityOrDaily: "Günlük kullanım, hafif mobilite, taşınabilirlik ve her an yanınızda taşıyabileceğiniz bir asistan deneyimi arıyorsanız, giyilebilir yapıda olan veya daha hafif tasarlanmış ürünü tercih etmelisiniz.",
    scenarioVerdictSummary: "Özetlemek gerekirse, bütçeniz elveriyorsa ve sabit/yoğun bir güç istasyonu arıyorsanız donanım devlerini; esneklik, güncellenebilirlik ve pratik mobil entegrasyon istiyorsanız modüler/giyilebilir alternatifleri seçmeniz önerilir."
  };

  return {
    summaries,
    keyDifferences,
    useCaseVerdict,
    isSimulated: true
  };
}

// API: Get products list

// API: Get products list
app.get("/api/products", (req, res) => {
  res.json({ products: ALL_PRODUCTS });
});

// API: AI Recommendation Engine (using gemini-3.5-flash with thinking)
app.post("/api/recommend", async (req, res) => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
    return res.status(400).json({
      error: "Sistemde geçerli bir Gemini API Anahtarı bulunamadı.",
      suggestion: "Lütfen ekranın sağ üst köşesindeki Ayarlar > Secrets (Sırlar) panelinden GEMINI_API_KEY değerini tanımlayın."
    });
  }

  const { budget, primaryUse, selectedCategory, customNeeds } = req.body;

  try {
    const ai = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });

    const productsJsonString = JSON.stringify(ALL_PRODUCTS, null, 2);

    const userProfileText = `
Kullanıcı Bütçesi: ${budget ? `$${budget}` : "Belirtilmemiş"}
Birincil Kullanım Amacı: ${primaryUse || "Belirtilmemiş"}
Tercih Edilen Kategori: ${selectedCategory || "Hepsi"}
Özel İstekler / Detaylar: ${customNeeds || "Yok"}
`;

    const systemInstruction = `
Sen "TeknoAsistan" adında, dünyadaki en modern teknolojiler konusunda uzmanlaşmış profesyonel bir yapay zeka danışmanısın.
Görevin, kullanıcının bütçesi, kullanım amacı, kategori tercihleri ve özel isteklerine göre portföyümüzdeki ürünlerden en uygun olanları seçmek ve kişiselleştirilmiş bir teknik analiz raporu hazırlamaktır.

Analizi tamamen TÜRKÇE yapmalı, teknik detaylara (işlemci gücü, ekran kalitesi, pil ömrü, verimlilik vb.) odaklanmalısın.
Raporunu kesinlikle sana sağlanan JSON şemasına uygun olarak üretmelisin.

Mevcut Ürün Listesi (Veri Tabanı):
${productsJsonString}
`;

    const userPrompt = `
Kullanıcının profili aşağıdaki gibidir:
${userProfileText}

Lütfen bu kullanıcıya en uygun 1 ile 3 adet ürünü seç, her birine bütçesine ve amacına göre 0-100 arası bir eşleşme skoru (matchScore) ata ve her biri için detaylı bir Türkçe teknik gerekçelendirme (reasoning) yaz. Ayrıca kullanıcı profilinin genel bir analizini (userAnalysis) ve genel donanım tavsiyelerini içeren bir kapanış tavsiyesi (genericAdvice) oluştur.
`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: userPrompt,
      config: {
        systemInstruction: systemInstruction,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          required: ["userAnalysis", "recommendedProducts", "genericAdvice"],
          properties: {
            userAnalysis: {
              type: Type.STRING,
              description: "Kullanıcının ihtiyaçlarının ve teknoloji profilinin Türkçe analizi."
            },
            recommendedProducts: {
              type: Type.ARRAY,
              description: "Tavsiye edilen en uygun ürünlerin listesi.",
              items: {
                type: Type.OBJECT,
                required: ["productId", "matchScore", "reasoning"],
                properties: {
                  productId: {
                    type: Type.STRING,
                    description: "Ürünün ID'si (apple-vision-pro-2, nvidia-rtx-5090, framework-laptop-16, samsung-galaxy-ring, tesla-optimus-devkit, starlink-mini)."
                  },
                  matchScore: {
                    type: Type.INTEGER,
                    description: "Kullanıcı ihtiyaçları ile ürünün eşleşme yüzdesi (0-100)."
                  },
                  reasoning: {
                    type: Type.STRING,
                    description: "Neden bu ürünün seçildiğine dair teknik gerekçelendirme ve bütçe/amaç uyumu açıklaması (Türkçe)."
                  }
                }
              }
            },
            genericAdvice: {
              type: Type.STRING,
              description: "Kullanıcıya gelecekteki teknoloji yatırımları ve bu kategoride nelere dikkat etmesi gerektiği hakkında genel Türkçe uzman tavsiyesi."
            }
          }
        }
      }
    });

    const responseText = response.text;
    if (!responseText) {
      throw new Error("Yapay zekadan boş yanıt alındı.");
    }

    const recommendationResult = JSON.parse(responseText.trim());
    res.json(recommendationResult);

  } catch (error: any) {
    console.warn("Gemini API Error, falling back to local recommendation generator:", error.message || error);
    try {
      const recommendationResult = generateLocalRecommendations(budget, primaryUse, selectedCategory, customNeeds);
      res.json(recommendationResult);
    } catch (fallbackError: any) {
      console.error("Critical fallback recommendation error:", fallbackError);
      res.status(500).json({
        error: "Yapay zeka öneri motoru çalıştırılırken bir hata oluştu.",
        details: error.message || error
      });
    }
  }
});

// API: AI Comparison Assistant (analyzes technical differences between 2 or 3 products)
app.post("/api/ai-compare", async (req, res) => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
    return res.status(400).json({
      error: "Sistemde geçerli bir Gemini API Anahtarı bulunamadı.",
      suggestion: "Lütfen Ayarlar > Secrets panelinden GEMINI_API_KEY değerini tanımlayın."
    });
  }

  const { productIds } = req.body;
  if (!productIds || !Array.isArray(productIds) || productIds.length < 2) {
    return res.status(400).json({ error: "Karşılaştırma için en az iki ürün seçilmelidir." });
  }

  const selectedProducts = ALL_PRODUCTS.filter(p => productIds.includes(p.id));
  if (selectedProducts.length < 2) {
    return res.status(400).json({ error: "Seçilen ürünler veri tabanında bulunamadı." });
  }

  try {
    const ai = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });

    const comparePrompt = `
Lütfen aşağıdaki teknik özellikleri verilen ürünleri derinlemesine karşılaştır:
${JSON.stringify(selectedProducts, null, 2)}

Senden istenenler:
1. Her ürün için kısa bir teknik özet yaz.
2. Bu ürünlerin temel farklarını (Örn: Güç verimliliği, taşınabilirlik, maliyet, kullanım amacı) karşılaştır.
3. Hangi senaryolarda hangi ürünün tercih edilmesi gerektiğine dair net bir karar (verdict) bildir.

Lütfen yanıtı tamamen TÜRKÇE, son derece profesyonel, anlaşılır ve JSON formatında döndür. Şema şu şekilde olmalıdır:
{
  "summaries": {
    "urun_id": "Urun hakkinda teknik ozet..."
  },
  "keyDifferences": [
    "Fark 1...",
    "Fark 2..."
  ],
  "useCaseVerdict": {
    "senaryo_1": "Urun A tercih edilmeli cunku...",
    "senaryo_2": "Urun B tercih edilmeli cunku..."
  }
}
`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: comparePrompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          required: ["summaries", "keyDifferences", "useCaseVerdict"],
          properties: {
            summaries: {
              type: Type.OBJECT,
              description: "Her ürün kimliği (id) için ürünün Türkçe teknik özeti.",
              properties: selectedProducts.reduce((acc: any, p) => {
                acc[p.id] = { type: Type.STRING };
                return acc;
              }, {})
            },
            keyDifferences: {
              type: Type.ARRAY,
              description: "Ürünler arasındaki temel teknik ve pratik farklar listesi (Türkçe).",
              items: { type: Type.STRING }
            },
            useCaseVerdict: {
              type: Type.OBJECT,
              description: "Hangi durumlarda hangi ürünün tercih edilmesi gerektiğine dair teknik kararlar/senaryolar.",
              properties: {
                scenarioGamingOrAI: {
                  type: Type.STRING,
                  description: "Oyun, Yapay Zeka veya Yoğun Grafik İşleri için karar."
                },
                scenarioMobilityOrDaily: {
                  type: Type.STRING,
                  description: "Mobilite, Taşınabilirlik veya Günlük Pratiklik için karar."
                },
                scenarioVerdictSummary: {
                  type: Type.STRING,
                  description: "Genel nihai değerlendirme özeti."
                }
              }
            }
          }
        }
      }
    });

    const responseText = response.text;
    if (!responseText) {
      throw new Error("Boş karşılaştırma yanıtı alındı.");
    }

    res.json(JSON.parse(responseText.trim()));

  } catch (error: any) {
    console.warn("AI Compare Error, falling back to local technical comparison:", error.message || error);
    try {
      const compareResult = generateLocalComparison(selectedProducts);
      res.json(compareResult);
    } catch (fallbackError: any) {
      console.error("Critical fallback comparison error:", fallbackError);
      res.status(500).json({
        error: "Yapay zeka karşılaştırma motoru çalıştırılırken bir hata oluştu.",
        details: error.message || error
      });
    }
  }
});

// API: Dynamic Web Search Discovery for newer technologies
app.post("/api/discover-new", async (req, res) => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
    return res.status(400).json({
      error: "Sistemde geçerli bir Gemini API Anahtarı bulunamadı.",
      suggestion: "Lütfen ekranın sağ üst köşesindeki Ayarlar > Secrets (Sırlar) panelinden GEMINI_API_KEY değerini tanımlayın."
    });
  }

  const searchPrompt = `
Google Arama kullanarak 2026 yılı ve en son lansmanı yapılan, dünyadaki en yeni ve en popüler tüketici donanım teknolojilerini, robotik platformları, gelişmiş çipleri, akıllı halkaları veya karma gerçeklik başlıklarını araştır.
Bu teknolojilerden, mevcut kataloğumuzda olmayan tamamen YENİ ve ilginç 1 veya 2 adet ürünü seç ve bunları ürün listemize uyumlu bir biçimde detaylandır.

Mevcut Kataloğumuzdaki Cihaz İsimleri: ${ALL_PRODUCTS.map(p => p.name).join(", ")}

Lütfen seçtiğin bu yeni ürünleri TÜRKÇE olarak, aşağıdaki JSON formatında oluştur. Her ürünün ID'si benzersiz ve küçük harfli İngilizce olmalı (Örn: 'meta-orion-glasses') ve pazar yeri fiyatları ile tüm teknik metrikleri içermelidir:

Response JSON Schema:
[
  {
    "id": "benzersiz-id-string",
    "name": "Ürünün Resmi Adı",
    "tagline": "Ürün için havalı ve kısa bir Türkçe tanıtım spotu.",
    "category": "Giyilebilir Teknoloji" | "Yapay Zeka & Robotik" | "Sanal & Artırılmış Gerçeklik" | "Donanım & Bilgisayar" | "Akıllı Çevre & İletişim",
    "priceRange": "$X - $Y",
    "image": "illustration_keyword",
    "description": "Ürünün genel, dikkat çekici ve kısa Türkçe açıklaması.",
    "longDescription": "Ürünün en az 3-4 cümlelik, teknik detaylara ve kullanım amaçlarına odaklanan kapsamlı Türkçe açıklaması.",
    "pros": [
      "Artı yön 1",
      "Artı yön 2",
      "Artı yön 3"
    ],
    "cons": [
      "Eksi yön 1",
      "Eksi yön 2"
    ],
    "specs": [
      { "label": "Özellik Adı 1", "value": "Özellik Değeri 1" },
      { "label": "Özellik Adı 2", "value": "Özellik Değeri 2" },
      { "label": "Özellik Adı 3", "value": "Özellik Değeri 3" },
      { "label": "Özellik Adı 4", "value": "Özellik Değeri 4" }
    ],
    "marketplace": [
      {
        "id": "benzersiz-magaza-id-1",
        "storeName": "Tedarikçi A",
        "price": 1299,
        "rating": 4.7,
        "stockStatus": "InStock",
        "deliveryDays": 3,
        "url": "https://example.com"
      },
      {
        "id": "benzersiz-magaza-id-2",
        "storeName": "Tedarikçi B",
        "price": 1349,
        "rating": 4.5,
        "stockStatus": "LowStock",
        "deliveryDays": 5,
        "url": "https://example.com"
      }
    ],
    "performanceMetrics": [
      { "label": "İşlem Gücü", "value": 92 },
      { "label": "Taşınabilirlik", "value": 85 },
      { "label": "Ekran Kalitesi", "value": 90 },
      { "label": "Fiyat/Performans", "value": 75 }
    ]
  }
]
`;

  const responseSchema = {
    type: Type.ARRAY,
    items: {
      type: Type.OBJECT,
      required: ["id", "name", "tagline", "category", "priceRange", "image", "description", "longDescription", "pros", "cons", "specs", "marketplace", "performanceMetrics"],
      properties: {
        id: { type: Type.STRING },
        name: { type: Type.STRING },
        tagline: { type: Type.STRING },
        category: { type: Type.STRING },
        priceRange: { type: Type.STRING },
        image: { type: Type.STRING },
        description: { type: Type.STRING },
        longDescription: { type: Type.STRING },
        pros: { type: Type.ARRAY, items: { type: Type.STRING } },
        cons: { type: Type.ARRAY, items: { type: Type.STRING } },
        specs: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            required: ["label", "value"],
            properties: {
              label: { type: Type.STRING },
              value: { type: Type.STRING }
            }
          }
        },
        marketplace: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            required: ["id", "storeName", "price", "rating", "stockStatus", "deliveryDays", "url"],
            properties: {
              id: { type: Type.STRING },
              storeName: { type: Type.STRING },
              price: { type: Type.INTEGER },
              rating: { type: Type.NUMBER },
              stockStatus: { type: Type.STRING },
              deliveryDays: { type: Type.INTEGER },
              url: { type: Type.STRING }
            }
          }
        },
        performanceMetrics: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            required: ["label", "value"],
            properties: {
              label: { type: Type.STRING },
              value: { type: Type.INTEGER }
            }
          }
        }
      }
    }
  };

  try {
    const ai = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });

    let responseText = "";

    // Attempt 1: Google live search tool enabled
    try {
      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: searchPrompt,
        config: {
          tools: [{ googleSearch: {} }],
          responseMimeType: "application/json",
          responseSchema: responseSchema
        }
      });
      responseText = response.text || "";
    } catch (searchError: any) {
      console.warn("Google Live Search failed, trying normal text generation without Search Tool...", searchError.message || searchError);
      
      // Attempt 2: normal text generation fallback (offline-AI mode)
      const offlinePrompt = searchPrompt + "\nNOT: Google Search modülü şu anda meşgul veya kotasız. Lütfen 2025/2026 yıllarında çıkan gerçek en yeni ve popüler teknolojilerden bildiklerini kullanarak yeni 1 veya 2 adet ürünü şemaya uygun üret.";
      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: offlinePrompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: responseSchema
        }
      });
      responseText = response.text || "";
    }

    if (!responseText) {
      throw new Error("Yapay zekadan boş yanıt döndü.");
    }

    const newProducts = JSON.parse(responseText.trim());
    let addedCount = 0;
    
    newProducts.forEach((newP: any) => {
      if (!ALL_PRODUCTS.some(p => p.id === newP.id)) {
        const validCategories = ['Giyilebilir Teknoloji', 'Yapay Zeka & Robotik', 'Sanal & Artırılmış Gerçeklik', 'Donanım & Bilgisayar', 'Akıllı Çevre & İletişim'];
        if (!validCategories.includes(newP.category)) {
          newP.category = 'Giyilebilir Teknoloji';
        }
        ALL_PRODUCTS.push(newP);
        addedCount++;
      }
    });

    res.json({
      success: true,
      addedProducts: newProducts,
      addedCount,
      totalProductsCount: ALL_PRODUCTS.length
    });

  } catch (error: any) {
    console.warn("Discovery Gemini API completely failed or rate limited, falling back to local database extension:", error.message || error);
    
    // Attempt 3: local static fallback list expansion
    const candidate = FALLBACK_DISCOVER_PRODUCTS.find(p => !ALL_PRODUCTS.some(ap => ap.id === p.id));
    if (candidate) {
      ALL_PRODUCTS.push(candidate as Product);
      res.json({
        success: true,
        addedProducts: [candidate],
        addedCount: 1,
        totalProductsCount: ALL_PRODUCTS.length,
        isSimulated: true,
        infoMessage: "Yoğun istek nedeniyle simüle güvenli mod devreye girdi ve kütüphaneden yeni nesil bir ürün eklendi!"
      });
    } else {
      res.json({
        success: true,
        addedProducts: [],
        addedCount: 0,
        totalProductsCount: ALL_PRODUCTS.length,
        isSimulated: true,
        infoMessage: "Tüm yeni teknolojiler zaten kataloğumuzda mevcut!"
      });
    }
  }
});

// Serve frontend assets
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on port ${PORT}`);
  });
}

startServer();
